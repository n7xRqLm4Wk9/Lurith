"""PyInstaller entry point for the Lurith desktop app (windowed .exe)."""

from __future__ import annotations

from lurith.gui import main

if __name__ == "__main__":
    raise SystemExit(main())
