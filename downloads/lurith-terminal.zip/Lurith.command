#!/bin/sh
# Double-click this file on macOS to open the Lurith desktop app.
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
if ! python3 -c "import tree_sitter, tree_sitter_language_pack" >/dev/null 2>&1; then
    echo "First run: installing the Lurith engine (this happens once)..."
    python3 -m pip install -r requirements-terminal.txt
fi
python3 -m lurith.gui
