@echo off
setlocal
cd /d "%~dp0"

python -c "import tree_sitter, tree_sitter_language_pack" >nul 2>nul
if errorlevel 1 goto install

:launch
python -m lurith.gui
if errorlevel 1 goto fail
goto done

:install
echo.
echo First run: installing the Lurith engine - this happens once.
python -m pip install -r requirements-terminal.txt
if errorlevel 1 goto fail
goto launch

:fail
echo.
echo Could not start Lurith.
echo Install Python 3.11+ from python.org and tick "Add Python to PATH",
echo then run Lurith.bat again.
pause

:done
endlocal
