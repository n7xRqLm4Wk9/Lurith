# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec: builds Lurith.exe (windowed GUI) and lurith-cli.exe
(console CLI) as self-contained one-file executables.

The grammar loader falls back to the tree-sitter-language-pack at runtime, so
the .exe downloads the platform grammars on first run (internet needed once)
and caches them afterwards.
"""

from PyInstaller.utils.hooks import collect_all

datas = [("assets/icon.png", "assets"), ("assets/icon.ico", "assets")]
binaries = []
hiddenimports = []
for package in ("tree_sitter", "tree_sitter_language_pack"):
    package_datas, package_binaries, package_hidden = collect_all(package)
    datas += package_datas
    binaries += package_binaries
    hiddenimports += package_hidden

common = dict(
    pathex=["."],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    excludes=["discord", "aiohttp", "pytest"],
)

gui_analysis = Analysis(["launcher_gui.py"], **common)
gui_pyz = PYZ(gui_analysis.pure)
gui_exe = EXE(
    gui_pyz,
    gui_analysis.scripts,
    gui_analysis.binaries,
    gui_analysis.datas,
    [],
    name="Lurith",
    console=False,
    icon="assets/icon.ico",
    upx=False,
)

cli_analysis = Analysis(["launcher_cli.py"], **common)
cli_pyz = PYZ(cli_analysis.pure)
cli_exe = EXE(
    cli_pyz,
    cli_analysis.scripts,
    cli_analysis.binaries,
    cli_analysis.datas,
    [],
    name="lurith-cli",
    console=True,
    icon="assets/icon.ico",
    upx=False,
)
