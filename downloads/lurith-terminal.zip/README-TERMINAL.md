# Lurith — Terminal & Desktop Edition

A zero-setup folder: extract it, then either **double-click a launcher** to open
the Lurith window, or run one command in a terminal. The only requirement is
Python 3.11+ (from python.org; tick **"Add Python to PATH"** during install).
The engine's two small parser dependencies install themselves on first run.

## Windows

- **Desktop app (GUI):** double-click **`Lurith.bat`**.
- **Terminal:** open PowerShell **inside this folder** (in File Explorer, type
  `powershell` in the address bar and press Enter), then:

  ```powershell
  .\lurith --version                 # sanity check
  .\lurith script.lua -c high        # obfuscate a file
  .\lurith game.luau -d luau -c very-high
  .\lurith --list-levels
  ```

  With no arguments, `.\lurith` opens the desktop app.

## macOS / Linux

- **Desktop app:** double-click **`Lurith.command`** (macOS) or run `./lurith.sh`.
- **Terminal:** open Terminal in this folder and run:

  ```bash
  ./lurith.sh script.lua -c high
  ./lurith.sh game.luau -d luau -c maximum
  ```

## Build a real .exe (optional)

You don't need a .exe — `Lurith.bat` works everywhere. But if you want a
double-clickable `Lurith.exe` (desktop app) and `lurith-cli.exe` (terminal),
you have two free options:

**A. On your own Windows PC (easiest):** double-click **`build_exe.bat`**. It
installs PyInstaller and builds both exe files into the `dist\` folder
(`Lurith.exe` + `lurith-cli.exe`). Takes a few minutes, once.

**B. On GitHub (no Windows needed):** this folder includes
`.github/workflows/build-windows.yml`. Push it to a GitHub repo and **push a tag
like `v5.1.0`** (or run **Actions → Build & release Windows EXE → Run
workflow** for an artifact). On a tag the workflow automatically publishes a
GitHub Release with `Lurith.exe` + `lurith-cli.exe` attached, downloadable at:

```
https://github.com/YOUR_USERNAME/lurith/releases/latest/download/Lurith.exe
```

That is the URL the Lurith website's **Download Lurith.exe** button points to —
replace `YOUR_USERNAME` with your GitHub username in `index.html` and the
button works permanently (it always follows the latest release).

Either way the exe uses the same Lurith icon (`assets/icon.ico`). First run
needs internet once (it downloads the Lua/Luau parsers and caches them).

### If the build fails

- **Antivirus false positive:** Windows Defender and some AVs flag
  PyInstaller-built exes (very common, it's a false positive). Add an exception
  for this folder and run `build_exe.bat` again.
- **Python not found:** install from https://www.python.org and tick
  "Add Python to PATH".
- **`dist\` is missing:** the build runs `--clean` every time, so a half-finished
  earlier run is wiped automatically.
- Still failing? Copy the red error text and it can be diagnosed from that.

## The desktop app

Add as many sources as you like — **folders** (scanned recursively),
**individual files**, and **`.zip` archives** — then choose the protection
level, dialect, VM family, and toggles, and hit **⚡ Obfuscate**. Every
`.lua` / `.luau` / `.txt` file is obfuscated and saved as `<name>.lurith.txt`
next to each source; zips come back as a new `<name>.lurith.zip` with the same
folder layout inside. A log shows what happened; one bad file never stops the
rest.

## Protection levels

`low` · `normal` · `medium` · `high` · `very-high` · `maximum` — all six are
unlocked locally (the booster lock only applies to the Discord bot). Use
`-d luau` for Roblox scripts; plain Lua 5.1 is the default. For Roblox, the
`auto` environment check verifies `game`/`workspace`/`task` so the output only
runs inside Roblox — pass `--environment-assertions off` to disable it.

## Everything else

- `lurith/` — the engine (also installable: `pip install .` gives a `lurith` command).
- `requirements-terminal.txt` — the two parser dependencies (auto-installed on first run).
- `README.md` — full documentation for the engine, configs, VM families and directives.
