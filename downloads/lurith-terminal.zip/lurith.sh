#!/bin/sh
# Lurith launcher (macOS / Linux). Run `./lurith.sh` with no arguments to open
# the desktop app, or `./lurith.sh file.lua -c high` for the terminal command.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"
if ! python3 -c "import tree_sitter, tree_sitter_language_pack" >/dev/null 2>&1; then
    echo "First run: installing the Lurith engine (this happens once)..."
    python3 -m pip install -r requirements-terminal.txt
fi
if [ $# -eq 0 ]; then
    python3 -m lurith.gui
else
    python3 -m lurith.cli "$@"
fi
