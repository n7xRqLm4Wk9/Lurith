"""PyInstaller entry point for the Lurith terminal command (console .exe)."""

from __future__ import annotations

from lurith.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
