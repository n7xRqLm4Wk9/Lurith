from __future__ import annotations

import re
from functools import partial
from typing import Any

from .candidate_analysis import analyze_candidate
from .config import get_config
from .ir import Instruction
from .vm import RandomLike
from .vm_common import _parameter_nodes, _random_name, _walk
from .vm_family import VmFamilyError
from .vm_integrity import _constant_canary
from .vm_lowering import _box_placeholder, _cell_param_placeholder, _FunctionCompiler
from .vm_optimize import optimize_program_ir
from .vm_packing import BytecodePackingError, pack_words, validate_packed_round_trip
from .vm_profile import create_vm_profile
from .vm_runtime import _render_shared_runtime
from .vm_schema import ALL_INSTRUCTIONS, DYNAMIC_RESULT_INSTRUCTIONS
from .vm_types import CompiledFunction, FunctionVmError, FunctionVmResult
from .vm_validate import VmValidationError, validate_encoded_bytecode, validate_program_ir

_ANNOTATION = re.compile(rb"^--\s*@(lurith|luaminator|aegis)-vm(?:\s+([A-Za-z0-9_-]+))?\s*$")
_ALIASED_OPCODES = frozenset({"ALU_DUAL", "CMP_DUAL"})
# Opcodes sampled after the established/dynamic draw so the original opcode
# layout and RNG stream stay byte-identical to earlier releases. GET_BOX/SET_BOX
# (boxed closure capture), CLOSE_OVER (loop-variable capture), and RETURN_NONE
# (bare-return zero values) join the late pool for the same reason.
_LATE_SAMPLED_OPCODES = frozenset(
    _ALIASED_OPCODES | {"GET_BOX", "SET_BOX", "CLOSE_OVER", "RETURN_NONE"}
)


def _invert_aliased(opcode: str, value: int, *, alu_inverted: bool, cmp_inverted: bool) -> int:
    if opcode == "ALU_DUAL" and alu_inverted:
        return 1 - value
    if opcode == "CMP_DUAL" and cmp_inverted:
        return 1 - value
    return value
_NO_VM_ANNOTATION = re.compile(rb"^--\s*@(lurith|luaminator)-no-vm(?:\s.*)?$")
_HOT_ANNOTATION = re.compile(rb"^--\s*@(lurith|luaminator)-hot(?:\s.*)?$")


def virtualize_annotated_functions(
    source: str,
    tree: Any,
    rng: RandomLike,
    *,
    max_instructions: int = 100_000,
    anti_tamper_mode: str = "off",
    polymorphism_level: int = 0,
    auto_virtualize_min_nodes: int = 0,
    auto_virtualize_max_overhead: int = 0,
    superinstruction_level: int = 0,
    vm_family: str = "auto",
    dialect: str = "luau",
) -> FunctionVmResult:
    if anti_tamper_mode not in {"off", "once", "sampled", "always"}:
        raise ValueError("anti_tamper_mode must be 'off', 'once', 'sampled', or 'always'")
    encoded = source.encode("utf-8")
    used_names = {
        encoded[node.start_byte : node.end_byte].decode("utf-8", "replace")
        for node in _walk(tree.root_node)
        if node.type == "identifier"
    }
    candidates: list[tuple[list[str], bool, Any, bool, tuple[int, int] | None, int | None]] = []
    candidate_body_ranges: list[tuple[int, int]] = []

    for node in _walk(tree.root_node):
        if node.type != "function_declaration":
            continue
        annotation = node.prev_named_sibling
        annotation_text = b""
        annotation_adjacent = False
        if annotation is not None and annotation.type == "comment":
            annotation_text = encoded[annotation.start_byte : annotation.end_byte].strip()
            gap = encoded[annotation.end_byte : node.start_byte]
            annotation_adjacent = gap.count(b"\n") <= 1
        annotation_match = _ANNOTATION.fullmatch(annotation_text) if annotation_adjacent else None
        forced = annotation_match is not None
        disabled = annotation_adjacent and (
            _NO_VM_ANNOTATION.fullmatch(annotation_text) is not None
            or _HOT_ANNOTATION.fullmatch(annotation_text) is not None
        )
        if disabled:
            continue
        if any(start <= node.start_byte < end for start, end in candidate_body_ranges):
            if forced:
                raise FunctionVmError("Nested overlapping @lurith-vm annotations are not supported.")
            continue
        if not forced and auto_virtualize_min_nodes <= 0:
            continue

        # Per-function protection-level override, e.g. `--@lurith-vm maximum`.
        # Maps to the named config's polymorphism level; the VM family and
        # anti-tamper schedule still come from the selected config.
        override_level: int | None = None
        if forced and annotation_match.group(2) is not None:
            level_name = annotation_match.group(2).decode("ascii", "replace")
            try:
                override_level = get_config(level_name).vm_polymorphism_level
            except ValueError as exc:
                raise FunctionVmError(
                    f"Unknown @lurith-vm protection level {level_name!r}; "
                    f"choose one of low, normal, medium, high, very-high, maximum."
                ) from exc

        name = node.child_by_field_name("name")
        parameters_node = node.child_by_field_name("parameters")
        body = node.child_by_field_name("body")
        if name is None or parameters_node is None or body is None:
            if forced:
                raise FunctionVmError("@lurith-vm supports named functions and methods only.")
            continue
        # Supported shapes: `local function f()`, `function f()`,
        # `function T.f()` (dot method), and `function T:f()` (colon method).
        valid_shape = name.type in {"identifier", "dot_index_expression", "method_index_expression"}
        if not valid_shape:
            if forced:
                raise FunctionVmError("@lurith-vm supports named functions and methods only.")
            continue
        is_colon_method = name.type == "method_index_expression"
        if not forced:
            candidate_score = analyze_candidate(body)
            if not candidate_score.eligible(auto_virtualize_min_nodes, auto_virtualize_max_overhead):
                continue
        has_vararg = any(item.type == "vararg_expression" for item in _walk(parameters_node))
        parameter_nodes = _parameter_nodes(parameters_node)
        parameters = [encoded[item.start_byte : item.end_byte].decode("utf-8") for item in parameter_nodes]
        if is_colon_method:
            parameters = ["self", *parameters]
        annotation_range = (annotation.start_byte, annotation.end_byte) if forced else None
        candidates.append((parameters, has_vararg, body, forced, annotation_range, override_level))
        candidate_body_ranges.append((body.start_byte, body.end_byte))

    if not candidates:
        return FunctionVmResult(source, 0, None, 0, 0, 0, 0, 0, 0)

    def build_profile(level: int) -> tuple[Any, dict[str, int], dict[str, int]]:
        profile = create_vm_profile(rng, level, vm_family)
        opcode_limit = profile.opcode_encoding.modulus - 1 if profile.opcode_encoding is not None else 239
        opcode_candidates = list(range(3, opcode_limit))
        # ALU_DUAL/CMP_DUAL are sampled separately (deterministically, from the
        # leftover pool) so the original instructions keep the exact pre-aliasing
        # opcode layout: the RNG draw sequence and every original opcode value
        # are byte-identical to earlier releases.
        established_instructions = [
            instruction
            for instruction in ALL_INSTRUCTIONS
            if instruction not in DYNAMIC_RESULT_INSTRUCTIONS and instruction not in _LATE_SAMPLED_OPCODES
        ]
        established_values = rng.sample(opcode_candidates, len(established_instructions))
        used_opcode_values = set(established_values)
        remaining_values = [value for value in opcode_candidates if value not in used_opcode_values]
        dynamic_instructions = [
            instruction for instruction in ALL_INSTRUCTIONS if instruction in DYNAMIC_RESULT_INSTRUCTIONS
        ]
        dynamic_values = remaining_values[: len(dynamic_instructions)]
        opcodes = dict(zip(established_instructions, established_values, strict=True))
        opcodes.update(dict(zip(dynamic_instructions, dynamic_values, strict=True)))
        for name in _ALIASED_OPCODES:
            for value in opcode_candidates:
                if value not in opcodes.values():
                    opcodes[name] = value
                    break
        for name in ("GET_BOX", "SET_BOX", "CLOSE_OVER", "RETURN_NONE"):
            for value in opcode_candidates:
                if value not in opcodes.values():
                    opcodes[name] = value
                    break
        stored_opcodes = {instruction: profile.encode_opcode(value) for instruction, value in opcodes.items()}
        return profile, opcodes, stored_opcodes

    # With two or more candidate functions, split them across two independently
    # randomized dispatcher runtimes. A function with a `--@lurith-vm <level>`
    # override gets its own profile built at that level, keyed by (group, level)
    # so same-level functions in different groups keep distinct dispatchers.
    num_groups = 2 if len(candidates) >= 2 else 1
    profile_map: dict[tuple[int, int], tuple[Any, dict[str, int], dict[str, int]]] = {}
    group_map: dict[tuple[int, int], list[CompiledFunction]] = {}
    annotation_ranges: list[tuple[int, int]] = []
    automatically_virtualized = 0
    total_instructions = 0
    total_ir_instructions = 0
    total_fused_instructions = 0
    used_handles: set[int] = set()
    for position, (parameters, has_vararg, body, forced, annotation_range, override_level) in enumerate(candidates):
        group_index = position % num_groups
        level = override_level if override_level is not None else polymorphism_level
        key = (group_index, level)
        if key not in profile_map:
            try:
                profile_map[key] = build_profile(level)
            except VmFamilyError as exc:
                if forced:
                    raise FunctionVmError(
                        f"@lurith-vm protection level is incompatible with VM family {vm_family!r}: {exc}"
                    ) from exc
                continue
        profile, _opcodes, stored_opcodes = profile_map[key]
        try:
            compiler = _FunctionCompiler(encoded, parameters, has_vararg, aliasing=profile.opcode_aliasing)
            program = compiler.compile(body)
            optimization = optimize_program_ir(program, superinstruction_level)
            validate_program_ir(program)

            code = compiler.builder.assemble(
                stored_opcodes,
                encode_operand=profile.encode_operand if profile.operand_encoding is not None else None,
                operand_transform=partial(
                    _invert_aliased,
                    alu_inverted=profile.alu_inverted,
                    cmp_inverted=profile.cmp_inverted,
                ),
            )
            validate_encoded_bytecode(code, stored_opcodes, profile)
            if profile.packed_bytecode:
                validate_packed_round_trip(code)
        except FunctionVmError:
            if forced:
                raise
            continue
        except (VmValidationError, BytecodePackingError) as exc:
            if forced:
                row, column = body.start_point
                raise FunctionVmError(
                    f"VM validation failed for forced function body at line {row + 1}, column {column + 1}: {exc}"
                ) from exc
            continue
        if total_instructions + len(code) > max_instructions:
            if forced:
                raise FunctionVmError(
                    f"Forced VM functions exceed the combined instruction limit of {max_instructions:,}."
                )
            continue
        total_instructions += len(code)
        total_ir_instructions += sum(isinstance(item, Instruction) for item in program.instructions)
        total_fused_instructions += optimization.fused_instructions
        handle = profile.new_handle(rng, used_handles)
        guard_token = rng.randint(1_000_003, 1_000_000_007)
        # Full integrity coverage: every decoded-code word is sentinel-bound and
        # every constant is canary-bound. Both checks run on every call in every
        # integrity mode, so any bytecode or constant edit is rejected per call
        # regardless of the verification schedule — the post-verification window
        # is closed. This trades per-call runtime (O(code) sentinel scan) for
        # protection; Lurith prioritizes protection over performance.
        sentinel_positions = list(range(1, len(code) + 1))
        sentinel_words = tuple((position_, code[position_ - 1]) for position_ in sentinel_positions)
        constant_positions = list(range(1, len(program.constants) + 1))
        constant_canaries = tuple(
            (position_, *_constant_canary(program.constants[position_ - 1], dialect))
            for position_ in constant_positions
        )
        group_map.setdefault(key, []).append(
            CompiledFunction(
                handle=handle,
                guard_token=guard_token,
                sentinel_words=sentinel_words,
                constant_canaries=constant_canaries,
                code=code,
                program=program,
                parameters=parameters,
                has_vararg=has_vararg,
                body_start=body.start_byte,
                body_end=body.end_byte,
                box_count=program.box_count,
            )
        )
        if forced and annotation_range is not None:
            annotation_ranges.append(annotation_range)
        else:
            automatically_virtualized += 1

    functions = [function for group in group_map.values() for function in group]
    if not functions:
        return FunctionVmResult(source, 0, None, 0, 0, 0, 0, 0, 0)

    run_name_by_key: dict[tuple[int, int], str] = {}
    prelude_parts: list[str] = []
    for key in sorted(group_map):
        group = group_map[key]
        profile, opcodes, _stored_opcodes = profile_map[key]
        run_name, prelude = _render_shared_runtime(
            rng,
            used_names,
            group,
            opcodes,
            profile,
            anti_tamper_mode,
            dialect,
        )
        run_name_by_key[key] = run_name
        prelude_parts.append(prelude)
    prelude = "".join(prelude_parts)

    replacements: list[tuple[int, int, bytes]] = []
    for key, group in group_map.items():
        profile = profile_map[key][0]
        run_name = run_name_by_key[key]
        for function in group:
            arguments = "{" + ",".join(function.parameters) + "}"
            box_name = _random_name(rng, used_names, profile) if function.box_count else ""
            externals_entries = []
            for external in function.program.externals:
                rewritten = external
                for box_number in range(1, function.box_count + 1):
                    rewritten = rewritten.replace(
                        _box_placeholder(box_number), f"{box_name}[{box_number}][1]"
                    )
                if _cell_param_placeholder() in rewritten:
                    cell_name = _random_name(rng, used_names, profile)
                    rewritten = rewritten.replace(_cell_param_placeholder(), cell_name)

                    def substitute_cell(match: re.Match[str], name: str = cell_name) -> str:
                        return f"{name}[{match.group(1)}]"

                    rewritten = re.sub(r"\x03LURITHCELL(\d+)\x02", substitute_cell, rewritten)
                externals_entries.append(rewritten)
            externals = "{" + ",".join(externals_entries) + "}"
            boxes = "{" + ",".join("{}" for _ in range(function.box_count)) + "}"
            boxes_argument = box_name if function.box_count else "{}"
            setter_value = _random_name(rng, used_names, profile)
            setter_entries = [
                f"function({setter_value}) {external}={setter_value} end"
                if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", external)
                else "false"
                for external in function.program.externals
            ]
            setters = "{" + ",".join(setter_entries) + "}"
            varargs = "{...}" if function.has_vararg else "{}"
            vararg_count = 'select("#",...)' if function.has_vararg else "0"
            invocation = (
                f"{run_name}({function.handle},{function.guard_token},{arguments},"
                f"{externals},{boxes_argument},{setters},{varargs},{vararg_count})"
            )
            prefix = f"local {box_name}={boxes};" if function.box_count else ""
            if function.program.returns_multiple:
                wrapper = f"{prefix}return {invocation} "
            elif profile.dispatcher == "bucket":
                result_name = _random_name(rng, used_names, profile)
                wrapper = f"{prefix}local {result_name}={invocation};return {result_name} "
            elif profile.dispatcher == "binary":
                wrapper = f"{prefix}return ({invocation}) "
            else:
                wrapper = f"{prefix}return {invocation} "
            # The trailing space keeps the wrapper's final token from fusing with
            # the function's closing `end` when the body is minified (the same
            # boundary rule that guards the native-flow wrappers).
            replacements.append((function.body_start, function.body_end, wrapper.encode("utf-8")))
    replacements.extend((start, end, b"") for start, end in annotation_ranges)

    for start, end, replacement in sorted(replacements, reverse=True):
        encoded = encoded[:start] + replacement + encoded[end:]
    packed_bytecode_bytes = sum(
        len(pack_words(function.code))
        for key, group in group_map.items()
        for function in group
        if profile_map[key][0].packed_bytecode
    )

    def profile_label(profile: Any) -> str:
        return (
            f"family:{profile.family}/execution:{profile.execution_style}/"
            f"{profile.dispatcher}/{profile.loop_style}/{profile.prelude}/"
            f"stack:{'up' if profile.stack_direction == 1 else 'down'}/"
            f"opcode:{'affine' if profile.opcode_encoding else 'raw'}/"
            f"operand:{'affine' if profile.operand_encoding else 'raw'}/"
            f"register:{'affine' if profile.register_encoding else 'raw'}/"
            f"code:{'packed' if profile.packed_bytecode else 'table'}/"
            f"bootstrap:{profile.bootstrap_shape}/decoys:{profile.decoy_opcode_count}/"
            f"integrity:{profile.integrity_family}"
        )

    profile_name = " | ".join(
        profile_label(profile_map[key][0]) for key in sorted(group_map)
    )


    return FunctionVmResult(
        prelude + encoded.decode("utf-8"),
        len(functions),
        profile_name,
        automatically_virtualized,
        total_ir_instructions,
        total_instructions,
        len(prelude.encode("utf-8")),
        packed_bytecode_bytes,
        total_fused_instructions,
    )
