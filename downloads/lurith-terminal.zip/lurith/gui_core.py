"""Headless core for the Lurith desktop app: folder/file/zip discovery and batch
obfuscation, kept free of any GUI dependency so it is testable and reusable."""

from __future__ import annotations

import re
import zipfile
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from lurith import Obfuscator

SOURCE_EXTENSIONS = {".lua", ".luau", ".txt"}
ZIP_EXTENSIONS = {".zip"}
OUTPUT_SUFFIX = ".lurith.txt"
ZIP_OUTPUT_SUFFIX = ".lurith.zip"

_WATERMARK_LINE = re.compile(
    r"^-- \[(?:Obfuscated using (?:Lurith|Luaminator)|obfuscated by Lurith) [^\r\n]*\][ \t]*(?:\r?\n)?$"
)


@dataclass(frozen=True, slots=True)
class BatchSettings:
    config: str = "high"
    dialect: str = "auto"
    vm_family: str = "auto"
    environment_assertions: str = "auto"
    minify: bool | None = None
    strip_comments: bool | None = None
    watermark: bool = True


def resolve_dialect(source_path: Path, dialect: str) -> str:
    """Resolve the per-file dialect: `.luau` files are Luau, everything else is
    Lua 5.1, unless an explicit dialect was chosen."""
    if dialect in {"lua51", "luau"}:
        return dialect
    return "luau" if source_path.suffix.lower() == ".luau" else "lua51"


@dataclass(slots=True)
class BatchSummary:
    discovered: int = 0
    succeeded: int = 0
    failed: int = 0
    outputs: list[Path] = field(default_factory=list)
    failures: list[tuple[str, str]] = field(default_factory=list)


def _is_source(path: Path) -> bool:
    return path.suffix.lower() in SOURCE_EXTENSIONS and not path.name.endswith(OUTPUT_SUFFIX)


def _is_zip(path: Path) -> bool:
    return path.suffix.lower() in ZIP_EXTENSIONS


def categorize_paths(paths: list[Path]) -> tuple[list[Path], list[Path], list[Path]]:
    """Split a list of paths into (folders, files, zips). Missing paths are
    ignored; a `.zip` is treated as an archive, never a source file."""
    folders: list[Path] = []
    files: list[Path] = []
    zips: list[Path] = []
    for path in paths:
        if path.is_dir():
            folders.append(path)
        elif path.is_file() and _is_zip(path):
            zips.append(path)
        elif path.is_file() and _is_source(path):
            files.append(path)
    return folders, files, zips


def discover_files(paths: list[Path]) -> list[Path]:
    """Expand a list of files/directories into a sorted, de-duplicated list of
    obfuscatable source files (recursively for directories)."""
    result: list[Path] = []
    seen: set[Path] = set()
    for path in paths:
        if path.is_dir():
            for candidate in sorted(path.rglob("*")):
                if candidate.is_file() and _is_source(candidate) and candidate not in seen:
                    seen.add(candidate)
                    result.append(candidate)
        elif path.is_file() and _is_source(path) and path not in seen:
            seen.add(path)
            result.append(path)
    return result


def zip_source_entries(zip_path: Path) -> list[tuple[str, bytes]]:
    """Return the (relative-name, bytes) pairs of every obfuscatable source file
    inside a zip archive, preserving the original order."""
    entries: list[tuple[str, bytes]] = []
    with zipfile.ZipFile(zip_path) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            name = Path(info.filename)
            if _is_source(name):
                entries.append((info.filename, archive.read(info.filename)))
    return entries


def count_sources(paths: list[Path]) -> int:
    """Count the total number of obfuscatable sources across folders, files and
    zips (zip entries are counted individually)."""
    folders, files, zips = categorize_paths(paths)
    total = len(discover_files([*folders, *files]))
    for zip_path in zips:
        try:
            total += len(zip_source_entries(zip_path))
        except (OSError, zipfile.BadZipFile):
            total += 0
    return total


def strip_watermark(source: str) -> str:
    """Remove the leading Lurith watermark line, if present (used by the
    watermark-off option in the desktop app)."""
    lines = source.splitlines(keepends=True)
    for index, line in enumerate(lines):
        if _WATERMARK_LINE.match(line):
            lines.pop(index)
            break
    return "".join(lines)


def _obfuscate_text(raw: str, source_name: str, settings: BatchSettings) -> object:
    dialect = resolve_dialect(Path(source_name), settings.dialect)
    return Obfuscator(
        settings.config,
        dialect,
        environment_assertions=settings.environment_assertions,
        vm_family=settings.vm_family,
        minify=settings.minify,
        strip_comments=settings.strip_comments,
    ).obfuscate(raw)


def obfuscate_zip(
    zip_path: Path,
    settings: BatchSettings,
    on_event: Callable[[str, str, str], None] | None = None,
) -> tuple[Path | None, int, int]:
    """Obfuscate every source inside a zip and write a new `<stem>.lurith.zip`
    next to it, preserving the relative path of each entry (renamed to
    `<name>.lurith.txt`). Returns (output_path, ok, failed)."""
    try:
        entries = zip_source_entries(zip_path)
    except (OSError, zipfile.BadZipFile) as exc:
        if on_event is not None:
            on_event("error", str(zip_path), f"could not read zip: {exc}")
        return None, 0, 0
    output_path = zip_path.with_name(zip_path.stem + ZIP_OUTPUT_SUFFIX)
    succeeded = 0
    failed = 0
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, raw in entries:
            try:
                source = raw.decode("utf-8-sig")
            except UnicodeError as exc:
                failed += 1
                if on_event is not None:
                    on_event("error", f"{zip_path.name}/{name}", f"decode failed: {exc}")
                continue
            try:
                result = _obfuscate_text(source, name, settings)
            except Exception as exc:  # noqa: BLE001 — one bad entry must not kill the zip
                failed += 1
                if on_event is not None:
                    on_event("error", f"{zip_path.name}/{name}", str(exc))
                continue
            text = result.source if settings.watermark else strip_watermark(result.source)
            entry_name = str(Path(name).with_name(Path(name).stem + OUTPUT_SUFFIX))
            archive.writestr(entry_name, text.encode("utf-8"))
            succeeded += 1
            if on_event is not None:
                on_event(
                    "ok",
                    f"{zip_path.name}/{name}",
                    f"{result.config}/{result.dialect} → {entry_name} ({len(raw)} → {len(text)} B)",
                )
    return output_path, succeeded, failed


def obfuscate_batch(
    paths: list[Path],
    settings: BatchSettings,
    on_event: Callable[[str, str, str], None] | None = None,
) -> BatchSummary:
    """Obfuscate every discovered source (folders recursively, individual files,
    and zips). Files write `<stem>.lurith.txt` next to themselves; zips write a
    new `<stem>.lurith.zip`. Per-item errors are collected and reported; one bad
    item never stops the batch."""
    folders, files, zips = categorize_paths(paths)
    summary = BatchSummary()

    def event(kind: str, label: str, message: str) -> None:
        if on_event is not None:
            on_event(kind, label, message)

    discovered = discover_files([*folders, *files])
    summary.discovered = len(discovered)
    for zip_path in zips:
        try:
            summary.discovered += len(zip_source_entries(zip_path))
        except (OSError, zipfile.BadZipFile):
            continue

    for source_path in discovered:
        try:
            raw = source_path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError) as exc:
            summary.failed += 1
            summary.failures.append((str(source_path), f"read failed: {exc}"))
            event("error", str(source_path), f"read failed: {exc}")
            continue
        try:
            result = _obfuscate_text(raw, source_path.name, settings)
        except Exception as exc:  # noqa: BLE001 — one bad file must not kill the batch
            summary.failed += 1
            summary.failures.append((str(source_path), str(exc)))
            event("error", str(source_path), str(exc))
            continue
        output = source_path.with_name(source_path.stem + OUTPUT_SUFFIX)
        text = result.source if settings.watermark else strip_watermark(result.source)
        try:
            output.write_text(text, encoding="utf-8")
        except OSError as exc:
            summary.failed += 1
            summary.failures.append((str(source_path), f"write failed: {exc}"))
            event("error", str(source_path), f"write failed: {exc}")
            continue
        summary.succeeded += 1
        summary.outputs.append(output)
        event(
            "ok",
            str(source_path),
            f"{result.config}/{result.dialect} → {output.name} ({result.input_bytes} → {result.output_bytes} B)",
        )

    for zip_path in zips:
        output, succeeded, failed = obfuscate_zip(
            zip_path, settings, on_event=lambda kind, label, message: event(kind, label, message)
        )
        summary.succeeded += succeeded
        summary.failed += failed
        if output is not None and succeeded > 0:
            summary.outputs.append(output)
            event("ok", str(zip_path), f"zip → {output.name} ({succeeded} files)")
        elif output is None:
            summary.failed += 1

    return summary
