from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .ir import Instruction, Label, ProgramIR
from .vm_profile import VmProfile
from .vm_schema import INSTRUCTION_SPECS, instruction_effect, instruction_minimum_stack


class VmValidationError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class DecodedInstruction:
    pc: int
    opcode: str
    operands: tuple[int, ...]


def _validate_operand_shape(opcode: str, operands: tuple[Any, ...]) -> None:
    spec = INSTRUCTION_SPECS.get(opcode)
    if spec is None:
        raise VmValidationError(f"Unknown IR opcode {opcode!r}")
    if spec.operands is not None and len(operands) != spec.operands:
        raise VmValidationError(f"{opcode} expects {spec.operands} operands, got {len(operands)}")
    if opcode == "GENERIC_NEXT":
        if len(operands) < 6 or not isinstance(operands[3], int):
            raise VmValidationError("GENERIC_NEXT has an invalid operand header")
        variable_count = operands[3]
        if not 1 <= variable_count <= 4 or len(operands) != 5 + variable_count:
            raise VmValidationError("GENERIC_NEXT variable count does not match its operands")


def _check_index(name: str, value: Any, maximum: int) -> None:
    if not isinstance(value, int) or not 1 <= value <= maximum:
        raise VmValidationError(f"{name} index {value!r} is outside 1..{maximum}")


def _validate_indices(program: ProgramIR, opcode: str, operands: tuple[Any, ...]) -> None:
    if opcode in {"CONST", "GET_METHOD"}:
        _check_index("constant", operands[0], len(program.constants))
    if opcode in {"ADD_LOCAL_CONST_SET", "JNE_LOCAL_CONST"}:
        _check_index("local", operands[0], program.local_count)
        _check_index("constant", operands[1], len(program.constants))
    if opcode == "ADD_LOCAL_CONST_SET":
        _check_index("local", operands[2], program.local_count)
    if opcode == "ADD_LOCALS_SET":
        for value in operands:
            _check_index("local", value, program.local_count)
    if opcode in {"GET_EXT", "SET_EXT", "CLOSE_OVER"}:
        _check_index("external", operands[0], len(program.externals))
    if opcode in {"GET_LOCAL", "SET_LOCAL", "COERCE_NUMBER", "CHECK_STEP"}:
        _check_index("local", operands[0], program.local_count)
    if opcode == "GET_VARARG":
        _check_index("vararg", operands[0], 1_000_000)
    if opcode in {
        "CALL",
        "CALL_PACK",
        "CALL_VARARG",
        "CALL_VARARG_PACK",
        "CALL_EXPANDED",
        "CALL_EXPANDED_PACK",
        "TAIL_CALL",
        "TAIL_CALL_VARARG",
        "TAIL_CALL_EXPANDED",
    } and (not isinstance(operands[0], int) or not 0 <= operands[0] <= 8):
        raise VmValidationError(f"{opcode} fixed argument count must be between 0 and 8")
    if opcode == "EXPAND_FIXED" and (not isinstance(operands[0], int) or not 1 <= operands[0] <= 1_000_000):
        raise VmValidationError("EXPAND_FIXED result count must be between 1 and 1,000,000")
    if opcode == "TABLE_APPEND_PACK" and (
        not isinstance(operands[0], int) or not 1 <= operands[0] <= 1_000_000
    ):
        raise VmValidationError("TABLE_APPEND_PACK start index must be between 1 and 1,000,000")
    if opcode == "RETURN_EXPANDED" and (not isinstance(operands[0], int) or not 0 <= operands[0] <= 3):
        raise VmValidationError("RETURN_EXPANDED prefix count must be between 0 and 3")
    if opcode == "CALL_MULTI3":
        if not isinstance(operands[0], int) or not 0 <= operands[0] <= 8:
            raise VmValidationError("CALL_MULTI3 argument count must be between 0 and 8")
        for value in operands[1:4]:
            _check_index("local", value, program.local_count)
    if opcode == "GENERIC_NEXT":
        variable_count = operands[3]
        for value in operands[:3]:
            _check_index("local", value, program.local_count)
        for value in operands[4 : 4 + variable_count]:
            _check_index("local", value, program.local_count)
    if opcode == "RETURN_MULTI" and (not isinstance(operands[0], int) or not 1 <= operands[0] <= 8):
        raise VmValidationError("RETURN_MULTI count must be between 1 and 8")


def validate_program_ir(program: ProgramIR) -> None:
    if program.local_count < program.parameter_count:
        raise VmValidationError("parameter count exceeds local frame size")

    marked_labels: set[Label] = set()
    instructions: list[Instruction] = []
    label_targets: dict[Label, int] = {}
    for item in program.instructions:
        if isinstance(item, Label):
            if item in marked_labels:
                raise VmValidationError(f"label {item.identifier} is marked more than once")
            marked_labels.add(item)
            label_targets[item] = len(instructions)
        else:
            _validate_operand_shape(item.opcode, item.operands)
            _validate_indices(program, item.opcode, item.operands)
            instructions.append(item)

    for instruction in instructions:
        for operand in instruction.operands:
            if isinstance(operand, Label) and operand not in marked_labels:
                raise VmValidationError(f"jump references unmarked label {operand.identifier}")

    if not instructions:
        raise VmValidationError("VM program is empty")

    depths: dict[int, int] = {0: 0}
    worklist = [0]
    while worklist:
        index = worklist.pop()
        if index == len(instructions):
            raise VmValidationError("reachable control flow falls off the end of the VM program")
        instruction = instructions[index]
        integer_operands = tuple(value for value in instruction.operands if isinstance(value, int))
        required = instruction_minimum_stack(instruction.opcode, integer_operands)
        depth = depths[index]
        if depth < required:
            raise VmValidationError(
                f"stack underflow at IR instruction {index + 1} ({instruction.opcode}): needs {required}, has {depth}"
            )
        next_depth = depth + instruction_effect(instruction.opcode, integer_operands)
        successors: list[int] = []
        if instruction.opcode == "JUMP":
            successors.append(label_targets[instruction.operands[0]])
        elif instruction.opcode in {"JFALSE_POP", "JFALSE_KEEP", "JTRUE_KEEP"}:
            successors.extend((index + 1, label_targets[instruction.operands[0]]))
        elif instruction.opcode == "JNE_LOCAL_CONST":
            successors.extend((index + 1, label_targets[instruction.operands[2]]))
        elif instruction.opcode == "GENERIC_NEXT":
            successors.extend((index + 1, label_targets[instruction.operands[-1]]))
        elif not INSTRUCTION_SPECS[instruction.opcode].terminal:
            successors.append(index + 1)

        for successor in successors:
            previous = depths.get(successor)
            if previous is not None and previous != next_depth:
                raise VmValidationError(
                    f"conflicting stack depths at IR instruction {successor + 1}: {previous} vs {next_depth}"
                )
            if previous is None:
                depths[successor] = next_depth
                worklist.append(successor)


def _decode_operand(profile: VmProfile, value: int) -> int:
    encoding = profile.operand_encoding
    if encoding is None:
        return value
    return ((value - encoding.increment) * encoding.inverse) % encoding.modulus


def validate_encoded_bytecode(
    code: list[int],
    stored_opcodes: dict[str, int],
    profile: VmProfile,
) -> list[DecodedInstruction]:
    reverse_opcodes = {value: name for name, value in stored_opcodes.items()}
    if len(reverse_opcodes) != len(stored_opcodes):
        raise VmValidationError("encoded opcode collision")

    decoded: list[DecodedInstruction] = []
    index = 0
    while index < len(code):
        pc = index + 1
        encoded_opcode = code[index]
        index += 1
        opcode = reverse_opcodes.get(encoded_opcode)
        if opcode is None:
            raise VmValidationError(f"unknown encoded opcode {encoded_opcode} at word {pc}")
        spec = INSTRUCTION_SPECS[opcode]
        if spec.operands is None:
            if index + 4 > len(code):
                raise VmValidationError(f"truncated {opcode} header at word {pc}")
            header = tuple(_decode_operand(profile, value) for value in code[index : index + 4])
            variable_count = header[3]
            operand_count = 5 + variable_count
        else:
            operand_count = spec.operands
        if index + operand_count > len(code):
            raise VmValidationError(f"truncated {opcode} operands at word {pc}")
        operands = tuple(_decode_operand(profile, value) for value in code[index : index + operand_count])
        index += operand_count
        _validate_operand_shape(opcode, operands)
        decoded.append(DecodedInstruction(pc, opcode, operands))

    boundaries = {instruction.pc for instruction in decoded}
    for instruction in decoded:
        targets: tuple[int, ...] = ()
        if instruction.opcode in {"JUMP", "JFALSE_POP", "JFALSE_KEEP", "JTRUE_KEEP"}:
            targets = (instruction.operands[0],)
        elif instruction.opcode == "JNE_LOCAL_CONST":
            targets = (instruction.operands[2],)
        elif instruction.opcode == "GENERIC_NEXT":
            targets = (instruction.operands[-1],)
        for target in targets:
            if target not in boundaries:
                raise VmValidationError(
                    f"{instruction.opcode} at word {instruction.pc} targets non-instruction word {target}"
                )
    return decoded
