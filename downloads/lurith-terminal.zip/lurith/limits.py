from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .lexer import Token


class ResourceLimitError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class EngineLimits:
    max_source_bytes: int = 5 * 1024 * 1024
    max_tokens: int = 1_500_000
    max_syntax_depth: int = 600
    max_literals: int = 100_000
    max_generated_bytes: int = 64 * 1024 * 1024
    max_function_vm_instructions: int = 100_000


DEFAULT_LIMITS = EngineLimits()


def check_source_size(source: str, limits: EngineLimits) -> None:
    size = len(source.encode("utf-8"))
    if size > limits.max_source_bytes:
        raise ResourceLimitError(f"Source exceeds the engine limit of {limits.max_source_bytes // 1024} KiB.")


def check_tokens(tokens: list[Token], limits: EngineLimits) -> None:
    if len(tokens) > limits.max_tokens:
        raise ResourceLimitError(f"Source contains more than {limits.max_tokens:,} tokens.")
    literals = sum(token.kind in {"string", "interpolated_string"} for token in tokens)
    if literals > limits.max_literals:
        raise ResourceLimitError(f"Source contains more than {limits.max_literals:,} string literals.")


def check_syntax_depth(root: Any, limits: EngineLimits) -> None:
    stack = [(root, 1)]
    while stack:
        node, depth = stack.pop()
        if depth > limits.max_syntax_depth:
            raise ResourceLimitError(f"Syntax nesting exceeds the limit of {limits.max_syntax_depth} levels.")
        stack.extend((child, depth + 1) for child in node.named_children)


def check_generated_size(source: str, limits: EngineLimits) -> None:
    size = len(source.encode("utf-8"))
    if size > limits.max_generated_bytes:
        raise ResourceLimitError(
            f"Generated output exceeds the engine limit of {limits.max_generated_bytes // (1024 * 1024)} MiB."
        )
