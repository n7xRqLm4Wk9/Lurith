from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from pathlib import PurePosixPath
from urllib.parse import unquote, urljoin, urlsplit

import aiohttp
from aiohttp.abc import AbstractResolver

from .version import VERSION


class FetchError(ValueError):
    pass


def _size_label(size: int) -> str:
    if size % (1024 * 1024) == 0:
        return f"{size // (1024 * 1024)} MiB"
    return f"{size // 1024} KiB"


@dataclass(frozen=True, slots=True)
class DownloadedSource:
    data: bytes
    filename: str
    final_url: str


def _is_public_address(host: str) -> bool:
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return False
    return address.is_global


class PublicOnlyResolver(AbstractResolver):
    """DNS resolver that refuses loopback, LAN, link-local, and reserved destinations."""

    def __init__(self) -> None:
        self._resolver = aiohttp.resolver.DefaultResolver()

    async def resolve(self, host: str, port: int = 0, family: int = socket.AF_INET):
        records = await self._resolver.resolve(host, port, family)
        if not records or any(not _is_public_address(record["host"]) for record in records):
            raise OSError("URL resolves to a non-public network address")
        return records

    async def close(self) -> None:
        await self._resolver.close()


def validate_public_url(url: str) -> None:
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"}:
        raise FetchError("Only http:// and https:// raw URLs are accepted.")
    if not parsed.hostname or parsed.username or parsed.password:
        raise FetchError("The URL must have a public host and no embedded credentials.")
    try:
        port = parsed.port
    except ValueError as exc:
        raise FetchError("The URL contains an invalid port.") from exc
    if port is not None and port not in {80, 443}:
        raise FetchError("Only standard HTTP/HTTPS ports (80 and 443) are accepted.")
    if parsed.hostname.lower() == "localhost":
        raise FetchError("Local and private-network URLs are not accepted.")
    try:
        literal_address = ipaddress.ip_address(parsed.hostname)
    except ValueError:
        literal_address = None
    if literal_address is not None and not literal_address.is_global:
        raise FetchError("Local and private-network URLs are not accepted.")


def _filename_from_url(url: str) -> str:
    path_name = unquote(PurePosixPath(urlsplit(url).path).name)
    safe = "".join(char for char in path_name if char.isalnum() or char in {".", "_", "-"})
    return safe[:100] or "source.lua"


async def fetch_source(url: str, *, max_bytes: int, redirects: int = 3) -> DownloadedSource:
    current = url.strip().strip("<>")
    resolver = PublicOnlyResolver()
    connector = aiohttp.TCPConnector(resolver=resolver, limit=4)
    timeout = aiohttp.ClientTimeout(total=15, connect=5, sock_read=8)
    headers = {"User-Agent": f"LurithBot/{VERSION}", "Accept": "text/plain, application/octet-stream;q=0.9"}

    try:
        async with aiohttp.ClientSession(connector=connector, timeout=timeout, headers=headers) as session:
            for _ in range(redirects + 1):
                validate_public_url(current)
                async with session.get(current, allow_redirects=False) as response:
                    if response.status in {301, 302, 303, 307, 308}:
                        location = response.headers.get("Location")
                        if not location:
                            raise FetchError("The URL returned an empty redirect.")
                        current = urljoin(current, location)
                        continue
                    if response.status != 200:
                        raise FetchError(f"The raw URL returned HTTP {response.status}.")
                    content_type = response.headers.get("Content-Type", "").lower()
                    if content_type.startswith(("text/html", "application/xhtml+xml")):
                        raise FetchError("That URL returned a web page. Use the file's raw-content URL instead.")
                    declared = response.content_length
                    if declared is not None and declared > max_bytes:
                        raise FetchError(f"Source is larger than {_size_label(max_bytes)}.")
                    chunks: list[bytes] = []
                    size = 0
                    async for chunk in response.content.iter_chunked(32 * 1024):
                        size += len(chunk)
                        if size > max_bytes:
                            raise FetchError(f"Source is larger than {_size_label(max_bytes)}.")
                        chunks.append(chunk)
                    return DownloadedSource(b"".join(chunks), _filename_from_url(current), current)
            raise FetchError(f"The URL redirected more than {redirects} times.")
    except (aiohttp.ClientError, TimeoutError, OSError) as exc:
        raise FetchError(f"Could not securely download that URL: {exc}") from exc
