from __future__ import annotations

import ctypes
import hashlib
import json
import os
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from tree_sitter import Language, Parser


class SyntaxValidationError(ValueError):
    pass


class ParserUnavailableError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class SyntaxAnalysis:
    tree: Any
    has_errors: bool
    error_message: str | None


_REQUIRED_GRAMMARS = ("lua", "luau")
_DEFAULT_GRAMMAR_DIR = "/opt/lurith/tree-sitter"
_thread_local = threading.local()
_loader_lock = threading.Lock()
_loaded_libraries: dict[str, ctypes.CDLL] = {}
_loaded_languages: dict[str, Language] = {}
_verified_manifest_directory: Path | None = None


def grammar_directory() -> Path:
    configured = os.getenv("LURITH_TS_GRAMMAR_DIR") or os.getenv("LUAMINATOR_TS_GRAMMAR_DIR")
    return Path(configured or _DEFAULT_GRAMMAR_DIR).resolve()


def _grammar_dir_configured() -> bool:
    return bool(os.getenv("LURITH_TS_GRAMMAR_DIR") or os.getenv("LUAMINATOR_TS_GRAMMAR_DIR"))


def _language_pack_cache_directory() -> Path:
    """Cache directory for the tree-sitter-language-pack fallback.

    The container sets LURITH_TS_GRAMMAR_DIR and always loads its baked grammars,
    so this path is only used by local CLI installs that ship no grammars/. It
    lives under the platform cache directory, not /opt.
    """
    configured = os.getenv("LURITH_TS_GRAMMAR_DIR") or os.getenv("LUAMINATOR_TS_GRAMMAR_DIR")
    if configured:
        return Path(configured).resolve()
    base = Path(os.getenv("XDG_CACHE_HOME") or Path.home() / ".cache")
    return base / "lurith" / "tree-sitter"


def _manifest_records(directory: Path) -> dict[str, dict[str, Any]]:
    manifest_path = directory / "lurith-grammars.json"
    if not manifest_path.is_file():
        raise ParserUnavailableError(
            f"Tree-sitter grammar manifest is missing at {manifest_path}. "
            "The image is incomplete; rebuild it so scripts/bake_tree_sitter.py runs successfully."
        )
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        records = {record["name"]: record for record in manifest["grammars"]}
    except (OSError, KeyError, TypeError, json.JSONDecodeError) as exc:
        raise ParserUnavailableError(f"Tree-sitter grammar manifest is invalid: {manifest_path}: {exc}") from exc
    return records


def _verify_baked_files(directory: Path) -> None:
    global _verified_manifest_directory
    if _verified_manifest_directory == directory:
        return
    records = _manifest_records(directory)
    for name in _REQUIRED_GRAMMARS:
        record = records.get(name)
        if record is None:
            raise ParserUnavailableError(f"Tree-sitter manifest does not contain required grammar {name!r}.")
        path = directory / str(record.get("filename", ""))
        if not path.is_file():
            raise ParserUnavailableError(f"Baked tree-sitter grammar is missing: {path}")
        data = path.read_bytes()
        expected_size = record.get("size")
        expected_hash = record.get("sha256")
        if len(data) != expected_size or hashlib.sha256(data).hexdigest() != expected_hash:
            raise ParserUnavailableError(
                f"Baked tree-sitter grammar failed its integrity check: {path}. Rebuild the image."
            )
    _verified_manifest_directory = directory


def _language_capsule(pointer: int) -> object:
    capsule_new = ctypes.pythonapi.PyCapsule_New
    capsule_new.restype = ctypes.py_object
    capsule_new.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_void_p]
    return capsule_new(pointer, b"tree_sitter.Language", None)


def _load_language(name: str) -> Language:
    if name not in _REQUIRED_GRAMMARS:
        raise ParserUnavailableError(f"Unsupported parser dialect {name!r}.")
    cached = _loaded_languages.get(name)
    if cached is not None:
        return cached
    with _loader_lock:
        cached = _loaded_languages.get(name)
        if cached is not None:
            return cached
        language = _load_baked_language(name) or _load_from_language_pack(name)
        _loaded_languages[name] = language
        return language


def _load_baked_language(name: str) -> Language | None:
    """Load a baked grammar, or return None when none is usable locally.

    A missing manifest means the deployment has no baked grammars (a local CLI
    install), and a platform-mismatched shared object (OSError) means the baked
    grammar was built for another OS/architecture — both fall back to the
    language pack. An integrity failure (size/hash mismatch) on a manifest that
    *is* present still hard-fails, so a corrupted container image is never
    silently replaced.
    """
    directory = grammar_directory()
    if not (directory / "lurith-grammars.json").is_file():
        # An explicitly configured grammar directory without its manifest is a
        # broken deployment (the bot/container case) and must fail loudly. An
        # unconfigured directory means a local CLI install with no baked
        # grammars, which falls back to the language pack.
        if _grammar_dir_configured():
            raise ParserUnavailableError(
                f"Tree-sitter grammar manifest is missing at {directory / 'lurith-grammars.json'}. "
                "The image is incomplete; rebuild it so scripts/bake_tree_sitter.py runs successfully."
            )
        return None
    _verify_baked_files(directory)
    path = directory / f"libtree_sitter_{name}.so"
    try:
        library = ctypes.CDLL(str(path))
        entrypoint = getattr(library, f"tree_sitter_{name}")
        entrypoint.restype = ctypes.c_void_p
        pointer = entrypoint()
        if not pointer:
            raise ParserUnavailableError(f"Grammar {name!r} returned a null language pointer: {path}")
        language = Language(_language_capsule(pointer))
    except OSError:
        # Wrong platform for the baked shared object (e.g. a Linux .so on
        # macOS/Windows) — the language pack provides a matching build.
        return None
    except (AttributeError, TypeError, ValueError) as exc:
        raise ParserUnavailableError(
            f"Unable to load baked tree-sitter grammar {name!r} from {path}: {exc}. "
            "No runtime download fallback is allowed; rebuild the image."
        ) from exc
    _loaded_libraries[name] = library
    return language


def _load_from_language_pack(name: str) -> Language:
    """Load a grammar from the locally installed tree-sitter-language-pack.

    This is a local, deterministic source (the pack ships grammars for the
    current platform) — it is only reached when no baked grammar is usable.
    """
    from tree_sitter_language_pack import PackConfig, configure, downloaded_languages, get_language, prefetch

    cache = _language_pack_cache_directory()
    cache.mkdir(parents=True, exist_ok=True)
    configure(PackConfig(cache_dir=str(cache)))
    if name not in downloaded_languages():
        prefetch([name])
    language = get_language(name)
    if language is None:
        raise ParserUnavailableError(f"tree-sitter-language-pack could not provide grammar {name!r}.")
    return language


def _get_parser(dialect: str) -> Parser:
    language_name = "luau" if dialect == "luau" else "lua"
    parsers = getattr(_thread_local, "parsers", None)
    if parsers is None:
        parsers = {}
        _thread_local.parsers = parsers
    parser = parsers.get(language_name)
    if parser is None:
        parser = Parser(_load_language(language_name))
        parsers[language_name] = parser
    return parser


def verify_parser_readiness() -> dict[str, str]:
    fixtures = {
        "lua": b"local value = 1\nreturn value\n",
        "luau": b"--!strict\nlocal value: number = 1\nvalue += 1\nreturn value\n",
    }
    ready: dict[str, str] = {}
    for name, fixture in fixtures.items():
        tree = Parser(_load_language(name)).parse(fixture)
        if tree.root_node.has_error:
            raise ParserUnavailableError(f"Baked {name} grammar failed its startup parse fixture.")
        ready[name] = str(grammar_directory() / f"libtree_sitter_{name}.so")
    return ready


def reset_parser_cache_for_tests() -> None:
    global _verified_manifest_directory
    _loaded_languages.clear()
    _loaded_libraries.clear()
    _verified_manifest_directory = None
    _thread_local.parsers = {}


def _first_error(root: Any) -> Any | None:
    stack = [root]
    while stack:
        node = stack.pop()
        if node.is_error or node.is_missing:
            return node
        if node.has_error:
            stack.extend(reversed(node.children))
    return None


def analyze_syntax(source: str, dialect: str) -> SyntaxAnalysis:
    encoded = source.encode("utf-8")
    tree = _get_parser(dialect).parse(encoded)
    if not tree.root_node.has_error:
        return SyntaxAnalysis(tree, False, None)

    error = _first_error(tree.root_node)
    if error is None:
        return SyntaxAnalysis(tree, True, "Source contains a syntax error.")
    row, column = error.start_point
    nearby = encoded[error.start_byte : min(error.end_byte, error.start_byte + 40)].decode("utf-8", "replace")
    if not nearby:
        nearby = "<missing token>"
    message = f"Syntax error near line {row + 1}, column {column + 1}: {nearby!r}"
    return SyntaxAnalysis(tree, True, message)


def require_valid_syntax(source: str, dialect: str) -> Any:
    analysis = analyze_syntax(source, dialect)
    if analysis.has_errors:
        raise SyntaxValidationError(analysis.error_message or "Source contains a syntax error.")
    return analysis.tree
