from __future__ import annotations

from typing import Any

from .vm import RandomLike
from .vm_profile import VmProfile, random_identifier


def _walk(root: Any):
    stack = [root]
    while stack:
        node = stack.pop()
        yield node
        stack.extend(reversed(node.named_children))


def _random_name(
    rng: RandomLike,
    used: set[str],
    profile: VmProfile,
    minimum: int = 6,
    maximum: int = 11,
) -> str:
    return random_identifier(rng, used, profile.name_style, minimum, maximum)


def _parameter_nodes(parameters: Any) -> list[Any]:
    result: list[Any] = []
    for child in parameters.named_children:
        if child.type == "identifier":
            result.append(child)
        elif child.type in {"parameter", "default_parameter"}:
            identifier = next((item for item in child.named_children if item.type == "identifier"), None)
            if identifier is not None:
                result.append(identifier)
    return result


def _field_children(node: Any, name: str) -> list[Any]:
    result: list[Any] = []
    for index, child in enumerate(node.children):
        if node.field_name_for_child(index) == name:
            result.append(child)
    return result


def _variable_list(node: Any) -> Any | None:
    for child in node.named_children:
        if child.type == "variable_list":
            return child
        if child.type in {"assignment_statement", "update_statement"}:
            nested = next((item for item in child.named_children if item.type == "variable_list"), None)
            if nested is not None:
                return nested
    return None


def _expression_list(node: Any) -> Any | None:
    for child in node.named_children:
        if child.type == "expression_list":
            return child
        if child.type in {"assignment_statement", "update_statement"}:
            nested = next((item for item in child.named_children if item.type == "expression_list"), None)
            if nested is not None:
                return nested
    return None


def _lua_string(value: str) -> str:
    escaped = value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r")
    return f'"{escaped}"'
