from __future__ import annotations

from dataclasses import dataclass

from .ir import ProgramIR


class FunctionVmError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class FunctionVmResult:
    source: str
    virtualized_functions: int
    profile: str | None
    automatically_virtualized: int
    ir_instruction_count: int
    bytecode_word_count: int
    runtime_prefix_bytes: int
    packed_bytecode_bytes: int
    fused_instruction_count: int


@dataclass(frozen=True, slots=True)
class CompiledFunction:
    handle: int
    guard_token: int
    sentinel_words: tuple[tuple[int, int], ...]
    constant_canaries: tuple[tuple[int, int, int], ...]
    code: list[int]
    program: ProgramIR
    parameters: list[str]
    has_vararg: bool
    body_start: int
    body_end: int
    box_count: int = 0
