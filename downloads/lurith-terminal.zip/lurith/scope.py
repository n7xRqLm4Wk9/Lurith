from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .lexer import Token
from .vm import RandomLike
from .vm_common import _parameter_nodes, _walk
from .vm_profile import NameStyle, random_identifier


@dataclass(slots=True)
class Binding:
    name: str
    declaration_start: int
    declaration_end: int
    visible_from: int
    scope_start: int
    scope_end: int
    depth: int
    replacement: str = ""


@dataclass(frozen=True, slots=True)
class RenameResult:
    tokens: list[Token]
    renamed_bindings: int
    renamed_occurrences: int


def _field_name(node: Any) -> str | None:
    parent = node.parent
    if parent is None:
        return None
    for index, child in enumerate(parent.children):
        if child.id == node.id:
            return parent.field_name_for_child(index)
    return None


def _depth(node: Any) -> int:
    result = 0
    current = node
    while current.parent is not None:
        result += 1
        current = current.parent
    return result


def _lexical_scope(node: Any) -> tuple[int, int, int]:
    current = node.parent
    while current is not None and current.type not in {"block", "chunk"}:
        current = current.parent
    if current is None:
        root = node
        while root.parent is not None:
            root = root.parent
        return 0, root.end_byte, 0

    end = current.end_byte
    # Lua locals declared in a repeat body remain visible in the `until` condition.
    if current.type == "block" and current.parent is not None and current.parent.type == "repeat_statement":
        end = current.parent.end_byte
    return current.start_byte, end, _depth(current)


def _direct_identifiers(node: Any) -> list[Any]:
    return [child for child in node.named_children if child.type == "identifier"]


def _variable_list(declaration: Any) -> Any | None:
    for child in declaration.named_children:
        if child.type == "variable_list":
            return child
        if child.type in {"assignment_statement", "update_statement"}:
            for grandchild in child.named_children:
                if grandchild.type == "variable_list":
                    return grandchild
    return None


def _node_text(source: bytes, node: Any) -> str:
    return source[node.start_byte : node.end_byte].decode("utf-8", "replace")


def _is_type_context(node: Any) -> bool:
    current = node.parent
    while current is not None:
        kind = current.type
        if (
            kind == "type_definition"
            or kind.endswith("_type")
            or kind
            in {
                "generic_type",
                "object_type",
                "function_type",
                "type_pack",
            }
        ):
            return True
        if kind in {
            "assignment_statement",
            "block",
            "chunk",
            "function_call",
            "binary_expression",
            "unary_expression",
        }:
            return False
        current = current.parent
    return False


def _is_nonvariable_identifier(node: Any, source: bytes) -> bool:
    parent = node.parent
    if parent is None:
        return True
    field = _field_name(node)
    if parent.type == "dot_index_expression" and field == "field":
        return True
    if parent.type == "method_index_expression" and field == "method":
        return True
    if parent.type == "field" and field == "name":
        field_source = source[parent.start_byte : parent.end_byte].lstrip()
        if not field_source.startswith(b"["):
            return True
    if parent.type in {"label_statement", "goto_statement"}:
        return True
    return _is_type_context(node)


def rename_locals(
    source: str,
    tokens: list[Token],
    tree: Any,
    rng: RandomLike,
    used_names: set[str],
    name_style: NameStyle = "underscore",
) -> RenameResult:
    encoded = source.encode("utf-8")
    bindings: list[Binding] = []
    declaration_spans: set[tuple[int, int]] = set()

    def add_binding(identifier: Any, visible_from: int, scope: tuple[int, int, int]) -> None:
        span = (identifier.start_byte, identifier.end_byte)
        if span in declaration_spans:
            return
        declaration_spans.add(span)
        bindings.append(
            Binding(
                name=_node_text(encoded, identifier),
                declaration_start=identifier.start_byte,
                declaration_end=identifier.end_byte,
                visible_from=visible_from,
                scope_start=scope[0],
                scope_end=scope[1],
                depth=scope[2],
            )
        )

    nodes = list(_walk(tree.root_node))
    for node in nodes:
        if node.type == "variable_declaration":
            names = _variable_list(node)
            if names is not None:
                scope = _lexical_scope(node)
                for identifier in _direct_identifiers(names):
                    add_binding(identifier, node.end_byte, scope)

        if node.type in {"function_declaration", "function_definition"}:
            body = node.child_by_field_name("body")
            parameters = node.child_by_field_name("parameters")
            if body is not None and parameters is not None:
                parameter_scope = (body.start_byte, body.end_byte, _depth(body))
                for identifier in _parameter_nodes(parameters):
                    add_binding(identifier, body.start_byte, parameter_scope)

            if node.type == "function_declaration":
                name = node.child_by_field_name("name")
                if name is not None and name.type == "identifier":
                    prefix = encoded[node.start_byte : name.start_byte].lstrip()
                    if prefix.startswith(b"local"):
                        add_binding(name, name.start_byte, _lexical_scope(node))

        if node.type == "for_statement":
            clause = node.child_by_field_name("clause")
            body = node.child_by_field_name("body")
            if clause is None or body is None:
                continue
            loop_scope = (body.start_byte, body.end_byte, _depth(body))
            if clause.type == "for_numeric_clause":
                identifier = clause.child_by_field_name("name")
                if identifier is not None:
                    add_binding(identifier, body.start_byte, loop_scope)
            elif clause.type == "for_generic_clause":
                names = next((child for child in clause.named_children if child.type == "variable_list"), None)
                if names is not None:
                    for identifier in _direct_identifiers(names):
                        add_binding(identifier, body.start_byte, loop_scope)

    # If a name appears in a type context, leave an identically named local untouched.
    # This conservatively handles Luau `typeof(localName)` even across grammar versions.
    protected_names = {
        _node_text(encoded, node) for node in nodes if node.type == "identifier" and _is_type_context(node)
    }

    active_bindings = [binding for binding in bindings if binding.name not in protected_names]
    for binding in active_bindings:
        binding.replacement = random_identifier(rng, used_names, name_style, 5, 10)

    replacements: dict[tuple[int, int], str] = {
        (binding.declaration_start, binding.declaration_end): binding.replacement for binding in active_bindings
    }

    for node in nodes:
        if node.type != "identifier":
            continue
        span = (node.start_byte, node.end_byte)
        if span in declaration_spans or _is_nonvariable_identifier(node, encoded):
            continue
        name = _node_text(encoded, node)
        candidates = [
            binding
            for binding in active_bindings
            if binding.name == name
            and binding.visible_from <= node.start_byte
            and binding.scope_start <= node.start_byte < binding.scope_end
        ]
        if candidates:
            binding = max(candidates, key=lambda item: (item.depth, item.visible_from))
            replacements[span] = binding.replacement

    renamed_tokens: list[Token] = []
    occurrences = 0
    for token in tokens:
        replacement = replacements.get((token.start_byte, token.end_byte))
        if replacement is None:
            if token.kind == "interpolated_string":
                inner = sorted(
                    (span, name)
                    for span, name in replacements.items()
                    if token.start_byte < span[0] and span[1] < token.end_byte
                )
                if inner:
                    # Identifiers inside Luau `…{expr}…` interpolations are part
                    # of a single string token, not standalone identifier tokens.
                    # Splice the renamed identifiers back into the raw token text
                    # (byte offsets, so non-ASCII prefixes stay aligned).
                    raw = token.value.encode("utf-8")
                    out = bytearray()
                    cursor = 0
                    for (start, end), name in inner:
                        out += raw[cursor : start - token.start_byte]
                        out += name.encode("utf-8")
                        cursor = end - token.start_byte
                    out += raw[cursor:]
                    renamed_tokens.append(
                        Token(
                            token.kind,
                            out.decode("utf-8"),
                            token.line,
                            token.column,
                            token.start_byte,
                            token.end_byte,
                        )
                    )
                    occurrences += len(inner)
                    continue
            renamed_tokens.append(token)
            continue
        renamed_tokens.append(
            Token(
                token.kind,
                replacement,
                token.line,
                token.column,
                token.start_byte,
                token.end_byte,
            )
        )
        occurrences += 1

    return RenameResult(renamed_tokens, len(active_bindings), occurrences)
