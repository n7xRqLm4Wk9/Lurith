from __future__ import annotations

from dataclasses import dataclass

from .ir import Instruction, Label, ProgramIR


@dataclass(frozen=True, slots=True)
class OptimizationResult:
    fused_instructions: int
    removed_instructions: int


def _instructions(items: list[Instruction | Label], index: int, count: int) -> list[Instruction] | None:
    window = items[index : index + count]
    if len(window) != count or any(not isinstance(item, Instruction) for item in window):
        return None
    return [item for item in window if isinstance(item, Instruction)]


def optimize_program_ir(program: ProgramIR, level: int) -> OptimizationResult:
    if level <= 0:
        return OptimizationResult(0, 0)
    items = program.instructions
    output: list[Instruction | Label] = []
    fused = 0
    removed = 0
    index = 0
    while index < len(items):
        window = _instructions(items, index, 4)
        if window is not None:
            first, second, third, fourth = window
            is_add = third.opcode == "ADD" or (third.opcode == "ALU_DUAL" and third.operands == (0,))
            is_eq = third.opcode == "EQ" or (third.opcode == "CMP_DUAL" and third.operands == (0,))
            if (
                first.opcode == "GET_LOCAL"
                and second.opcode == "CONST"
                and is_add
                and fourth.opcode == "SET_LOCAL"
            ):
                output.append(
                    Instruction(
                        "ADD_LOCAL_CONST_SET",
                        (first.operands[0], second.operands[0], fourth.operands[0]),
                    )
                )
                fused += 1
                removed += 3
                index += 4
                continue
            if level >= 2 and (
                first.opcode == "GET_LOCAL"
                and second.opcode == "GET_LOCAL"
                and is_add
                and fourth.opcode == "SET_LOCAL"
            ):
                output.append(
                    Instruction(
                        "ADD_LOCALS_SET",
                        (first.operands[0], second.operands[0], fourth.operands[0]),
                    )
                )
                fused += 1
                removed += 3
                index += 4
                continue
            if level >= 2 and (
                first.opcode == "GET_LOCAL"
                and second.opcode == "CONST"
                and is_eq
                and fourth.opcode == "JFALSE_POP"
            ):
                output.append(
                    Instruction(
                        "JNE_LOCAL_CONST",
                        (first.operands[0], second.operands[0], fourth.operands[0]),
                    )
                )
                fused += 1
                removed += 3
                index += 4
                continue
        output.append(items[index])
        index += 1

    program.instructions = output
    program.fused_instruction_count += fused
    return OptimizationResult(fused, removed)
