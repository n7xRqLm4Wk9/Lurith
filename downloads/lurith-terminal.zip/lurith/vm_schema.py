from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class InstructionSpec:
    operands: int | None
    minimum_stack: int
    fixed_effect: int | None = 0
    terminal: bool = False


BINARY_INSTRUCTIONS = (
    "ADD",
    "SUB",
    "MUL",
    "DIV",
    "MOD",
    "POW",
    "CONCAT",
    "EQ",
    "NE",
    "LT",
    "LE",
    "GT",
    "GE",
)

INSTRUCTION_SPECS: dict[str, InstructionSpec] = {
    "CONST": InstructionSpec(1, 0, 1),
    "TRUE": InstructionSpec(0, 0, 1),
    "FALSE": InstructionSpec(0, 0, 1),
    "NIL": InstructionSpec(0, 0, 1),
    "GET_LOCAL": InstructionSpec(1, 0, 1),
    "SET_LOCAL": InstructionSpec(1, 1, -1),
    "GET_EXT": InstructionSpec(1, 0, 1),
    "SET_EXT": InstructionSpec(1, 1, -1),
    "GET_BOX": InstructionSpec(1, 0, 1),
    "SET_BOX": InstructionSpec(1, 1, -1),
    # Closes the cells table on top of the stack over a template external,
    # producing `function(...) return template(cells, ...) end`. Net stack 0.
    "CLOSE_OVER": InstructionSpec(1, 1, 0),
    "POP": InstructionSpec(0, 1, -1),
    "DUP": InstructionSpec(0, 1, 1),
    "NEG": InstructionSpec(0, 1),
    "NOT": InstructionSpec(0, 1),
    "LEN": InstructionSpec(0, 1),
    "JUMP": InstructionSpec(1, 0),
    "JFALSE_POP": InstructionSpec(1, 1, -1),
    "JFALSE_KEEP": InstructionSpec(1, 1),
    "JTRUE_KEEP": InstructionSpec(1, 1),
    "NEW_TABLE": InstructionSpec(0, 0, 1),
    "GET_INDEX": InstructionSpec(0, 2, -1),
    "SET_INDEX": InstructionSpec(0, 3, -3),
    "SET_INDEX_KEEP": InstructionSpec(0, 3, -2),
    "GET_METHOD": InstructionSpec(1, 1, 1),
    "CALL": InstructionSpec(1, 1, None),
    "CALL_PACK": InstructionSpec(1, 1, None),
    "CALL_VARARG": InstructionSpec(1, 1, None),
    "CALL_VARARG_PACK": InstructionSpec(1, 1, None),
    "CALL_EXPANDED": InstructionSpec(1, 2, None),
    "CALL_EXPANDED_PACK": InstructionSpec(1, 2, None),
    "TAIL_CALL": InstructionSpec(1, 1, None, True),
    "TAIL_CALL_VARARG": InstructionSpec(1, 1, None, True),
    "TAIL_CALL_EXPANDED": InstructionSpec(1, 2, None, True),
    "CALL_MULTI3": InstructionSpec(4, 1, None),
    "PACK_VARARG": InstructionSpec(0, 0, 1),
    "EXPAND_FIXED": InstructionSpec(1, 1, None),
    "TABLE_APPEND_PACK": InstructionSpec(1, 2, -1),
    "RETURN_EXPANDED": InstructionSpec(1, 1, None, True),
    "GENERIC_NEXT": InstructionSpec(None, 0),
    "COERCE_NUMBER": InstructionSpec(1, 0),
    "CHECK_STEP": InstructionSpec(1, 0),
    "RETURN": InstructionSpec(0, 1, 0, True),
    # Bare `return` / function fallthrough: zero values (Lua semantics).
    "RETURN_NONE": InstructionSpec(0, 0, 0, True),
    "RETURN_MULTI": InstructionSpec(1, 1, None, True),
    "GET_VARARG": InstructionSpec(1, 0, 1),
    "RETURN_VARARG": InstructionSpec(0, 0, 0, True),
    "ADD_LOCAL_CONST_SET": InstructionSpec(3, 0),
    "ADD_LOCALS_SET": InstructionSpec(3, 0),
    "JNE_LOCAL_CONST": InstructionSpec(3, 0),
    # Aliased opcodes: two operations share one opcode value and are resolved
    # by an operand-carried discriminant (0/1) at runtime.
    "ALU_DUAL": InstructionSpec(1, 2, -1),
    "CMP_DUAL": InstructionSpec(1, 2, -1),
}
INSTRUCTION_SPECS.update({name: InstructionSpec(0, 2, -1) for name in BINARY_INSTRUCTIONS})
ALL_INSTRUCTIONS = tuple(INSTRUCTION_SPECS)
DYNAMIC_RESULT_INSTRUCTIONS = frozenset(
    {
        "CALL_PACK",
        "CALL_VARARG_PACK",
        "CALL_EXPANDED",
        "CALL_EXPANDED_PACK",
        "TAIL_CALL_EXPANDED",
        "PACK_VARARG",
        "EXPAND_FIXED",
        "TABLE_APPEND_PACK",
        "RETURN_EXPANDED",
    }
)


def instruction_effect(opcode: str, operands: tuple[int, ...]) -> int:
    spec = INSTRUCTION_SPECS[opcode]
    if spec.fixed_effect is not None:
        return spec.fixed_effect
    if opcode in {"CALL", "CALL_PACK", "CALL_VARARG", "CALL_VARARG_PACK"}:
        return -operands[0]
    if opcode in {"CALL_EXPANDED", "CALL_EXPANDED_PACK"}:
        return -(operands[0] + 1)
    if opcode in {"TAIL_CALL", "TAIL_CALL_VARARG", "TAIL_CALL_EXPANDED", "RETURN_EXPANDED"}:
        return 0
    if opcode == "CALL_MULTI3":
        return -(operands[0] + 1)
    if opcode == "EXPAND_FIXED":
        return operands[0] - 1
    if opcode == "RETURN_MULTI":
        return 0
    raise ValueError(f"No stack effect defined for {opcode}")


def instruction_minimum_stack(opcode: str, operands: tuple[int, ...]) -> int:
    if opcode in {
        "CALL",
        "CALL_PACK",
        "CALL_VARARG",
        "CALL_VARARG_PACK",
        "TAIL_CALL",
        "TAIL_CALL_VARARG",
        "CALL_MULTI3",
    }:
        return operands[0] + 1
    if opcode in {"CALL_EXPANDED", "CALL_EXPANDED_PACK", "TAIL_CALL_EXPANDED"}:
        return operands[0] + 2
    if opcode == "RETURN_EXPANDED":
        return operands[0] + 1
    if opcode == "RETURN_MULTI":
        return operands[0]
    return INSTRUCTION_SPECS[opcode].minimum_stack
