from __future__ import annotations

import contextlib
import json
import os
import re
import tempfile
import threading
import time
from collections.abc import Collection
from dataclasses import dataclass
from pathlib import Path

from .config import CONFIGS


def _atomic_write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        text=True,
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, separators=(",", ":"), sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        with contextlib.suppress(OSError):
            directory_flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
            directory_descriptor = os.open(path.parent, directory_flags)
            try:
                os.fsync(directory_descriptor)
            finally:
                os.close(directory_descriptor)
    finally:
        with contextlib.suppress(FileNotFoundError):
            temporary.unlink()


class UserConfigStore:
    """Small atomic JSON store for per-user config selections.

    Discord IDs are stored as strings to avoid JSON number interoperability issues. Invalid
    entries are ignored on load, and the file is replaced atomically after each change.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        max_entries: int = 25_000,
        allowed_values: Collection[str] = CONFIGS,
    ) -> None:
        self.path = Path(path)
        self.max_entries = max_entries
        self.allowed_values = frozenset(allowed_values)
        if not self.allowed_values:
            raise ValueError("allowed_values cannot be empty")
        self._lock = threading.Lock()
        self._values = self._load()

    def _load(self) -> dict[str, str]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError, UnicodeError):
            return {}
        if not isinstance(raw, dict):
            return {}
        valid: dict[str, str] = {}
        for user_id, config in raw.items():
            if str(user_id).isdigit() and config in self.allowed_values:
                valid[str(user_id)] = config
        return dict(list(valid.items())[-self.max_entries :])

    def get(self, user_id: int, default: str) -> str:
        with self._lock:
            return self._values.get(str(user_id), default)

    def set(self, user_id: int, config: str) -> None:
        if config not in self.allowed_values:
            raise ValueError(f"Unknown selection {config!r}")
        key = str(user_id)
        with self._lock:
            if key not in self._values and len(self._values) >= self.max_entries:
                self._values.pop(next(iter(self._values)))
            self._values[key] = config
            self._save_locked()

    def delete(self, user_id: int) -> bool:
        with self._lock:
            removed = self._values.pop(str(user_id), None) is not None
            if removed:
                self._save_locked()
            return removed

    def __len__(self) -> int:
        with self._lock:
            return len(self._values)

    def _save_locked(self) -> None:
        _atomic_write_json(self.path, self._values)


class PersistentCooldownStore:
    """Atomic per-user cooldowns that survive restarts on persistent storage."""

    def __init__(self, path: str | Path, *, window_seconds: float = 10.0, max_entries: int = 50_000) -> None:
        self.path = Path(path)
        self.window_seconds = window_seconds
        self.max_entries = max_entries
        self._lock = threading.Lock()
        self._values = self._load()

    def _load(self) -> dict[str, float]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError, UnicodeError):
            return {}
        if not isinstance(raw, dict):
            return {}
        valid = {
            str(user_id): float(timestamp)
            for user_id, timestamp in raw.items()
            if str(user_id).isdigit() and isinstance(timestamp, int | float)
        }
        return dict(sorted(valid.items(), key=lambda item: item[1])[-self.max_entries :])

    def try_acquire(
        self,
        user_id: int,
        *,
        now: float | None = None,
        window_seconds: float | None = None,
    ) -> float:
        window = self.window_seconds if window_seconds is None else float(window_seconds)
        current = time.time() if now is None else now
        key = str(user_id)
        with self._lock:
            previous = self._values.get(key)
            if previous is not None:
                remaining = window - (current - previous)
                if remaining > 0:
                    return min(remaining, window)
            if key not in self._values and len(self._values) >= self.max_entries:
                oldest = min(self._values, key=self._values.__getitem__)
                self._values.pop(oldest, None)
            self._values[key] = current
            self._save_locked()
            return 0.0

    def remaining(self, user_id: int, *, now: float | None = None, window_seconds: float | None = None) -> float:
        window = self.window_seconds if window_seconds is None else float(window_seconds)
        current = time.time() if now is None else now
        with self._lock:
            previous = self._values.get(str(user_id))
            if previous is None:
                return 0.0
            return max(0.0, min(window, window - (current - previous)))

    def delete(self, user_id: int) -> bool:
        with self._lock:
            removed = self._values.pop(str(user_id), None) is not None
            if removed:
                self._save_locked()
            return removed

    def __len__(self) -> int:
        with self._lock:
            return len(self._values)

    def _save_locked(self) -> None:
        _atomic_write_json(self.path, self._values)


@dataclass(frozen=True, slots=True)
class BlacklistEntry:
    user_id: int
    reason: str
    added_by: int
    added_at: float


class BlacklistStore:
    """Persistent owner-managed deny list for Discord user IDs."""

    def __init__(self, path: str | Path, *, max_entries: int = 100_000) -> None:
        self.path = Path(path)
        self.max_entries = max_entries
        self._lock = threading.Lock()
        self._values = self._load()

    def _load(self) -> dict[str, BlacklistEntry]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError, UnicodeError):
            return {}
        if not isinstance(raw, dict):
            return {}
        entries: dict[str, BlacklistEntry] = {}
        for user_id, value in raw.items():
            if not str(user_id).isdigit() or not isinstance(value, dict):
                continue
            try:
                entry = BlacklistEntry(
                    user_id=int(user_id),
                    reason=str(value.get("reason", "No reason supplied"))[:300],
                    added_by=int(value.get("added_by", 0)),
                    added_at=float(value.get("added_at", 0)),
                )
            except (TypeError, ValueError):
                continue
            entries[str(entry.user_id)] = entry
        ordered = sorted(entries.values(), key=lambda entry: entry.added_at)
        return {str(entry.user_id): entry for entry in ordered[-self.max_entries :]}

    def get(self, user_id: int) -> BlacklistEntry | None:
        with self._lock:
            return self._values.get(str(user_id))

    def add(self, user_id: int, reason: str, added_by: int, *, now: float | None = None) -> BlacklistEntry:
        if user_id <= 0 or added_by <= 0:
            raise ValueError("Discord user IDs must be positive integers")
        clean_reason = " ".join(reason.split())[:300] or "No reason supplied"
        entry = BlacklistEntry(user_id, clean_reason, added_by, time.time() if now is None else now)
        with self._lock:
            if str(user_id) not in self._values and len(self._values) >= self.max_entries:
                oldest = min(self._values.values(), key=lambda value: value.added_at)
                self._values.pop(str(oldest.user_id), None)
            self._values[str(user_id)] = entry
            self._save_locked()
        return entry

    def remove(self, user_id: int) -> bool:
        with self._lock:
            removed = self._values.pop(str(user_id), None) is not None
            if removed:
                self._save_locked()
            return removed

    def entries(self) -> list[BlacklistEntry]:
        with self._lock:
            return sorted(self._values.values(), key=lambda entry: entry.added_at, reverse=True)

    def __len__(self) -> int:
        with self._lock:
            return len(self._values)

    def _save_locked(self) -> None:
        payload = {
            user_id: {
                "reason": entry.reason,
                "added_by": entry.added_by,
                "added_at": entry.added_at,
            }
            for user_id, entry in self._values.items()
        }
        _atomic_write_json(self.path, payload)


class UsageStatsStore:
    """Small persistent aggregate counters; no source or URL contents are stored."""

    _DEFAULTS = {
        "successful_jobs": 0,
        "rejected_jobs": 0,
        "input_bytes": 0,
        "output_bytes": 0,
    }

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self._lock = threading.Lock()
        self._values = self._load()

    def _load(self) -> dict[str, int]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError, UnicodeError):
            return dict(self._DEFAULTS)
        if not isinstance(raw, dict):
            return dict(self._DEFAULTS)
        values: dict[str, int] = {}
        for key, default in self._DEFAULTS.items():
            try:
                values[key] = max(0, int(raw.get(key, default)))
            except (TypeError, ValueError):
                values[key] = default
        return values

    def record_success(self, input_bytes: int, output_bytes: int) -> None:
        with self._lock:
            self._values["successful_jobs"] += 1
            self._values["input_bytes"] += max(0, input_bytes)
            self._values["output_bytes"] += max(0, output_bytes)
            self._save_locked()

    def record_rejection(self) -> None:
        with self._lock:
            self._values["rejected_jobs"] += 1
            self._save_locked()

    def snapshot(self) -> dict[str, int]:
        with self._lock:
            return dict(self._values)

    def reset(self) -> None:
        with self._lock:
            self._values = dict(self._DEFAULTS)
            self._save_locked()

    def _save_locked(self) -> None:
        _atomic_write_json(self.path, self._values)


class IdSetStore:
    """Persistent set of positive integer IDs (user or server IDs), stored atomically.

    Insertion order is preserved for stable eviction; lookups return sorted copies.
    """

    def __init__(self, path: str | Path, *, max_entries: int = 100_000) -> None:
        self.path = Path(path)
        self._capacity = max_entries
        self._lock = threading.Lock()
        self._values = self._load()

    def _load(self) -> list[int]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError, UnicodeError):
            return []
        if not isinstance(raw, dict) or not isinstance(raw.get("ids"), list):
            return []
        values: list[int] = []
        for value in raw["ids"]:
            try:
                parsed = int(value)
            except (TypeError, ValueError):
                continue
            if parsed > 0 and parsed not in values:
                values.append(parsed)
        return values[-self._capacity :]

    def contains(self, item_id: int) -> bool:
        with self._lock:
            return item_id in self._values

    def add(self, item_id: int) -> bool:
        if item_id <= 0:
            raise ValueError("IDs must be positive integers")
        with self._lock:
            if item_id in self._values:
                return False
            self._values.append(item_id)
            if len(self._values) > self._capacity:
                self._values = self._values[-self._capacity :]
            self._save_locked()
            return True

    def remove(self, item_id: int) -> bool:
        with self._lock:
            if item_id not in self._values:
                return False
            self._values.remove(item_id)
            self._save_locked()
            return True

    def ids(self) -> list[int]:
        with self._lock:
            return sorted(self._values)

    def __len__(self) -> int:
        with self._lock:
            return len(self._values)

    def _save_locked(self) -> None:
        _atomic_write_json(self.path, {"ids": self._values})


class UserTextStore:
    """Per-user free-text setting (e.g. a custom watermark tag)."""

    def __init__(self, path: str | Path, *, max_entries: int = 25_000, max_length: int = 200) -> None:
        self.path = Path(path)
        self.max_entries = max_entries
        self.max_length = max_length
        self._lock = threading.Lock()
        self._values = self._load()

    def _load(self) -> dict[str, str]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError, UnicodeError):
            return {}
        if not isinstance(raw, dict):
            return {}
        valid: dict[str, str] = {}
        for user_id, value in raw.items():
            if str(user_id).isdigit() and isinstance(value, str):
                valid[str(user_id)] = value[: self.max_length]
        return dict(list(valid.items())[-self.max_entries :])

    def get(self, user_id: int, default: str | None = None) -> str | None:
        with self._lock:
            return self._values.get(str(user_id), default)

    def set(self, user_id: int, value: str) -> None:
        key = str(user_id)
        with self._lock:
            self._values[key] = value[: self.max_length]
            if len(self._values) > self.max_entries:
                self._values = dict(list(self._values.items())[-self.max_entries :])
            self._save_locked()

    def delete(self, user_id: int) -> bool:
        with self._lock:
            removed = self._values.pop(str(user_id), None) is not None
            if removed:
                self._save_locked()
            return removed

    def __len__(self) -> int:
        with self._lock:
            return len(self._values)

    def _save_locked(self) -> None:
        _atomic_write_json(self.path, self._values)


class PresetStore:
    """Per-user named (config, vm_family) presets."""

    _NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")

    def __init__(self, path: str | Path, *, max_users: int = 25_000, max_per_user: int = 50) -> None:
        self.path = Path(path)
        self.max_users = max_users
        self.max_per_user = max_per_user
        self._lock = threading.Lock()
        self._values = self._load()

    def _load(self) -> dict[str, dict[str, dict[str, str]]]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError, UnicodeError):
            return {}
        if not isinstance(raw, dict):
            return {}
        valid: dict[str, dict[str, dict[str, str]]] = {}
        for user_id, presets in raw.items():
            if not str(user_id).isdigit() or not isinstance(presets, dict):
                continue
            user_valid: dict[str, dict[str, str]] = {}
            for name, value in presets.items():
                if not self._NAME_RE.fullmatch(str(name)) or not isinstance(value, dict):
                    continue
                config = value.get("config")
                vm_family = value.get("vm_family")
                if isinstance(config, str) and isinstance(vm_family, str):
                    user_valid[str(name)] = {"config": config, "vm_family": vm_family}
            if user_valid:
                valid[str(user_id)] = dict(list(user_valid.items())[-self.max_per_user :])
        return dict(list(valid.items())[-self.max_users :])

    def set(self, user_id: int, name: str, config: str, vm_family: str) -> None:
        if not self._NAME_RE.fullmatch(name):
            raise ValueError("Preset names must be 1-32 letters, digits, `-`, or `_`.")
        key = str(user_id)
        with self._lock:
            user_presets = self._values.setdefault(key, {})
            if name not in user_presets and len(user_presets) >= self.max_per_user:
                user_presets.pop(next(iter(user_presets)))
            user_presets[name] = {"config": config, "vm_family": vm_family}
            if len(self._values) > self.max_users:
                self._values = dict(list(self._values.items())[-self.max_users :])
            self._save_locked()

    def get(self, user_id: int, name: str) -> tuple[str, str] | None:
        with self._lock:
            value = self._values.get(str(user_id), {}).get(name)
            if value is None:
                return None
            return value["config"], value["vm_family"]

    def delete(self, user_id: int, name: str) -> bool:
        with self._lock:
            user_presets = self._values.get(str(user_id))
            if not user_presets or name not in user_presets:
                return False
            user_presets.pop(name)
            if not user_presets:
                self._values.pop(str(user_id), None)
            self._save_locked()
            return True

    def list(self, user_id: int) -> dict[str, tuple[str, str]]:
        with self._lock:
            return {
                name: (value["config"], value["vm_family"])
                for name, value in self._values.get(str(user_id), {}).items()
            }

    def __len__(self) -> int:
        with self._lock:
            return sum(len(presets) for presets in self._values.values())

    def _save_locked(self) -> None:
        _atomic_write_json(self.path, self._values)


class JobHistoryStore:
    """Per-user recent-job records (newest first), capped per user."""

    def __init__(self, path: str | Path, *, max_entries_per_user: int = 20, max_users: int = 25_000) -> None:
        self.path = Path(path)
        self.max_entries_per_user = max_entries_per_user
        self.max_users = max_users
        self._lock = threading.Lock()
        self._values = self._load()

    def _load(self) -> dict[str, list[dict]]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError, UnicodeError):
            return {}
        if not isinstance(raw, dict):
            return {}
        valid: dict[str, list[dict]] = {}
        for user_id, records in raw.items():
            if not str(user_id).isdigit() or not isinstance(records, list):
                continue
            entries = [record for record in records if isinstance(record, dict)]
            valid[str(user_id)] = entries[-self.max_entries_per_user :]
        return dict(list(valid.items())[-self.max_users :])

    def record(self, user_id: int, entry: dict) -> None:
        key = str(user_id)
        with self._lock:
            records = self._values.setdefault(key, [])
            records.append(entry)
            del records[: -self.max_entries_per_user]
            if len(self._values) > self.max_users:
                self._values = dict(list(self._values.items())[-self.max_users :])
            self._save_locked()

    def entries(self, user_id: int) -> list[dict]:
        with self._lock:
            return list(reversed(self._values.get(str(user_id), [])))

    def __len__(self) -> int:
        with self._lock:
            return sum(len(records) for records in self._values.values())

    def _save_locked(self) -> None:
        _atomic_write_json(self.path, self._values)
