from __future__ import annotations

import math
import multiprocessing
import sys
from dataclasses import asdict
from multiprocessing.connection import Connection
from typing import Any

from .obfuscator import ObfuscationResult, Obfuscator


class JobTimeoutError(ValueError):
    pass


class JobProcessError(ValueError):
    pass


def _apply_unix_limits(timeout_seconds: float, memory_mb: int) -> None:
    if sys.platform != "linux":
        return
    try:
        import resource

        memory_bytes = memory_mb * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (memory_bytes, memory_bytes))
        cpu_seconds = max(2, math.ceil(timeout_seconds) + 1)
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_seconds, cpu_seconds + 1))
    except (ImportError, OSError, ValueError):
        # The parent still enforces wall-clock timeout even when a host refuses rlimits.
        pass


def _job_process(
    connection: Connection,
    source: str,
    config: str,
    dialect: str,
    environment_assertions: str,
    vm_family: str,
    timeout_seconds: float,
    memory_mb: int,
) -> None:
    try:
        _apply_unix_limits(timeout_seconds, memory_mb)
        result = Obfuscator(
            config,
            dialect,
            environment_assertions=environment_assertions,
            vm_family=vm_family,
        ).obfuscate(source)
        connection.send(("ok", asdict(result)))
    except BaseException as exc:  # Child boundary: serialize errors rather than crashing silently.
        connection.send(("error", type(exc).__name__, str(exc)[:2000]))
    finally:
        connection.close()


def _stop_process(process: multiprocessing.Process) -> None:
    if process.is_alive():
        process.terminate()
        process.join(timeout=2)
    if process.is_alive() and hasattr(process, "kill"):
        process.kill()
        process.join(timeout=2)


def run_isolated_obfuscation(
    source: str,
    config: str,
    dialect: str,
    *,
    timeout_seconds: float = 20.0,
    memory_mb: int = 512,
    environment_assertions: str = "auto",
    vm_family: str = "auto",
) -> ObfuscationResult:
    """Run one obfuscation in a killable child process with time and memory limits."""
    if not 1 <= timeout_seconds <= 120:
        raise ValueError("timeout_seconds must be between 1 and 120")
    if not 128 <= memory_mb <= 4096:
        raise ValueError("memory_mb must be between 128 and 4096")
    if environment_assertions not in {"off", "roblox", "auto"}:
        raise ValueError("environment_assertions must be 'off', 'roblox', or 'auto'")

    context = multiprocessing.get_context("spawn")
    parent, child = context.Pipe(duplex=False)
    process = context.Process(
        target=_job_process,
        args=(child, source, config, dialect, environment_assertions, vm_family, timeout_seconds, memory_mb),
        name="lurith-job",
        daemon=True,
    )
    process.start()
    child.close()

    try:
        if not parent.poll(timeout_seconds):
            _stop_process(process)
            raise JobTimeoutError(f"Obfuscation exceeded the {timeout_seconds:g}-second job limit.")
        try:
            payload: tuple[Any, ...] = parent.recv()
        except EOFError as exc:
            raise JobProcessError(f"Obfuscation worker exited unexpectedly with code {process.exitcode}.") from exc
        process.join(timeout=2)
        if payload[0] == "ok":
            return ObfuscationResult(**payload[1])
        _, error_type, message = payload
        raise JobProcessError(f"{error_type}: {message}")
    finally:
        parent.close()
        _stop_process(process)
        process.close()
