from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TypeAlias


@dataclass(frozen=True, slots=True)
class Label:
    identifier: int


Operand: TypeAlias = int | Label


@dataclass(frozen=True, slots=True)
class Instruction:
    opcode: str
    operands: tuple[Operand, ...] = ()


@dataclass(slots=True)
class ProgramIR:
    instructions: list[Instruction | Label] = field(default_factory=list)
    constants: list[str] = field(default_factory=list)
    externals: list[str] = field(default_factory=list)
    local_count: int = 0
    parameter_count: int = 0
    returns_multiple: bool = False
    fused_instruction_count: int = 0
    box_count: int = 0


class IRBuilder:
    def __init__(self) -> None:
        self.program = ProgramIR()
        self._next_label = 0
        self._constant_indices: dict[str, int] = {}
        self._external_indices: dict[str, int] = {}

    def new_label(self) -> Label:
        label = Label(self._next_label)
        self._next_label += 1
        return label

    def mark(self, label: Label) -> None:
        self.program.instructions.append(label)

    def emit(self, opcode: str, *operands: Operand) -> int:
        self.program.instructions.append(Instruction(opcode, tuple(operands)))
        return len(self.program.instructions) - 1

    def constant(self, source_literal: str) -> int:
        existing = self._constant_indices.get(source_literal)
        if existing is not None:
            return existing
        self.program.constants.append(source_literal)
        index = len(self.program.constants)
        self._constant_indices[source_literal] = index
        return index

    def external(self, name: str) -> int:
        existing = self._external_indices.get(name)
        if existing is not None:
            return existing
        self.program.externals.append(name)
        index = len(self.program.externals)
        self._external_indices[name] = index
        return index

    def assemble(
        self,
        opcodes: dict[str, int],
        *,
        encode_operand: Callable[[int], int] | None = None,
        operand_transform: Callable[[str, int], int] | None = None,
    ) -> list[int]:
        label_positions: dict[Label, int] = {}
        instruction_pointer = 1
        for item in self.program.instructions:
            if isinstance(item, Label):
                label_positions[item] = instruction_pointer
            else:
                instruction_pointer += 1 + len(item.operands)

        output: list[int] = []
        for item in self.program.instructions:
            if isinstance(item, Label):
                continue
            try:
                output.append(opcodes[item.opcode])
            except KeyError as exc:
                raise ValueError(f"No opcode assigned for IR instruction {item.opcode!r}") from exc
            for operand in item.operands:
                if isinstance(operand, Label):
                    try:
                        value = label_positions[operand]
                    except KeyError as exc:
                        raise ValueError(f"Unmarked IR label {operand.identifier}") from exc
                else:
                    value = operand
                    if operand_transform is not None:
                        value = operand_transform(item.opcode, value)
                output.append(encode_operand(value) if encode_operand is not None else value)
        return output
