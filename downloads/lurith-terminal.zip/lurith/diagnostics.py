from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class SourceRange:
    start_line: int
    start_column: int
    end_line: int
    end_column: int

    def display(self) -> str:
        if self.start_line == self.end_line:
            return f"line {self.start_line}:{self.start_column}-{self.end_column}"
        return f"line {self.start_line}:{self.start_column} to {self.end_line}:{self.end_column}"


@dataclass(frozen=True, slots=True)
class CompilerDiagnostic:
    feature: str
    location: SourceRange
    excerpt: str
    suggestion: str

    def format(self) -> str:
        return (
            f"VM lowering rejected {self.feature} at {self.location.display()}.\n"
            f"Source: {self.excerpt}\n"
            f"Suggestion: {self.suggestion}\n"
            "Automatic mode leaves this function native; remove --@lurith-vm to allow that fallback."
        )


_SUGGESTIONS = (
    ("multi-return", "Store the required return values explicitly, or leave this function outside the VM."),
    ("vararg", "Use a direct vararg return/forwarding form, or leave the function outside the VM."),
    ("closure capture", "Pass the captured value as a parameter, or leave the outer function native."),
    ("recursive", "Keep recursive closure logic native or move recursion into a separately protected function."),
    ("assignment target", "Split the assignment into supported single local or single indexed assignments."),
    ("generic for", "Use one iterator-factory call or an explicit iterator/state/control triple."),
    ("more than eight", "Reduce the fixed value count to eight or leave the function native."),
    ("coroutine", "Keep yielding code outside the VM boundary."),
    ("function call", "Store the call result in a scalar local first, or leave the function native."),
)


def suggestion_for(feature: str) -> str:
    lowered = feature.lower()
    for marker, suggestion in _SUGGESTIONS:
        if marker in lowered:
            return suggestion
    return "Rewrite this construct into smaller scalar operations or leave the function outside the VM."


def diagnostic_for_node(source: bytes, node: Any, feature: str) -> CompilerDiagnostic:
    start_row, start_column = node.start_point
    end_row, end_column = node.end_point
    decoded = source.decode("utf-8", "replace")
    lines = decoded.splitlines()
    excerpt = lines[start_row].strip() if 0 <= start_row < len(lines) else "<source unavailable>"
    if len(excerpt) > 160:
        excerpt = excerpt[:157] + "..."
    return CompilerDiagnostic(
        feature=feature,
        location=SourceRange(start_row + 1, start_column + 1, end_row + 1, end_column + 1),
        excerpt=excerpt,
        suggestion=suggestion_for(feature),
    )
