from __future__ import annotations

from dataclasses import dataclass


class VmFamilyError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class VmFamilySpec:
    name: str
    description: str
    minimum_polymorphism_level: int
    dispatcher: str | None
    packed_bytecode: bool | None
    integrity_family: str | None
    execution_style: str | None

    def validate_level(self, level: int, config_name: str) -> None:
        if level < self.minimum_polymorphism_level:
            raise VmFamilyError(
                f"VM family {self.name!r} requires config "
                f"{'high or very-high' if self.minimum_polymorphism_level >= 3 else 'normal or higher'}; "
                f"{config_name!r} does not expose the required existing profile features."
            )


VM_FAMILIES: dict[str, VmFamilySpec] = {
    "auto": VmFamilySpec(
        name="auto",
        description="Use the selected protection config's existing randomized VM profile family.",
        minimum_polymorphism_level=0,
        dispatcher=None,
        packed_bytecode=None,
        integrity_family=None,
        execution_style=None,
    ),
    "classic": VmFamilySpec(
        name="classic",
        description="Existing linear dispatcher, table bytecode, and rolling integrity family.",
        minimum_polymorphism_level=0,
        dispatcher="linear",
        packed_bytecode=False,
        integrity_family="rolling",
        execution_style="inline",
    ),
    "balanced": VmFamilySpec(
        name="balanced",
        description="Existing binary dispatcher, table bytecode, and Fletcher integrity family.",
        minimum_polymorphism_level=1,
        dispatcher="binary",
        packed_bytecode=False,
        integrity_family="fletcher",
        execution_style="inline",
    ),
    "packed": VmFamilySpec(
        name="packed",
        description="Existing bucket dispatcher, packed bytecode, and Fletcher integrity family.",
        minimum_polymorphism_level=3,
        dispatcher="bucket",
        packed_bytecode=True,
        integrity_family="fletcher",
        execution_style="inline",
    ),
    "staged": VmFamilySpec(
        name="staged",
        description=(
            "Staged fetch/execute state with grouped ALU handlers, bucket dispatch, table code, and Fletcher integrity."
        ),
        minimum_polymorphism_level=3,
        dispatcher="bucket",
        packed_bytecode=False,
        integrity_family="fletcher",
        execution_style="staged",
    ),
}


def normalize_vm_family(name: str) -> str:
    return name.strip().lower().replace("_", "-").replace(" ", "-")


def get_vm_family(name: str) -> VmFamilySpec:
    normalized = normalize_vm_family(name)
    try:
        return VM_FAMILIES[normalized]
    except KeyError as exc:
        valid = ", ".join(VM_FAMILIES)
        raise VmFamilyError(f"Unknown VM family {name!r}. Choose one of: {valid}") from exc
