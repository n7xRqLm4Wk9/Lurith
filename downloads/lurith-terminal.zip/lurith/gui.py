"""Lurith desktop app: a small Tkinter window for picking a folder (or files),
choosing protection settings, and obfuscating everything in one click.

Run with `python -m lurith.gui`, or use the bundled launcher (`Lurith.bat` on
Windows). Tkinter ships with the standard Python install on Windows and macOS,
so there is no extra dependency.
"""

from __future__ import annotations

import contextlib
import os
import queue
import subprocess
import sys
import threading
from pathlib import Path

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    _TK_AVAILABLE = True
except Exception:  # noqa: BLE001 — ImportError on a Python without Tcl/Tk, or a headless server
    tk = None
    _TK_AVAILABLE = False

from lurith import CONFIGS, VM_FAMILIES, __version__
from lurith.gui_core import BatchSettings, count_sources, obfuscate_batch
from lurith.syntax import ParserUnavailableError, verify_parser_readiness

BG = "#0b0b11"
CARD = "#14141d"
FIELD = "#1b1b28"
FG = "#ececf4"
MUTED = "#9c9cb0"
FAINT = "#6b6b80"
ACCENT = "#8b5cf6"
ACCENT_DARK = "#7c3aed"
ACCENT_2 = "#ec4899"
OK = "#34d399"
ERR = "#f87171"
WARN = "#fbbf24"


def _asset_path(name: str) -> Path | None:
    """Locate a bundled asset: inside a PyInstaller onefile bundle, next to the
    installed package, or in the current working directory (the terminal zip)."""
    candidates: list[Path] = []
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        candidates.append(Path(meipass) / "assets" / name)
    candidates.append(Path(__file__).resolve().parent.parent / "assets" / name)
    candidates.append(Path.cwd() / "assets" / name)
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


class LurithApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.paths: list[Path] = []
        self.events: queue.Queue[tuple] = queue.Queue()
        self.running = False
        self._photo = None
        self._logo = None
        self._style_ui()
        self._build_ui()
        self.root.after(100, self._poll)
        self._warm_engine()

    # ---------------------------------------------------------------- theme
    def _style_ui(self) -> None:
        style = ttk.Style()
        with contextlib.suppress(tk.TclError):
            style.theme_use("clam")
        style.configure(
            "TCombobox",
            fieldbackground=FIELD,
            background=FIELD,
            foreground=FG,
            arrowcolor=FG,
            bordercolor="#2a2a3a",
            lightcolor=FIELD,
            darkcolor=FIELD,
            padding=4,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", FIELD)],
            foreground=[("readonly", FG)],
            selectbackground=[("readonly", FIELD)],
            selectforeground=[("readonly", FG)],
        )
        style.configure(
            "TProgressbar",
            background=ACCENT,
            troughcolor=FIELD,
            bordercolor=FIELD,
            lightcolor=ACCENT,
            darkcolor=ACCENT,
        )

    # ---------------------------------------------------------------- UI
    def _build_ui(self) -> None:
        root = self.root
        root.title(f"Lurith {__version__}")
        root.configure(bg=BG)
        root.geometry("820x720")
        root.minsize(680, 600)

        self._apply_window_icon()

        # Accent strip + header
        tk.Frame(root, bg=ACCENT, height=3).pack(fill="x")
        header = tk.Frame(root, bg=BG)
        header.pack(fill="x", padx=22, pady=(16, 4))
        self._logo = self._load_logo()
        if self._logo is not None:
            tk.Label(header, image=self._logo, bg=BG).pack(side="left", padx=(0, 12))
        title_box = tk.Frame(header, bg=BG)
        title_box.pack(side="left")
        tk.Label(
            title_box, text="Lurith", bg=BG, fg="#ffffff", font=("Segoe UI", 24, "bold")
        ).pack(anchor="w")
        tk.Label(
            title_box,
            text="Lua 5.1 & Roblox Luau obfuscator",
            bg=BG,
            fg=MUTED,
            font=("Segoe UI", 10),
        ).pack(anchor="w")
        version = tk.Label(
            header,
            text=f"v{__version__}",
            bg="#1d1d29",
            fg="#c4b5fd",
            font=("Segoe UI", 9, "bold"),
            padx=9,
            pady=2,
        )
        version.pack(side="right", pady=(10, 0))

        # ---- source card ----
        card = tk.Frame(root, bg=CARD, padx=16, pady=14, highlightthickness=1, highlightbackground="#22222f")
        card.pack(fill="x", padx=22, pady=(14, 0))
        tk.Label(
            card, text="SOURCE — folders, files, and .zip archives", bg=CARD, fg=ACCENT,
            font=("Segoe UI", 9, "bold"),
        ).pack(anchor="w")

        # List of selected sources with add/remove controls.
        list_row = tk.Frame(card, bg=CARD)
        list_row.pack(fill="x", pady=(8, 0))
        list_frame = tk.Frame(list_row, bg=FIELD)
        list_frame.pack(side="left", fill="both", expand=True)
        self.source_list = tk.Listbox(
            list_frame, bg=FIELD, fg=FG, selectbackground=ACCENT_DARK, selectforeground="#ffffff",
            relief="flat", font=("Consolas", 10), activestyle="none", height=4, highlightthickness=0,
        )
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=self.source_list.yview, bg=CARD)
        self.source_list.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.source_list.pack(side="left", fill="both", expand=True)
        buttons = tk.Frame(list_row, bg=CARD)
        buttons.pack(side="left", padx=(8, 0), fill="y")
        tk.Button(
            buttons, text="＋ Add folder", command=self._choose_folder, bg=FIELD, fg=FG,
            activebackground="#26263a", relief="flat", bd=0, padx=10, pady=4,
            font=("Segoe UI", 9), cursor="hand2",
        ).pack(fill="x", pady=(0, 4))
        tk.Button(
            buttons, text="＋ Add files…", command=self._choose_files, bg=FIELD, fg=FG,
            activebackground="#26263a", relief="flat", bd=0, padx=10, pady=4,
            font=("Segoe UI", 9), cursor="hand2",
        ).pack(fill="x", pady=(0, 4))
        tk.Button(
            buttons, text="＋ Add zip…", command=self._choose_zip, bg=FIELD, fg=FG,
            activebackground="#26263a", relief="flat", bd=0, padx=10, pady=4,
            font=("Segoe UI", 9), cursor="hand2",
        ).pack(fill="x", pady=(0, 4))
        tk.Button(
            buttons, text="− Remove", command=self._remove_selected, bg=FIELD, fg=FG,
            activebackground="#26263a", relief="flat", bd=0, padx=10, pady=4,
            font=("Segoe UI", 9), cursor="hand2",
        ).pack(fill="x", pady=(0, 4))
        tk.Button(
            buttons, text="✕ Clear", command=self._clear_sources, bg=FIELD, fg=FG,
            activebackground="#26263a", relief="flat", bd=0, padx=10, pady=4,
            font=("Segoe UI", 9), cursor="hand2",
        ).pack(fill="x")

        self.source_hint = tk.Label(
            card, text="Add folders (scanned recursively), individual files, or .zip archives.",
            bg=CARD, fg=FAINT, font=("Segoe UI", 9),
        )
        self.source_hint.pack(anchor="w", pady=(6, 0))

        # ---- settings card ----
        opts = tk.Frame(root, bg=CARD, padx=16, pady=14, highlightthickness=1, highlightbackground="#22222f")
        opts.pack(fill="x", padx=22, pady=(10, 0))
        tk.Label(opts, text="PROTECTION", bg=CARD, fg=ACCENT, font=("Segoe UI", 9, "bold")).pack(anchor="w")

        grid = tk.Frame(opts, bg=CARD)
        grid.pack(fill="x", pady=(8, 0))
        self.level_var = tk.StringVar(value="high")
        self.dialect_var = tk.StringVar(value="auto")
        self.family_var = tk.StringVar(value="auto")
        self.env_var = tk.StringVar(value="auto")
        self.minify_var = tk.BooleanVar(value=False)
        self.comments_var = tk.BooleanVar(value=False)
        self.watermark_var = tk.BooleanVar(value=True)
        self.auto_open_var = tk.BooleanVar(value=True)

        self._label_combo(grid, "Level", self.level_var, list(CONFIGS), 0, 0)
        self._label_combo(grid, "Dialect", self.dialect_var, ["auto", "lua51", "luau"], 0, 1)
        self._label_combo(grid, "VM family", self.family_var, list(VM_FAMILIES), 0, 2)
        self._label_combo(grid, "Env check", self.env_var, ["auto", "off", "roblox"], 1, 0)

        toggles = tk.Frame(grid, bg=CARD)
        toggles.grid(row=1, column=1, columnspan=2, sticky="w", pady=(2, 0))
        tk.Checkbutton(
            toggles, text="Force minify", variable=self.minify_var, bg=CARD, fg=FG,
            selectcolor=FIELD, activebackground=CARD, activeforeground=FG, font=("Segoe UI", 10),
        ).pack(side="left", padx=(0, 12))
        tk.Checkbutton(
            toggles, text="Strip comments", variable=self.comments_var, bg=CARD, fg=FG,
            selectcolor=FIELD, activebackground=CARD, activeforeground=FG, font=("Segoe UI", 10),
        ).pack(side="left", padx=(0, 12))
        tk.Checkbutton(
            toggles, text="Watermark", variable=self.watermark_var, bg=CARD, fg=FG,
            selectcolor=FIELD, activebackground=CARD, activeforeground=FG, font=("Segoe UI", 10),
        ).pack(side="left", padx=(0, 12))
        tk.Checkbutton(
            toggles, text="Open result when done", variable=self.auto_open_var, bg=CARD, fg=FG,
            selectcolor=FIELD, activebackground=CARD, activeforeground=FG, font=("Segoe UI", 10),
        ).pack(side="left")

        self.level_hint = tk.Label(opts, text="", bg=CARD, fg=FAINT, font=("Segoe UI", 9), justify="left")
        self.level_hint.pack(anchor="w", pady=(6, 0))
        self.level_var.trace_add("write", self._on_level_change)
        self._on_level_change()

        # ---- run row ----
        run_row = tk.Frame(root, bg=BG)
        run_row.pack(fill="x", padx=22, pady=(16, 0))
        self.run_button = tk.Button(
            run_row, text="⚡  Obfuscate", command=self._run, bg=ACCENT, fg="#ffffff",
            activebackground=ACCENT_DARK, activeforeground="#ffffff", relief="flat", bd=0,
            padx=22, pady=11, font=("Segoe UI", 12, "bold"), cursor="hand2",
        )
        self.run_button.pack(side="left")
        self.progress = ttk.Progressbar(run_row, mode="determinate")
        self.progress.pack(side="left", fill="x", expand=True, padx=(14, 0))
        self.status_var = tk.StringVar(value="Ready.")
        tk.Label(run_row, textvariable=self.status_var, bg=BG, fg=MUTED, font=("Segoe UI", 10)).pack(
            side="left", padx=(14, 0)
        )

        # ---- log card ----
        log_card = tk.Frame(root, bg=CARD, highlightthickness=1, highlightbackground="#22222f")
        log_card.pack(fill="both", expand=True, padx=22, pady=(12, 6))
        log_head = tk.Frame(log_card, bg=CARD)
        log_head.pack(fill="x", padx=12, pady=(8, 0))
        tk.Label(log_head, text="OUTPUT", bg=CARD, fg=ACCENT, font=("Segoe UI", 9, "bold")).pack(side="left")
        self.log = tk.Text(
            log_card, bg=FIELD, fg=FG, insertbackground=FG, relief="flat", wrap="word",
            font=("Consolas", 10), padx=12, pady=10, state="disabled", height=10,
        )
        self.log.pack(fill="both", expand=True, padx=10, pady=(4, 10))

        # ---- bottom bar ----
        bottom = tk.Frame(root, bg=BG)
        bottom.pack(fill="x", padx=22, pady=(0, 14))
        tk.Button(
            bottom, text="Open output folder", command=self._open_output, bg=FIELD, fg=FG,
            activebackground="#26263a", relief="flat", bd=0, padx=12, pady=7,
            font=("Segoe UI", 10), cursor="hand2",
        ).pack(side="left")
        tk.Label(
            bottom,
            text="Outputs are saved as <name>.lurith.txt next to each source.",
            bg=BG, fg=FAINT, font=("Segoe UI", 9),
        ).pack(side="right")

    def _label_combo(
        self, parent: tk.Frame, label: str, variable: tk.StringVar, values: list[str], row: int, column: int
    ) -> None:
        cell = tk.Frame(parent, bg=CARD)
        cell.grid(row=row, column=column, sticky="w", padx=(0, 16), pady=(2, 2))
        tk.Label(cell, text=label.upper(), bg=CARD, fg=FAINT, font=("Segoe UI", 8, "bold")).pack(anchor="w")
        combo = ttk.Combobox(cell, textvariable=variable, values=values, state="readonly", width=18)
        combo.pack(fill="x", pady=(2, 0))

    # ---------------------------------------------------------------- icon
    def _apply_window_icon(self) -> None:
        png = _asset_path("icon.png")
        if png is None:
            return
        try:
            self._photo = tk.PhotoImage(file=str(png))
            self.root.iconphoto(True, self._photo)
        except tk.TclError:
            self._photo = None

    def _load_logo(self) -> tk.PhotoImage | None:
        png = _asset_path("icon.png")
        if png is None:
            return None
        try:
            image = tk.PhotoImage(file=str(png))
            return image.subsample(2) if image.width() > 96 else image
        except tk.TclError:
            return None

    def _on_level_change(self, *_args: object) -> None:
        config = CONFIGS.get(self.level_var.get())
        if config is None:
            self.level_hint.configure(text="")
            return
        self.level_hint.configure(text=config.description)

    # ---------------------------------------------------------------- engine warmup
    def _warm_engine(self) -> None:
        self.status_var.set("Checking engine…")

        def worker() -> None:
            try:
                ready = verify_parser_readiness()
                self.events.put(("engine", "", f"Engine ready: {', '.join(sorted(ready))}"))
            except ParserUnavailableError as exc:
                self.events.put(("engine-error", "", str(exc)))

        threading.Thread(target=worker, daemon=True).start()

    # ---------------------------------------------------------------- actions
    def _add_paths(self, paths: list[Path], label: str) -> None:
        if not paths:
            return
        existing = set(self.paths)
        added = 0
        for path in paths:
            if path not in existing:
                existing.add(path)
                self.paths.append(path)
                self._add_list_entry(path)
                added += 1
        self._refresh_summary()
        self._log(f"Added {added} source(s).")

    def _add_list_entry(self, path: Path) -> None:
        if path.is_dir():
            tag = "[folder]"
        elif path.suffix.lower() == ".zip":
            tag = "[zip]"
        else:
            tag = "[file]"
        self.source_list.insert("end", f"{tag}  {path}")

    def _refresh_summary(self) -> None:
        if not self.paths:
            self.source_hint.configure(text="Add folders (scanned recursively), individual files, or .zip archives.")
            self.status_var.set("Ready.")
            return
        count = count_sources(self.paths)
        self.source_hint.configure(text=f"{len(self.paths)} item(s) selected · {count} script(s) to obfuscate.")
        self.status_var.set(f"Ready — {count} script(s).")

    def _choose_folder(self) -> None:
        directory = filedialog.askdirectory(title="Add a folder of Lua/Luau scripts")
        if directory:
            self._add_paths([Path(directory)], "folder")

    def _choose_files(self) -> None:
        selected = filedialog.askopenfilenames(
            title="Add Lua/Luau files",
            filetypes=[("Lua source", "*.lua *.luau *.txt"), ("All files", "*.*")],
        )
        if selected:
            self._add_paths([Path(path) for path in selected], "files")

    def _choose_zip(self) -> None:
        selected = filedialog.askopenfilenames(
            title="Add .zip archives",
            filetypes=[("Zip archive", "*.zip"), ("All files", "*.*")],
        )
        if selected:
            self._add_paths([Path(path) for path in selected], "zips")

    def _remove_selected(self) -> None:
        selection = self.source_list.curselection()
        if not selection:
            return
        for index in reversed(selection):
            self.source_list.delete(index)
            del self.paths[index]
        self._refresh_summary()

    def _clear_sources(self) -> None:
        self.paths.clear()
        self.source_list.delete(0, "end")
        self._refresh_summary()

    def _settings(self) -> BatchSettings:
        return BatchSettings(
            config=self.level_var.get(),
            dialect=self.dialect_var.get(),
            vm_family=self.family_var.get(),
            environment_assertions=self.env_var.get(),
            minify=True if self.minify_var.get() else None,
            strip_comments=True if self.comments_var.get() else None,
            watermark=self.watermark_var.get(),
        )

    def _run(self) -> None:
        if self.running:
            return
        if not self.paths:
            messagebox.showinfo("Lurith", "Add a folder, files, or a zip first.")
            return
        total = count_sources(self.paths)
        if total == 0:
            messagebox.showinfo("Lurith", "No .lua / .luau / .txt files found to obfuscate.")
            return
        settings = self._settings()
        self.running = True
        self.progress.configure(maximum=total, value=0)
        self.run_button.configure(state="disabled", text="Working…")
        self.status_var.set(f"Obfuscating {total} file(s)…")
        self._log(f"Starting batch: level={settings.config}, dialect={settings.dialect} ({total} files)")

        def worker() -> None:
            try:
                summary = obfuscate_batch(
                    self.paths,
                    settings,
                    on_event=lambda kind, label, message: self.events.put((kind, label, message)),
                )
                self.events.put(("finished", "", summary))
            except Exception as exc:  # noqa: BLE001 — surface unexpected engine errors to the log
                self.events.put(("fatal", "", str(exc)))

        threading.Thread(target=worker, daemon=True).start()

    def _poll(self) -> None:
        try:
            while True:
                kind, path, payload = self.events.get_nowait()
                if kind == "engine":
                    self._log(payload, color=OK)
                    if not self.running:
                        self.status_var.set("Ready.")
                elif kind == "engine-error":
                    self._log(f"Engine problem: {payload}", color=WARN)
                    self.status_var.set("Engine not ready.")
                elif kind == "ok":
                    self._log(payload, color=OK)
                    self.progress.step(1)
                elif kind == "error":
                    self._log(f"✗ {path}: {payload}", color=ERR)
                    self.progress.step(1)
                elif kind == "finished":
                    summary = payload
                    self.running = False
                    self.run_button.configure(state="normal", text="⚡  Obfuscate")
                    self.progress.configure(value=summary.discovered)
                    self.status_var.set(f"Done: {summary.succeeded} ok, {summary.failed} failed.")
                    self._log(
                        f"— {summary.succeeded} succeeded, {summary.failed} failed (of {summary.discovered} found).",
                        color=ACCENT_2,
                    )
                    if self.auto_open_var.get() and summary.outputs:
                        self._reveal_results(summary.outputs)
                elif kind == "fatal":
                    self.running = False
                    self.run_button.configure(state="normal", text="⚡  Obfuscate")
                    self.status_var.set("Error.")
                    self._log(f"✗ {payload}", color=ERR)
        except queue.Empty:
            pass
        self.root.after(100, self._poll)

    def _log(self, message: str, color: str = FG) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", message + "\n")
        self.log.see("end")
        self.log.tag_add("recent", "end-2l", "end-1l")
        self.log.tag_configure("recent", foreground=color)
        self.log.configure(state="disabled")

    def _open_output(self) -> None:
        target = None
        if self.paths:
            first = self.paths[0]
            target = first if first.is_dir() else first.parent
        if target is None:
            messagebox.showinfo("Lurith", "Pick a folder first.")
            return
        self._reveal(target)

    def _reveal(self, path: Path) -> None:
        """Open a file (or folder) in the OS's default handler."""
        try:
            if sys.platform == "win32":
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except OSError as exc:
            messagebox.showwarning("Lurith", f"Could not open {path}: {exc}")

    def _reveal_results(self, outputs: list[Path]) -> None:
        """Open the freshly generated output(s): a single file/zip opens directly,
        otherwise the shared output folder is opened."""
        if not outputs:
            return
        if len(outputs) == 1:
            self._reveal(outputs[0])
            return
        parents = {output.parent for output in outputs}
        if len(parents) == 1:
            self._reveal(next(iter(parents)))
            return
        # Mixed locations (e.g. several folders + a zip): open each file.
        for output in outputs:
            self._reveal(output)


def main() -> int:
    if not _TK_AVAILABLE:
        print(
            "Lurith could not open its window: tkinter is unavailable.\n"
            "Install Python from python.org (the standard installer includes Tcl/Tk),\n"
            "or run the command-line version: `lurith file.lua -c high`.",
            file=sys.stderr,
        )
        return 1
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        print(
            f"Lurith could not open a window (no display available): {exc}\n"
            "Run the command-line version instead: `lurith file.lua -c high`.",
            file=sys.stderr,
        )
        return 1
    LurithApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
