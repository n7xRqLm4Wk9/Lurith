from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class CandidateScore:
    syntax_nodes: int
    protection_score: int
    estimated_overhead: int
    loops: int
    branches: int
    calls: int
    nested_functions: int
    has_vararg: bool

    def eligible(self, minimum_score: int, maximum_overhead: int) -> bool:
        return self.protection_score >= minimum_score and self.estimated_overhead <= maximum_overhead

    def reason(self, minimum_score: int, maximum_overhead: int) -> str:
        if self.protection_score < minimum_score:
            return f"protection score {self.protection_score} is below {minimum_score}"
        if self.estimated_overhead > maximum_overhead:
            return f"estimated overhead {self.estimated_overhead} exceeds {maximum_overhead}"
        return "eligible"


def analyze_candidate(body: Any) -> CandidateScore:
    syntax_nodes = 0
    loops = 0
    branches = 0
    calls = 0
    nested_functions = 0
    constants = 0
    has_vararg = False
    stack = [body]
    while stack:
        node = stack.pop()
        syntax_nodes += 1
        kind = node.type
        if kind in {"while_statement", "repeat_statement", "for_statement"}:
            loops += 1
        elif kind in {"if_statement", "elseif_statement"}:
            branches += 1
        elif kind == "function_call":
            calls += 1
        elif kind in {"function_declaration", "function_definition"}:
            nested_functions += 1
        elif kind in {"number", "string", "true", "false", "nil"}:
            constants += 1
        elif kind == "vararg_expression":
            has_vararg = True
        stack.extend(reversed(node.named_children))

    protection_score = syntax_nodes + loops * 6 + branches * 3 + constants - calls * 2 - nested_functions * 4
    estimated_overhead = 12 + loops * 5 + branches * 2 + calls * 5 + nested_functions * 14 + (8 if has_vararg else 0)
    return CandidateScore(
        syntax_nodes=syntax_nodes,
        protection_score=max(0, protection_score),
        estimated_overhead=estimated_overhead,
        loops=loops,
        branches=branches,
        calls=calls,
        nested_functions=nested_functions,
        has_vararg=has_vararg,
    )
