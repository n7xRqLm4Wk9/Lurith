from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from .lexer import Token
from .syntax import analyze_syntax
from .vm_family import get_vm_family

_CALLABLE_MACROS = frozenset({"LPH_JIT", "LPH_JIT_MAX", "LPH_NO_VIRTUALIZE"})
_VALUE_MACROS = frozenset({"LPH_OBFUSCATED", "LPH_LINE"})
_FAMILY_DIRECTIVE = re.compile(
    r"^--\s*@(lurith|luaminator)-vm-(?:family|profile)\s+([A-Za-z][A-Za-z0-9_-]*)\s*$"
)
_MINIFY_DIRECTIVE = re.compile(
    r"^--\s*@(lurith|luaminator)-(minify|no-minify|strip-comments|keep-comments)\s*$"
)


class MacroError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class VmFamilyDirectiveResult:
    source: str
    family: str | None


@dataclass(frozen=True, slots=True)
class MinifyDirectiveResult:
    source: str
    minify: bool | None
    strip_comments: bool | None


@dataclass(frozen=True, slots=True)
class MacroExpansionResult:
    source: str
    expanded: int
    names: tuple[str, ...]


def _walk(root: Any) -> list[Any]:
    output = []
    stack = [root]
    while stack:
        node = stack.pop()
        output.append(node)
        stack.extend(reversed(node.named_children))
    return output


def _location(node: Any) -> str:
    row, column = node.start_point
    return f"line {row + 1}, column {column + 1}"


def _apply_replacements(source: str, replacements: list[tuple[int, int, bytes]]) -> str:
    encoded = source.encode("utf-8")
    ordered = sorted(replacements, reverse=True)
    previous_start = len(encoded) + 1
    for start, end, replacement in ordered:
        if not 0 <= start <= end <= len(encoded):
            raise MacroError("Internal macro replacement range is invalid.")
        if end > previous_start:
            raise MacroError("Overlapping macro replacements are not supported.")
        encoded = encoded[:start] + replacement + encoded[end:]
        previous_start = start
    return encoded.decode("utf-8")


def extract_minify_directive(source: str, tokens: list[Token]) -> MinifyDirectiveResult:
    """Honor `--@lurith-minify` / `--@lurith-no-minify` and the comment controls.

    Both appear before any source code and override the selected config's
    minify/comment behavior for this obfuscation only.
    """
    minify_choice: tuple[Token, bool] | None = None
    comments_choice: tuple[Token, bool] | None = None
    code_seen = False
    for token in tokens:
        if token.kind in {"whitespace", "comment"}:
            if token.kind == "comment":
                match = _MINIFY_DIRECTIVE.fullmatch(token.value.strip())
                if match is not None:
                    if code_seen:
                        raise MacroError(
                            f"Minify directive must appear before source code at line {token.line}, "
                            f"column {token.column}."
                        )
                    action = match.group(2)
                    if action in {"minify", "no-minify"}:
                        if minify_choice is not None:
                            raise MacroError("Use at most one minify directive.")
                        minify_choice = (token, action == "minify")
                    else:
                        if comments_choice is not None:
                            raise MacroError("Use at most one comment directive.")
                        comments_choice = (token, action == "strip-comments")
            continue
        code_seen = True

    removed: list[tuple[int, int, bytes]] = []
    for token, _ in (choice for choice in (minify_choice, comments_choice) if choice is not None):
        removed.append((token.start_byte, token.end_byte, b""))
    if not removed:
        return MinifyDirectiveResult(source, None, None)
    changed = _apply_replacements(source, removed)
    return MinifyDirectiveResult(
        changed,
        minify_choice[1] if minify_choice is not None else None,
        comments_choice[1] if comments_choice is not None else None,
    )


def extract_vm_family_directive(source: str, tokens: list[Token]) -> VmFamilyDirectiveResult:
    matches: list[tuple[Token, str]] = []
    code_seen = False
    for token in tokens:
        if token.kind in {"whitespace", "comment"}:
            if token.kind == "comment":
                match = _FAMILY_DIRECTIVE.fullmatch(token.value.strip())
                if match is not None:
                    if code_seen:
                        raise MacroError(
                            f"VM-family directive must appear before source code at line {token.line}, "
                            f"column {token.column}."
                        )
                    family = get_vm_family(match.group(2)).name
                    matches.append((token, family))
            continue
        code_seen = True
    if len(matches) > 1:
        locations = ", ".join(f"line {token.line}" for token, _ in matches)
        raise MacroError(f"Use at most one VM-family directive; found directives at {locations}.")
    if not matches:
        return VmFamilyDirectiveResult(source, None)
    token, family = matches[0]
    changed = _apply_replacements(source, [(token.start_byte, token.end_byte, b"")])
    return VmFamilyDirectiveResult(changed, family)


def _condition_kind(source: bytes, condition: Any) -> bool | None:
    text = source[condition.start_byte : condition.end_byte].decode("utf-8").strip()
    if condition.type == "identifier" and text == "LPH_OBFUSCATED":
        return True
    if condition.type == "unary_expression" and re.fullmatch(r"not\s+LPH_OBFUSCATED", text):
        return False
    return None


def _fold_obfuscated_branches(source: str, dialect: str) -> tuple[str, int]:
    folded = 0
    for _ in range(1024):
        analysis = analyze_syntax(source, dialect)
        encoded = source.encode("utf-8")
        candidates = []
        for node in _walk(analysis.tree.root_node):
            if node.type != "if_statement":
                continue
            condition = node.child_by_field_name("condition")
            if condition is not None and _condition_kind(encoded, condition) is not None:
                candidates.append(node)
        if not candidates:
            return source, folded
        node = min(candidates, key=lambda value: value.end_byte - value.start_byte)
        condition = node.child_by_field_name("condition")
        assert condition is not None
        condition_true = _condition_kind(encoded, condition)
        consequence = node.child_by_field_name("consequence")
        alternative = node.child_by_field_name("alternative")
        chosen = consequence if condition_true else None
        if not condition_true and alternative is not None:
            if alternative.type != "else_statement":
                raise MacroError(
                    f"LPH_OBFUSCATED conditions with elseif branches are not supported at {_location(node)}."
                )
            chosen = alternative.child_by_field_name("body")
        body = b"" if chosen is None else encoded[chosen.start_byte : chosen.end_byte]
        replacement = b"do\n" + body + b"\nend"
        source = _apply_replacements(source, [(node.start_byte, node.end_byte, replacement)])
        folded += 1
    raise MacroError("Source contains too many nested LPH_OBFUSCATED branches.")


def _identifier_text(encoded: bytes, node: Any) -> str:
    return encoded[node.start_byte : node.end_byte].decode("utf-8")


def _is_assignment_target(node: Any) -> bool:
    parent = node.parent
    while parent is not None and parent.type in {"dot_index_expression", "bracket_index_expression"}:
        parent = parent.parent
    return parent is not None and parent.type in {"variable_list", "function_declaration"}


def _expand_line_macros(source: str, dialect: str) -> tuple[str, int]:
    analysis = analyze_syntax(source, dialect)
    encoded = source.encode("utf-8")
    replacements = []
    for node in _walk(analysis.tree.root_node):
        if node.type != "identifier" or _identifier_text(encoded, node) != "LPH_LINE":
            continue
        if _is_assignment_target(node):
            raise MacroError(f"LPH_LINE is a read-only macro at {_location(node)}.")
        parent = node.parent
        if parent is not None and parent.type == "function_call" and parent.child_by_field_name("name") == node:
            raise MacroError(f"LPH_LINE is a value macro and cannot be called at {_location(node)}.")
        replacements.append((node.start_byte, node.end_byte, str(node.start_point[0] + 1).encode("ascii")))
    changed = _apply_replacements(source, replacements) if replacements else source
    return changed, len(replacements)


def _expand_calls_and_values(source: str, dialect: str) -> tuple[str, list[str]]:
    analysis = analyze_syntax(source, dialect)
    encoded = source.encode("utf-8")
    replacements: list[tuple[int, int, bytes]] = []
    replaced_ranges: list[tuple[int, int]] = []
    names: list[str] = []

    for node in _walk(analysis.tree.root_node):
        if node.type != "function_call":
            continue
        name = node.child_by_field_name("name")
        arguments = node.child_by_field_name("arguments")
        if name is None or name.type != "identifier" or arguments is None:
            continue
        macro = _identifier_text(encoded, name)
        if macro not in _CALLABLE_MACROS:
            continue
        values = list(arguments.named_children)
        if len(values) != 1 or values[0].type != "function_definition":
            raise MacroError(f"{macro} requires exactly one anonymous function argument at {_location(node)}.")
        function_source = encoded[values[0].start_byte : values[0].end_byte].decode("utf-8")
        inner_replacements: list[tuple[int, int, bytes]] = []
        for inner in _walk(values[0]):
            if inner.type != "identifier":
                continue
            inner_name = _identifier_text(encoded, inner)
            if inner_name not in _VALUE_MACROS:
                continue
            if _is_assignment_target(inner):
                raise MacroError(f"{inner_name} is a read-only macro at {_location(inner)}.")
            inner_parent = inner.parent
            if (
                inner_parent is not None
                and inner_parent.type == "function_call"
                and inner_parent.child_by_field_name("name") == inner
            ):
                raise MacroError(f"{inner_name} is a value macro and cannot be called at {_location(inner)}.")
            replacement = b"true" if inner_name == "LPH_OBFUSCATED" else str(inner.start_point[0] + 1).encode("ascii")
            inner_replacements.append(
                (
                    inner.start_byte - values[0].start_byte,
                    inner.end_byte - values[0].start_byte,
                    replacement,
                )
            )
            names.append(inner_name)
        if inner_replacements:
            function_source = _apply_replacements(function_source, inner_replacements)
        replacements.append((node.start_byte, node.end_byte, b"(" + function_source.encode("utf-8") + b")"))
        replaced_ranges.append((node.start_byte, node.end_byte))
        names.append(macro)

    for node in _walk(analysis.tree.root_node):
        if node.type != "identifier":
            continue
        if any(start <= node.start_byte < end for start, end in replaced_ranges):
            continue
        name = _identifier_text(encoded, node)
        if name not in _VALUE_MACROS:
            continue
        if _is_assignment_target(node):
            raise MacroError(f"{name} is a read-only macro at {_location(node)}.")
        parent = node.parent
        if parent is not None and parent.type == "function_call" and parent.child_by_field_name("name") == node:
            raise MacroError(f"{name} is a value macro and cannot be called at {_location(node)}.")
        replacement = b"true" if name == "LPH_OBFUSCATED" else str(node.start_point[0] + 1).encode("ascii")
        replacements.append((node.start_byte, node.end_byte, replacement))
        names.append(name)

    changed = _apply_replacements(source, replacements) if replacements else source
    return changed, names


def _reject_reserved_identifiers(source: str, dialect: str) -> None:
    analysis = analyze_syntax(source, dialect)
    encoded = source.encode("utf-8")
    for node in _walk(analysis.tree.root_node):
        if node.type != "identifier":
            continue
        name = _identifier_text(encoded, node)
        if name.startswith("LPH"):
            supported = ", ".join(sorted(_CALLABLE_MACROS | _VALUE_MACROS))
            raise MacroError(
                f"Unsupported or misplaced Luraph-style identifier {name!r} at {_location(node)}. "
                f"Lurith's compatibility subset is: {supported}."
            )


def expand_luraph_macros(source: str, tree: Any, dialect: str) -> MacroExpansionResult:
    del tree  # Reparse after each pass so all replacement ranges stay exact.
    source, line_count = _expand_line_macros(source, dialect)
    source, branch_count = _fold_obfuscated_branches(source, dialect)
    source, names = _expand_calls_and_values(source, dialect)
    _reject_reserved_identifiers(source, dialect)
    all_names = [
        *("LPH_LINE" for _ in range(line_count)),
        *("LPH_OBFUSCATED" for _ in range(branch_count)),
        *names,
    ]
    return MacroExpansionResult(source, len(all_names), tuple(sorted(set(all_names))))
