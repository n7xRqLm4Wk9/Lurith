from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class PassSpec:
    name: str
    enabled: bool = True
    options: tuple[tuple[str, Any], ...] = ()

    def option(self, name: str, default: Any = None) -> Any:
        return dict(self.options).get(name, default)


@dataclass(frozen=True, slots=True)
class PipelinePlan:
    passes: tuple[PassSpec, ...]

    def enabled(self, name: str) -> bool:
        return any(stage.name == name and stage.enabled for stage in self.passes)

    def stage(self, name: str) -> PassSpec:
        for stage in self.passes:
            if stage.name == name:
                return stage
        raise KeyError(name)

    @property
    def active_names(self) -> tuple[str, ...]:
        return tuple(stage.name for stage in self.passes if stage.enabled)


def build_pipeline(config: Any) -> PipelinePlan:
    return PipelinePlan(
        (
            PassSpec("parse"),
            PassSpec("validate-input"),
            PassSpec("normalize-watermark"),
            PassSpec("expand-macros"),
            PassSpec(
                "lower-function-vm",
                True,
                (
                    ("auto-min-score", config.auto_virtualize_min_nodes),
                    ("auto-max-overhead", config.auto_virtualize_max_overhead),
                    ("polymorphism", config.vm_polymorphism_level),
                    ("integrity", config.anti_tamper_mode),
                ),
            ),
            PassSpec(
                "optimize-ir",
                config.superinstruction_level > 0,
                (("superinstruction-level", config.superinstruction_level),),
            ),
            PassSpec("validate-ir"),
            PassSpec("encode-bytecode"),
            PassSpec("validate-bytecode"),
            PassSpec(
                "obfuscate-native-flow",
                config.native_opaque_probability > 0 or config.native_flatten_probability > 0,
                (
                    ("opaque-probability", config.native_opaque_probability),
                    ("flatten-probability", config.native_flatten_probability),
                ),
            ),
            PassSpec("validate-native-flow"),
            PassSpec("rename-locals", config.rename_locals),
            PassSpec("protect-literals", config.virtualize_strings),
            PassSpec("mask-integers", config.integer_mask_probability > 0),
            PassSpec("strip-comments", config.strip_comments),
            PassSpec("minify", config.minify),
            PassSpec("emit"),
            PassSpec("validate-output"),
        )
    )
