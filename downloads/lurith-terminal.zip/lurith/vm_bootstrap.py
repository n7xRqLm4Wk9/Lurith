from __future__ import annotations

from dataclasses import dataclass

from .vm import RandomLike
from .vm_common import _random_name
from .vm_packing import lua_binary_literal, pack_words
from .vm_profile import VmProfile
from .vm_types import CompiledFunction


@dataclass(frozen=True, slots=True)
class BootstrapResult:
    lines: list[str]
    expected_manifest: int


def _zigzag(value: int) -> int:
    return value * 2 if value >= 0 else -value * 2 - 1


def _manifest_values(
    functions: list[CompiledFunction],
    opcodes: dict[str, int],
    profile: VmProfile,
) -> list[int]:
    values = [*profile.bootstrap_canaries, *sorted(opcodes.values())]
    for function in functions:
        encoded_handle = (_zigzag(function.handle) + profile.bootstrap_offset) % profile.bootstrap_modulus
        stored_code_length = len(pack_words(function.code)) if profile.packed_bytecode else len(function.code)
        values.extend(
            (
                encoded_handle,
                function.guard_token,
                stored_code_length,
                len(function.program.constants),
                len(function.sentinel_words),
                len(function.constant_canaries),
            )
        )
    return values


def _manifest_checksum(values: list[int], profile: VmProfile) -> int:
    result = profile.bootstrap_seed % profile.bootstrap_modulus
    for index, value in enumerate(values, 1):
        result = (result * profile.bootstrap_multiplier + value + index) % profile.bootstrap_modulus
    return result


def render_bootstrap(
    rng: RandomLike,
    used: set[str],
    profile: VmProfile,
    records: list[tuple[CompiledFunction, str]],
    opcodes: dict[str, int],
    programs_name: str,
    opaque_error: str,
) -> BootstrapResult:
    blob_name = _random_name(rng, used, profile)
    decoder_name = _random_name(rng, used, profile)
    canary_name = _random_name(rng, used, profile)
    opcode_name = _random_name(rng, used, profile)
    records_name = _random_name(rng, used, profile)
    decoded_name = _random_name(rng, used, profile)
    output_name = _random_name(rng, used, profile)
    record_name = _random_name(rng, used, profile)
    hash_name = _random_name(rng, used, profile)
    position_name = _random_name(rng, used, profile)
    mix_name = _random_name(rng, used, profile)
    zigzag_name = _random_name(rng, used, profile)
    handle_name = _random_name(rng, used, profile)
    init_name = _random_name(rng, used, profile)
    state_name = _random_name(rng, used, profile)
    enc_name = _random_name(rng, used, profile)
    guard_scalar_name = _random_name(rng, used, profile)
    code_len_name = _random_name(rng, used, profile)
    const_len_name = _random_name(rng, used, profile)
    sent_count_name = _random_name(rng, used, profile)
    canary_count_name = _random_name(rng, used, profile)
    k_name = _random_name(rng, used, profile)

    def number(value: int) -> str:
        return profile.lua_integer(value, rng)

    record_functions = [function for function, _ in records]
    expected = _manifest_checksum(_manifest_values(record_functions, opcodes, profile), profile)

    # Flat shuffled record table: records carry no inline handle, so the nested
    # `{handle, record}` dump site is gone entirely.
    records_source = "{" + ",".join(record for _, record in records) + "}"

    # Outer manifest blob: per-record structural scalars packed as varints.
    scalars: list[int] = []
    for function in record_functions:
        code_length = (
            len(pack_words(function.code)) if profile.packed_bytecode else len(function.code)
        )
        scalars.extend(
            (
                (_zigzag(function.handle) + profile.bootstrap_offset) % profile.bootstrap_modulus,
                function.guard_token,
                code_length,
                len(function.program.constants),
                len(function.sentinel_words),
                len(function.constant_canaries),
            )
        )
    blob_bytes = pack_words(scalars)
    blob_source = lua_binary_literal(blob_bytes)
    canary_source = "{" + ",".join(number(value) for value in profile.bootstrap_canaries) + "}"
    opcode_source = "{" + ",".join(number(value) for value in sorted(opcodes.values())) + "}"

    blob_len = len(blob_bytes)
    sentinel_one = 1 + (blob_len * 1) // 3
    sentinel_two = 1 + (blob_len * 2) // 3
    sentinel_one_value = blob_bytes[sentinel_one - 1]
    sentinel_two_value = blob_bytes[sentinel_two - 1]

    code_field = profile.record_index("code")
    constants_field = profile.record_index("constants")
    guard_field = profile.record_index("guard")
    sentinels_field = profile.record_index("sentinels")
    constant_canaries_field = profile.record_index("constant_canaries")

    # Outer decoder: a byte-walking varint unpacker using method-call form
    # (`blob:byte(i)`) — a different shape family from the inner packed-code
    # decoder which uses `string.byte(blob, i)` function form.
    decoder_lines = [
        f"local function {decoder_name}({blob_name})",
        f"local {output_name}={{}}",
        f"local {enc_name}=0",
        f"local {guard_scalar_name}=1",
        f"for i=1,#{blob_name} do",
        f"local {zigzag_name}={blob_name}:byte(i)",
        f"{enc_name}={enc_name}+({zigzag_name}%128)*{guard_scalar_name}",
        (
            f"if {zigzag_name}<128 then {output_name}[#{output_name}+1]={enc_name};"
            f"{enc_name}=0;{guard_scalar_name}=1 else {guard_scalar_name}={guard_scalar_name}*128 end"
        ),
        "end",
        f"return {output_name}",
        "end",
    ]

    common = [
        f"local {blob_name}={blob_source}",
        f"local {canary_name}={canary_source}",
        f"local {opcode_name}={opcode_source}",
        f"local {records_name}={records_source}",
        *decoder_lines,
        f"local {decoded_name}={decoder_name}({blob_name})",
    ]

    # Multi-point integrity: blob length, two byte sentinels, then the same
    # manifest checksum formula mixed over the decoded scalars (order preserved
    # from _manifest_checksum: canaries, opcodes, then per-record scalars).
    validation = [
        f"if not(#{blob_name}=={number(blob_len)}) then error({opaque_error},0) end",
        (
            f"if not({blob_name}:byte({number(sentinel_one)})=={number(sentinel_one_value)}) "
            f"then error({opaque_error},0) end"
        ),
        (
            f"if not({blob_name}:byte({number(sentinel_two)})=={number(sentinel_two_value)}) "
            f"then error({opaque_error},0) end"
        ),
        f"local {hash_name},{position_name}={number(profile.bootstrap_seed)},0",
        (
            f"local function {mix_name}(value){position_name}={position_name}+1;"
            f"{hash_name}=({hash_name}*{number(profile.bootstrap_multiplier)}+value+{position_name})"
            f"%{number(profile.bootstrap_modulus)} end"
        ),
        f"for i=1,#{canary_name} do {mix_name}({canary_name}[i]) end",
        f"for i=1,#{opcode_name} do {mix_name}({opcode_name}[i]) end",
        f"local {k_name}=1",
        f"for i=1,#{records_name} do",
        f"{mix_name}({decoded_name}[{k_name}])",
        f"{mix_name}({decoded_name}[{k_name}+1])",
        f"{mix_name}({decoded_name}[{k_name}+2])",
        f"{mix_name}({decoded_name}[{k_name}+3])",
        f"{mix_name}({decoded_name}[{k_name}+4])",
        f"{mix_name}({decoded_name}[{k_name}+5])",
        f"{k_name}={k_name}+6",
        "end",
        f"if {hash_name}~={number(expected)} then error({opaque_error},0) end",
    ]

    # Unpack into the real VM: verify each record's structural scalars, then
    # bind it under its zigzag-decoded handle. Opaque failure tokens throughout.
    reconstruct = [
        f"local {k_name}=1",
        f"for i=1,#{records_name} do",
        f"local {record_name}={records_name}[i]",
        f"local {handle_name}={decoded_name}[{k_name}]",
        f"local {guard_scalar_name}={decoded_name}[{k_name}+1]",
        f"local {code_len_name}={decoded_name}[{k_name}+2]",
        f"local {const_len_name}={decoded_name}[{k_name}+3]",
        f"local {sent_count_name}={decoded_name}[{k_name}+4]",
        f"local {canary_count_name}={decoded_name}[{k_name}+5]",
        f"if not({record_name}[{guard_field}]=={guard_scalar_name}) then error({opaque_error},0) end",
        f"if not(#{record_name}[{code_field}]=={code_len_name}) then error({opaque_error},0) end",
        f"if not(#{record_name}[{constants_field}]=={const_len_name}) then error({opaque_error},0) end",
        f"if not(#{record_name}[{sentinels_field}]/2=={sent_count_name}) then error({opaque_error},0) end",
        f"if not(#{record_name}[{constant_canaries_field}]/3=={canary_count_name}) then error({opaque_error},0) end",
        (
            f"local {zigzag_name}=({handle_name}-{number(profile.bootstrap_offset)})"
            f"%{number(profile.bootstrap_modulus)}"
        ),
        (
            f"local {state_name};if {zigzag_name}%2==0 then {state_name}={zigzag_name}/2 "
            f"else {state_name}=-({zigzag_name}+1)/2 end"
        ),
        f"{output_name}[{state_name}]={record_name}",
        f"{k_name}={k_name}+6",
        "end",
    ]

    if profile.bootstrap_shape == "iife":
        lines = [
            *common,
            f"local {programs_name}=(function()",
            f"local {output_name}={{}}",
            *validation,
            *reconstruct,
            f"return {output_name}",
            "end)()",
        ]
    elif profile.bootstrap_shape == "closure":
        lines = [
            *common,
            f"local function {init_name}()",
            f"local {output_name}={{}}",
            *validation,
            *reconstruct,
            f"return {output_name}",
            "end",
            f"local {programs_name}={init_name}();{init_name}=nil",
        ]
    elif profile.bootstrap_shape == "state":
        start_state = rng.randint(10_000, 500_000)
        build_state = start_state + rng.randint(3, 997)
        end_state = build_state + rng.randint(3, 997)
        lines = [
            *common,
            f"local {programs_name}, {state_name}={{}},{number(start_state)}",
            "repeat",
            f"if {state_name}=={number(start_state)} then",
            *validation,
            f"{state_name}={number(build_state)}",
            f"elseif {state_name}=={number(build_state)} then",
            f"local {output_name}={programs_name}",
            *reconstruct,
            f"{state_name}={number(end_state)}",
            "end",
            f"until {state_name}=={number(end_state)}",
        ]
    else:
        lines = [
            *common,
            f"local {programs_name};do",
            f"local {output_name}={{}}",
            *validation,
            *reconstruct,
            f"{programs_name}={output_name}",
            "end",
        ]
    return BootstrapResult(lines, expected)
