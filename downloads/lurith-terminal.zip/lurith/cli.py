"""Lurith terminal CLI.

Runs the full obfuscation engine locally. Install with `pip install .` (core
dependencies only) and run `lurith script.lua`, or run `python -m lurith.cli`
from a checkout without installing anything.

The grammar loader in `lurith.syntax` falls back to the locally installed
`tree-sitter-language-pack` when the baked grammars are absent or were built
for another platform, so this CLI works on Linux, macOS, and Windows with just
`tree-sitter` and `tree-sitter-language-pack` installed.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from lurith import CONFIGS, VM_FAMILIES, Obfuscator, __version__, get_config, get_vm_family


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="lurith",
        description="Obfuscate Lua 5.1 or Roblox Luau source files locally.",
    )
    parser.add_argument(
        "inputs",
        nargs="*",
        metavar="INPUT",
        help="source files to obfuscate (use '-' to read from stdin)",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        help="output file (single input only; default '<stem>.lurith.txt')",
    )
    parser.add_argument("--stdout", action="store_true", help="write the result to stdout instead of a file")
    parser.add_argument(
        "-c", "--config", choices=tuple(CONFIGS), default="normal", help="protection level (default: normal)"
    )
    parser.add_argument(
        "-d", "--dialect", choices=("lua51", "luau"), default="lua51", help="source dialect (default: lua51)"
    )
    parser.add_argument(
        "--vm-family",
        choices=tuple(VM_FAMILIES),
        default="auto",
        help="VM profile family (default: auto; a source directive may select one when this is auto)",
    )
    parser.add_argument(
        "--environment-assertions",
        choices=("auto", "off", "roblox"),
        default="auto",
        help="Roblox capability assertion: auto (roblox for Luau, off for Lua 5.1), roblox, or off",
    )
    parser.add_argument("--seed", type=int, help="deterministic seed (for reproducible builds / testing)")
    minify_group = parser.add_mutually_exclusive_group()
    minify_group.add_argument("--minify", dest="minify", action="store_true", help="force whitespace minification")
    minify_group.add_argument(
        "--no-minify", dest="minify", action="store_false", help="disable minification regardless of config"
    )
    parser.set_defaults(minify=None)
    comment_group = parser.add_mutually_exclusive_group()
    comment_group.add_argument("--strip-comments", dest="strip_comments", action="store_true", help="strip comments")
    comment_group.add_argument(
        "--keep-comments", dest="strip_comments", action="store_false", help="keep comments in the output"
    )
    parser.set_defaults(strip_comments=None)
    parser.add_argument("-q", "--quiet", action="store_true", help="suppress the per-file summary")
    parser.add_argument("--version", action="store_true", help="print the Lurith version and exit")
    parser.add_argument("--list-levels", action="store_true", help="list protection levels and exit")
    parser.add_argument("--list-families", action="store_true", help="list VM families and exit")
    return parser


def _print_levels() -> None:
    print(f"Lurith {__version__} — protection levels")
    print()
    for name, config in CONFIGS.items():
        print(f"  {name:<11} {config.description}")
    print()
    print("Choose with `--config <level>` (default: normal).")


def _print_families() -> None:
    print(f"Lurith {__version__} — VM families")
    print()
    for name, spec in VM_FAMILIES.items():
        requirement = "any" if spec.minimum_polymorphism_level == 0 else (
            "normal+" if spec.minimum_polymorphism_level == 1 else "high+"
        )
        print(f"  {name:<9} requires {requirement:<8} {spec.description}")
    print()
    print("Choose with `--vm-family <family>` (default: auto).")


def _obfuscate_source(source: str, args: argparse.Namespace) -> object:
    return Obfuscator(
        args.config,
        args.dialect,
        seed=args.seed,
        environment_assertions=args.environment_assertions,
        vm_family=args.vm_family,
        minify=args.minify,
        strip_comments=args.strip_comments,
    ).obfuscate(source)


def _summarize(result: object, destination: str) -> str:
    return (
        f"wrote {destination} ({result.config}, {result.dialect}, {result.virtualized_literals} literals, "
        f"{result.masked_integers} masked ints, {result.renamed_locals} renamed locals, "
        f"{result.virtualized_functions} VM functions, {result.bytecode_word_count} words, "
        f"{result.opaque_predicates} opaque, {result.flattened_native_statements} flattened, "
        f"VM family {result.vm_family}, {result.input_bytes} -> {result.output_bytes} bytes)"
    )


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.version:
        print(f"Lurith {__version__}")
        return 0
    if args.list_levels:
        _print_levels()
        return 0
    if args.list_families:
        _print_families()
        return 0
    if not args.inputs:
        parser.print_help()
        return 1
    if args.output is not None and (len(args.inputs) != 1 or args.stdout):
        print("error: --output requires exactly one input and cannot be combined with --stdout", file=sys.stderr)
        return 1

    # Validate the requested config/family combination once, up front.
    try:
        config = get_config(args.config)
        get_vm_family(args.vm_family).validate_level(config.vm_polymorphism_level, config.name)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    for input_name in args.inputs:
        try:
            if input_name == "-":
                if len(args.inputs) != 1:
                    print("error: stdin input '-' cannot be combined with other inputs", file=sys.stderr)
                    return 1
                source = sys.stdin.read()
                label = "<stdin>"
            else:
                path = Path(input_name)
                source = path.read_text(encoding="utf-8-sig")
                label = str(path)
            result = _obfuscate_source(source, args)
        except (OSError, UnicodeError, ValueError) as exc:
            print(f"error: {label}: {exc}", file=sys.stderr)
            return 1

        if args.stdout or (input_name == "-" and args.output is None):
            sys.stdout.write(result.source)
            if not result.source.endswith("\n"):
                sys.stdout.write("\n")
            if not args.quiet:
                print(_summarize(result, "<stdout>"), file=sys.stderr)
            continue

        output = args.output
        if output is None:
            output = Path(input_name).with_name(Path(input_name).stem + ".lurith.txt")
        try:
            output.write_text(result.source, encoding="utf-8")
        except OSError as exc:
            print(f"error: {output}: {exc}", file=sys.stderr)
            return 1
        if not args.quiet:
            print(_summarize(result, str(output)), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
