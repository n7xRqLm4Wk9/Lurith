from __future__ import annotations

import re
from dataclasses import dataclass

LUA_KEYWORDS = {
    "and",
    "break",
    "do",
    "else",
    "elseif",
    "end",
    "false",
    "for",
    "function",
    "goto",
    "if",
    "in",
    "local",
    "nil",
    "not",
    "or",
    "repeat",
    "return",
    "then",
    "true",
    "until",
    "while",
    "continue",
    "type",
    "export",
}

_MULTI_SYMBOLS = sorted(
    {
        "...",
        "..=",
        "//=",
        "<<=",
        ">>=",
        "->",
        "::",
        "==",
        "~=",
        "<=",
        ">=",
        "..",
        "//",
        "<<",
        ">>",
        "+=",
        "-=",
        "*=",
        "/=",
        "%=",
        "^=",
        "&=",
        "|=",
    },
    key=len,
    reverse=True,
)

_LONG_OPEN = re.compile(r"\[(=*)\[")
_HEX_NUMBER = re.compile(r"0[xX][0-9A-Fa-f_]+(?:\.[0-9A-Fa-f_]*)?(?:[pP][+-]?[0-9_]+)?")
_BINARY_NUMBER = re.compile(r"0[bB][01_]+")
_DECIMAL_NUMBER = re.compile(r"[0-9][0-9_]*(?:\.(?!\.)[0-9_]*)?(?:[eE][+-]?[0-9_]+)?")
_DOT_NUMBER = re.compile(r"\.[0-9][0-9_]*(?:[eE][+-]?[0-9_]+)?")


class LexError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class Token:
    kind: str
    value: str
    line: int
    column: int
    start_byte: int = -1
    end_byte: int = -1


def _long_bracket_end(source: str, position: int) -> tuple[int, int] | None:
    match = _LONG_OPEN.match(source, position)
    if not match:
        return None
    close = "]" + match.group(1) + "]"
    end = source.find(close, match.end())
    if end < 0:
        raise LexError(f"Unterminated long bracket at offset {position}")
    return end + len(close), len(match.group(1))


def lex(source: str) -> list[Token]:
    tokens: list[Token] = []
    i = 0
    line = 1
    column = 1
    byte_offset = 0
    length = len(source)

    def emit(kind: str, start: int, end: int, start_line: int, start_column: int) -> None:
        text = source[start:end]
        tokens.append(
            Token(
                kind,
                text,
                start_line,
                start_column,
                byte_offset,
                byte_offset + len(text.encode("utf-8")),
            )
        )

    def advance(text: str) -> None:
        nonlocal byte_offset, line, column
        byte_offset += len(text.encode("utf-8"))
        newlines = text.count("\n")
        if newlines:
            line += newlines
            column = len(text.rsplit("\n", 1)[-1]) + 1
        else:
            column += len(text)

    while i < length:
        start = i
        start_line = line
        start_column = column
        char = source[i]

        if char.isspace():
            i += 1
            while i < length and source[i].isspace():
                i += 1
            text = source[start:i]
            emit("whitespace", start, i, start_line, start_column)
            advance(text)
            continue

        if source.startswith("--", i):
            long_end = _long_bracket_end(source, i + 2)
            if long_end:
                i = long_end[0]
            else:
                newline = source.find("\n", i + 2)
                i = length if newline < 0 else newline
            text = source[start:i]
            emit("comment", start, i, start_line, start_column)
            advance(text)
            continue

        if char in {"'", '"'}:
            quote = char
            i += 1
            while i < length:
                current = source[i]
                if current == "\\":
                    if i + 1 >= length:
                        i += 1
                        continue
                    # Lua 5.2+ and Luau use \z to consume all following whitespace,
                    # including otherwise-forbidden physical newlines inside a quote.
                    if source[i + 1] == "z":
                        i += 2
                        while i < length and source[i].isspace():
                            i += 1
                    elif source[i + 1] == "\r" and i + 2 < length and source[i + 2] == "\n":
                        i += 3
                    else:
                        i += 2
                    continue
                if current == quote:
                    i += 1
                    break
                if current in "\r\n":
                    raise LexError(f"Unescaped newline in string at line {start_line}")
                i += 1
            else:
                raise LexError(f"Unterminated string at line {start_line}")
            text = source[start:i]
            emit("string", start, i, start_line, start_column)
            advance(text)
            continue

        if char == "`":
            # Luau interpolated strings contain nested expressions. Preserve the whole token
            # instead of rewriting it without a full Luau parser.
            i += 1
            escaped = False
            while i < length:
                current = source[i]
                if escaped:
                    escaped = False
                    i += 1
                    continue
                if current == "\\":
                    escaped = True
                    i += 1
                    continue
                if current == "`":
                    i += 1
                    break
                i += 1
            else:
                raise LexError(f"Unterminated interpolated string at line {start_line}")
            text = source[start:i]
            emit("interpolated_string", start, i, start_line, start_column)
            advance(text)
            continue

        long_end = _long_bracket_end(source, i) if char == "[" else None
        if long_end:
            i = long_end[0]
            text = source[start:i]
            emit("string", start, i, start_line, start_column)
            advance(text)
            continue

        if char == "_" or char.isalpha():
            i += 1
            while i < length and (source[i] == "_" or source[i].isalnum()):
                i += 1
            text = source[start:i]
            kind = "keyword" if text in LUA_KEYWORDS else "identifier"
            emit(kind, start, i, start_line, start_column)
            advance(text)
            continue

        number_match = None
        if char.isdigit():
            number_match = (
                _HEX_NUMBER.match(source, i) or _BINARY_NUMBER.match(source, i) or _DECIMAL_NUMBER.match(source, i)
            )
        elif char == "." and i + 1 < length and source[i + 1].isdigit():
            number_match = _DOT_NUMBER.match(source, i)
        if number_match:
            i = number_match.end()
            text = source[start:i]
            emit("number", start, i, start_line, start_column)
            advance(text)
            continue

        matched_symbol = next((symbol for symbol in _MULTI_SYMBOLS if source.startswith(symbol, i)), None)
        if matched_symbol:
            i += len(matched_symbol)
        else:
            i += 1
        text = source[start:i]
        emit("symbol", start, i, start_line, start_column)
        advance(text)

    return tokens


def decode_lua_string(literal: str, dialect: str = "luau") -> bytes | None:
    """Decode a Lua/Luau literal to its runtime UTF-8 byte sequence.

    `dialect` selects escape semantics: PUC Lua 5.1 treats the z-escape and the
    u-brace escape as unknown escapes (the escaped character itself), while Luau
    implements both. Returns None for interpolated strings or malformed/unsupported
    escapes so callers can conservatively leave the original literal untouched.
    """
    if not literal:
        return None

    long_match = _LONG_OPEN.match(literal)
    if long_match:
        close = "]" + long_match.group(1) + "]"
        if not literal.endswith(close):
            return None
        body = literal[long_match.end() : -len(close)]
        if body.startswith("\r\n"):
            body = body[2:]
        elif body.startswith(("\n", "\r")):
            body = body[1:]
        return body.encode("utf-8")

    if literal[0] not in {"'", '"'} or len(literal) < 2 or literal[-1] != literal[0]:
        return None

    body = literal[1:-1]
    output = bytearray()
    i = 0
    simple = {
        "a": 7,
        "b": 8,
        "f": 12,
        "n": 10,
        "r": 13,
        "t": 9,
        "v": 11,
        "\\": 92,
        '"': 34,
        "'": 39,
    }

    while i < len(body):
        char = body[i]
        if char != "\\":
            output.extend(char.encode("utf-8"))
            i += 1
            continue

        i += 1
        if i >= len(body):
            return None
        escaped = body[i]
        if escaped in simple:
            output.append(simple[escaped])
            i += 1
        elif escaped in "\r\n":
            if escaped == "\r" and i + 1 < len(body) and body[i + 1] == "\n":
                i += 1
            output.append(10)
            i += 1
        elif escaped == "z":
            if dialect == "lua51":
                output.extend(b"z")
                i += 1
            else:
                i += 1
                while i < len(body) and body[i].isspace():
                    i += 1
        elif escaped == "x" and i + 2 < len(body):
            digits = body[i + 1 : i + 3]
            if not re.fullmatch(r"[0-9A-Fa-f]{2}", digits):
                return None
            output.append(int(digits, 16))
            i += 3
        elif escaped == "u" and dialect == "lua51":
            # PUC Lua 5.1 has no \u escape: keep the literal `u`, then the
            # `{...}` text that follows is emitted as ordinary characters.
            output.extend(b"u")
            i += 1
        elif escaped == "u" and i + 1 < len(body) and body[i + 1] == "{":
            close = body.find("}", i + 2)
            if close < 0:
                return None
            digits = body[i + 2 : close]
            if not digits or not re.fullmatch(r"[0-9A-Fa-f]+", digits):
                return None
            try:
                output.extend(chr(int(digits, 16)).encode("utf-8"))
            except (ValueError, UnicodeEncodeError):
                return None
            i = close + 1
        elif escaped.isdigit():
            end = i
            while end < len(body) and end < i + 3 and body[end].isdigit():
                end += 1
            value = int(body[i:end], 10)
            if value > 255:
                return None
            output.append(value)
            i = end
        else:
            # Lua 5.1 treats an escaped non-special character as that character.
            output.extend(escaped.encode("utf-8"))
            i += 1

    return bytes(output)
