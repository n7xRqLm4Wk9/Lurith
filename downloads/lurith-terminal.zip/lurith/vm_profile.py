from __future__ import annotations

import math
import string
from dataclasses import dataclass, replace
from typing import Literal

from .vm import RandomLike
from .vm_family import get_vm_family

DispatcherShape = Literal["linear", "binary", "bucket"]
PreludeShape = Literal["block", "iife"]
EncodingShape = Literal["raw", "affine"]
NameStyle = Literal["underscore", "confusable", "alpha"]
IntegrityFamily = Literal["rolling", "fletcher"]
BootstrapShape = Literal["direct", "iife", "closure", "state"]
ExecutionStyle = Literal["inline", "staged"]


@dataclass(frozen=True, slots=True)
class AffineEncoding:
    modulus: int
    multiplier: int
    increment: int
    inverse: int

    def encode(self, value: int) -> int:
        return (value * self.multiplier + self.increment) % self.modulus

    def lua_decode(self, expression: str) -> str:
        return f"((({expression})-{self.increment})*{self.inverse})%{self.modulus}"


@dataclass(frozen=True, slots=True)
class VmProfile:
    family: str
    execution_style: ExecutionStyle
    numeric_constant_strings: bool
    dispatcher: DispatcherShape
    loop_style: Literal["while", "repeat"]
    prelude: PreludeShape
    name_style: NameStyle
    stack_direction: int
    stack_origin: int
    opcode_encoding: AffineEncoding | None
    operand_encoding: AffineEncoding | None
    register_encoding: AffineEncoding | None
    packed_bytecode: bool
    bootstrap_shape: BootstrapShape
    bootstrap_offset: int
    bootstrap_modulus: int
    bootstrap_multiplier: int
    bootstrap_seed: int
    bootstrap_canaries: tuple[int, int, int]
    integrity_sample_period: int
    integrity_sample_slot: int
    decoy_opcode_count: int
    number_style: Literal["decimal", "mixed"]
    record_order: tuple[str, ...]
    handle_minimum: int
    handle_maximum: int
    integrity_family: IntegrityFamily
    integrity_modulus: int
    integrity_multiplier: int
    integrity_increment: int
    integrity_weights: tuple[int, int, int, int]
    error_tokens: tuple[str, str, str, str]
    opcode_aliasing: bool
    alu_inverted: bool
    cmp_inverted: bool

    def new_handle(self, rng: RandomLike, used: set[int]) -> int:
        while True:
            handle = rng.randint(self.handle_minimum, self.handle_maximum)
            if handle not in used:
                used.add(handle)
                return handle

    def encode_operand(self, value: int) -> int:
        if self.operand_encoding is None:
            return value
        return self.operand_encoding.encode(value)

    def decode_operand_lua(self, expression: str) -> str:
        if self.operand_encoding is None:
            return expression
        return self.operand_encoding.lua_decode(expression)

    def encode_opcode(self, value: int) -> int:
        if self.opcode_encoding is None:
            return value
        return self.opcode_encoding.encode(value)

    def decode_opcode_lua(self, expression: str) -> str:
        if self.opcode_encoding is None:
            return expression
        return self.opcode_encoding.lua_decode(expression)

    def register_lua(self, expression: str) -> str:
        if self.register_encoding is None:
            return expression
        encoding = self.register_encoding
        return f"((({expression})*{encoding.multiplier})+{encoding.increment})%{encoding.modulus}"

    def lua_integer(self, value: int, rng: RandomLike) -> str:
        if self.number_style == "mixed" and rng.random() < 0.5:
            return f"-0x{abs(value):X}" if value < 0 else f"0x{value:X}"
        return str(value)

    def record_index(self, field: str) -> int:
        return self.record_order.index(field) + 1


def _affine_encoding(rng: RandomLike, modulus: int) -> AffineEncoding:
    while True:
        multiplier = rng.randint(3, min(modulus - 2, 10_000))
        if math.gcd(multiplier, modulus) == 1:
            break
    increment = rng.randint(1, modulus - 1)
    return AffineEncoding(modulus, multiplier, increment, pow(multiplier, -1, modulus))


def _random_token(rng: RandomLike) -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(rng.choice(alphabet) for _ in range(rng.randint(9, 18)))


def create_vm_profile(rng: RandomLike, level: int, family: str = "auto") -> VmProfile:
    level = max(0, min(level, 4))
    family_spec = get_vm_family(family)
    family_spec.validate_level(level, f"polymorphism-level-{level}")
    dispatcher_choices: list[DispatcherShape] = ["linear"]
    if level >= 1:
        dispatcher_choices.append("binary")
    if level >= 2:
        dispatcher_choices.append("bucket")

    encoding_moduli = [251, 257, 263]
    opcode_encoding = None
    if level >= 1 and rng.random() < min(0.35 + level * 0.12, 0.85):
        opcode_encoding = _affine_encoding(rng, rng.choice(encoding_moduli))

    operand_encoding = None
    if level >= 2 and rng.random() < min(0.25 + level * 0.15, 0.85):
        operand_encoding = _affine_encoding(rng, 1_000_003)

    register_encoding = None
    if level >= 2 and rng.random() < min(0.30 + level * 0.12, 0.85):
        register_encoding = _affine_encoding(rng, 1_000_003)

    # Preserve the historical RNG draw so other profile dimensions keep their distribution.
    if level >= 3:
        rng.random()
    packed_bytecode = False
    bootstrap_choices: list[BootstrapShape] = ["direct"]
    if level >= 1:
        bootstrap_choices.extend(("iife", "closure"))
    if level >= 2:
        bootstrap_choices.append("state")
    bootstrap_shape = rng.choice(bootstrap_choices)
    bootstrap_modulus = 2_147_483_647
    bootstrap_offset = rng.randint(1_000, bootstrap_modulus - 2)
    bootstrap_multiplier = rng.choice([257, 263, 269, 271, 277, 281, 283])
    bootstrap_seed = rng.randint(97, 65_535)
    bootstrap_canaries = tuple(rng.sample(range(100_003, 9_999_991), 3))
    integrity_sample_period = rng.randint(3, 11)
    integrity_sample_slot = rng.randint(0, integrity_sample_period - 1)
    decoy_opcode_count = 0 if level < 2 else min(8, level * 2)
    number_style = "mixed" if level >= 2 and rng.random() < 0.8 else "decimal"

    record_fields = [
        "code",
        "constants",
        "locals",
        "parameters",
        "guard",
        "sentinels",
        "constant_canaries",
        "checksum",
    ]
    if level >= 1:
        record_fields = rng.sample(record_fields, len(record_fields))

    handle_ranges = [
        (4_097, 16_777_215),
        (-16_777_215, -4_097),
        (33_554_431, 536_870_911),
    ]
    handle_minimum, handle_maximum = rng.choice(handle_ranges[: 1 + min(level, 2)])

    integrity_modulus = rng.choice([1_000_003, 16_777_213, 2_147_483_647])
    integrity_multiplier = rng.choice([257, 263, 269, 271, 277, 281, 283, 293, 307])
    integrity_increment = rng.randint(97, 65_535)
    integrity_weights = tuple(rng.sample(list(range(11, 97)), 4))

    name_styles: list[NameStyle] = ["underscore"]
    if level >= 1:
        name_styles.extend(("confusable", "alpha"))

    # Deep-opcode aliasing: at medium+ two operation pairs share one opcode
    # value, gated by an operand-carried discriminant (see vm_runtime.py).
    # The inversion draws happen only when aliasing is enabled, so lower-level
    # profiles keep the exact RNG sequence of earlier releases.
    opcode_aliasing = level >= 2
    if opcode_aliasing:
        alu_inverted = rng.random() < 0.5
        cmp_inverted = rng.random() < 0.5
    else:
        alu_inverted = False
        cmp_inverted = False

    profile = VmProfile(
        family=family_spec.name,
        execution_style=("staged" if level >= 3 and bootstrap_seed % 3 == 0 else "inline"),
        numeric_constant_strings=level >= 2,
        dispatcher=rng.choice(dispatcher_choices),
        loop_style=rng.choice(["while", "repeat"]) if level >= 1 else "while",
        prelude=rng.choice(["block", "iife"]) if level >= 1 else "block",
        name_style=rng.choice(name_styles),
        stack_direction=rng.choice([1, -1]) if level >= 1 else 1,
        stack_origin=rng.randint(0, 4096) if level >= 1 else 0,
        opcode_encoding=opcode_encoding,
        operand_encoding=operand_encoding,
        register_encoding=register_encoding,
        packed_bytecode=packed_bytecode,
        bootstrap_shape=bootstrap_shape,
        bootstrap_offset=bootstrap_offset,
        bootstrap_modulus=bootstrap_modulus,
        bootstrap_multiplier=bootstrap_multiplier,
        bootstrap_seed=bootstrap_seed,
        bootstrap_canaries=bootstrap_canaries,
        integrity_sample_period=integrity_sample_period,
        integrity_sample_slot=integrity_sample_slot,
        decoy_opcode_count=decoy_opcode_count,
        number_style=number_style,
        record_order=tuple(record_fields),
        handle_minimum=handle_minimum,
        handle_maximum=handle_maximum,
        integrity_family=rng.choice(["rolling", "fletcher"]) if level >= 2 else "rolling",
        integrity_modulus=integrity_modulus,
        integrity_multiplier=integrity_multiplier,
        integrity_increment=integrity_increment,
        integrity_weights=integrity_weights,
        error_tokens=tuple(_random_token(rng) for _ in range(4)),
        opcode_aliasing=opcode_aliasing,
        alu_inverted=alu_inverted,
        cmp_inverted=cmp_inverted,
    )
    if family_spec.name == "auto":
        return profile
    return replace(
        profile,
        dispatcher=family_spec.dispatcher or profile.dispatcher,
        packed_bytecode=(
            family_spec.packed_bytecode if family_spec.packed_bytecode is not None else profile.packed_bytecode
        ),
        integrity_family=family_spec.integrity_family or profile.integrity_family,
        execution_style=family_spec.execution_style or profile.execution_style,
    )


def random_identifier(rng: RandomLike, used: set[str], style: NameStyle, minimum: int = 6, maximum: int = 11) -> str:
    while True:
        length = rng.randint(minimum, maximum)
        if style == "confusable":
            candidate = rng.choice("lI") + "".join(rng.choice("lIOo") for _ in range(length - 1))
        elif style == "alpha":
            candidate = rng.choice(string.ascii_letters) + "".join(
                rng.choice(string.ascii_letters + string.digits) for _ in range(length - 1)
            )
        else:
            candidate = "_" + "".join(rng.choice(string.ascii_letters) for _ in range(length))
        if candidate not in used:
            used.add(candidate)
            return candidate
