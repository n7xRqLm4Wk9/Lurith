from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

AntiTamperMode = Literal["off", "once", "sampled", "always"]


@dataclass(frozen=True, slots=True)
class ObfuscationConfig:
    name: str
    description: str
    strip_comments: bool
    minify: bool
    virtualize_strings: bool
    minimum_string_bytes: int
    junk_probability: float
    mask_vm_constants: bool
    integer_mask_probability: float
    rename_locals: bool
    max_string_fragments: int
    anti_tamper_mode: AntiTamperMode
    vm_polymorphism_level: int
    auto_virtualize_min_nodes: int
    auto_virtualize_max_overhead: int
    native_opaque_probability: float
    native_flatten_probability: float
    superinstruction_level: int


CONFIGS: dict[str, ObfuscationConfig] = {
    "low": ObfuscationConfig(
        name="low",
        description=(
            "Light protection; preserves comments/formatting, virtualizes strings of "
            "8+ bytes, and verifies forced VM functions once."
        ),
        strip_comments=False,
        minify=False,
        virtualize_strings=True,
        minimum_string_bytes=8,
        junk_probability=0.00,
        mask_vm_constants=False,
        integer_mask_probability=0.00,
        rename_locals=False,
        max_string_fragments=1,
        anti_tamper_mode="once",
        vm_polymorphism_level=0,
        auto_virtualize_min_nodes=0,
        auto_virtualize_max_overhead=0,
        native_opaque_probability=0.0,
        native_flatten_probability=0.0,
        superinstruction_level=0,
    ),
    "normal": ObfuscationConfig(
        name="normal",
        description="Validated syntax, local renaming, compacting, protected literals, masks, one-time integrity.",
        strip_comments=True,
        minify=True,
        virtualize_strings=True,
        minimum_string_bytes=4,
        junk_probability=0.03,
        mask_vm_constants=False,
        integer_mask_probability=0.05,
        rename_locals=True,
        max_string_fragments=1,
        anti_tamper_mode="once",
        vm_polymorphism_level=1,
        auto_virtualize_min_nodes=0,
        auto_virtualize_max_overhead=0,
        native_opaque_probability=0.0,
        native_flatten_probability=0.0,
        superinstruction_level=0,
    ),
    "medium": ObfuscationConfig(
        name="medium",
        description="Polymorphic VM, safe auto-selection, cached integrity, and light native predicates.",
        strip_comments=True,
        minify=True,
        virtualize_strings=True,
        minimum_string_bytes=1,
        junk_probability=0.08,
        mask_vm_constants=False,
        integer_mask_probability=0.20,
        rename_locals=True,
        max_string_fragments=2,
        anti_tamper_mode="once",
        vm_polymorphism_level=2,
        auto_virtualize_min_nodes=24,
        auto_virtualize_max_overhead=55,
        native_opaque_probability=0.08,
        native_flatten_probability=0.0,
        superinstruction_level=1,
    ),
    "high": ObfuscationConfig(
        name="high",
        description="Aggressive VM polymorphism with native opaque predicates, state wrappers, and cached integrity.",
        strip_comments=True,
        minify=True,
        virtualize_strings=True,
        minimum_string_bytes=0,
        junk_probability=0.18,
        mask_vm_constants=True,
        integer_mask_probability=0.55,
        rename_locals=True,
        max_string_fragments=3,
        anti_tamper_mode="sampled",
        vm_polymorphism_level=3,
        auto_virtualize_min_nodes=14,
        auto_virtualize_max_overhead=85,
        native_opaque_probability=0.20,
        native_flatten_probability=0.08,
        superinstruction_level=2,
    ),
    "very-high": ObfuscationConfig(
        name="very-high",
        description="Maximum VM/native-flow variation and safe auto-selection with per-call integrity; slowest.",
        strip_comments=True,
        minify=True,
        virtualize_strings=True,
        minimum_string_bytes=0,
        junk_probability=0.32,
        mask_vm_constants=True,
        integer_mask_probability=0.90,
        rename_locals=True,
        max_string_fragments=4,
        anti_tamper_mode="always",
        vm_polymorphism_level=4,
        auto_virtualize_min_nodes=8,
        auto_virtualize_max_overhead=130,
        native_opaque_probability=0.35,
        native_flatten_probability=0.18,
        superinstruction_level=2,
    ),
    "maximum": ObfuscationConfig(
        name="maximum",
        description="Booster-only. Densest VM/native-flow variation, broadest auto-VM selection, always-on integrity.",
        strip_comments=True,
        minify=True,
        virtualize_strings=True,
        minimum_string_bytes=0,
        junk_probability=0.45,
        mask_vm_constants=True,
        integer_mask_probability=1.0,
        rename_locals=True,
        max_string_fragments=5,
        anti_tamper_mode="always",
        vm_polymorphism_level=4,
        auto_virtualize_min_nodes=4,
        auto_virtualize_max_overhead=200,
        native_opaque_probability=0.50,
        native_flatten_probability=0.30,
        superinstruction_level=2,
    ),
}


def normalize_config_name(name: str) -> str:
    return name.strip().lower().replace("_", "-").replace(" ", "-")


def get_config(name: str) -> ObfuscationConfig:
    normalized = normalize_config_name(name)
    try:
        return CONFIGS[normalized]
    except KeyError as exc:
        valid = ", ".join(CONFIGS)
        raise ValueError(f"Unknown config {name!r}. Choose one of: {valid}") from exc
