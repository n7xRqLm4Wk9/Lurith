from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .diagnostics import diagnostic_for_node
from .ir import IRBuilder, Label, ProgramIR
from .vm_common import _expression_list, _field_children, _lua_string, _parameter_nodes, _variable_list
from .vm_types import FunctionVmError

_BINARY_OPERATORS = {
    "+": "ADD",
    "-": "SUB",
    "*": "MUL",
    "/": "DIV",
    "%": "MOD",
    "^": "POW",
    "..": "CONCAT",
    "==": "EQ",
    "~=": "NE",
    "<": "LT",
    "<=": "LE",
    ">": "GT",
    ">=": "GE",
}
_UNARY_OPERATORS = {"-": "NEG", "not": "NOT", "#": "LEN"}
_UPDATE_OPERATORS = {
    "+=": "ADD",
    "-=": "SUB",
    "*=": "MUL",
    "/=": "DIV",
    "%=": "MOD",
    "^=": "POW",
    "..=": "CONCAT",
}
_MAX_CALL_ARGUMENTS = 8

# Boxed-closure-capture placeholder tokens. They contain control bytes that can
# never appear in user-written Lua identifiers, so a placeholder only ever marks
# a reference the compiler itself rewrote; function_vm.py substitutes every one
# with a real box access before the source is emitted.
_BOX_PREFIX = "\x01LURITHBOX"
# Loop-variable captures use per-iteration cells: the closure is compiled to a
# template `function(<CELLPARAM>, ...orig params...)` whose body reads
# `<CELLPARAM>[N]` for each captured loop variable, and the VM creates the
# closure as `function(...) return template(cells, ...) end` with a fresh
# `cells` table per iteration. These placeholders mark the parameter and the
# cell references for function_vm.py to name at emission time.
_CELL_PREFIX = "\x03LURITHCELL"
_CELL_PARAM = "\x03LURITHCELLPARAM\x02"


def _box_placeholder(box_number: int) -> str:
    return f"{_BOX_PREFIX}{box_number}\x02"


def _cell_placeholder(cell_number: int) -> str:
    return f"{_CELL_PREFIX}{cell_number}\x02"


def _cell_param_placeholder() -> str:
    return _CELL_PARAM


@dataclass(frozen=True, slots=True)
class _Boxed:
    number: int


def _parameter_names(source: bytes, parameters: Any) -> list[str]:
    if parameters is None:
        return []
    return [
        source[item.start_byte : item.end_byte].decode("utf-8", "replace")
        for item in _parameter_nodes(parameters)
    ]


def _walk_scoped(source: bytes, node: Any, scopes: list[set[str]], on_free_ref: Any) -> None:
    """Walk `node`, calling `on_free_ref(identifier_node, name)` for every variable
    reference that is not bound by `scopes` (a list of sets, innermost last).
    Nested function bodies are walked with their parameters bound, so a name only
    counts as free when it resolves past every enclosing closure to the caller's
    scope stack."""
    kind = node.type
    if kind == "identifier":
        name = source[node.start_byte : node.end_byte].decode("utf-8", "replace")
        if not any(name in scope for scope in reversed(scopes)):
            on_free_ref(node, name)
        return
    if kind == "function_definition":
        body = node.child_by_field_name("body")
        if body is not None:
            inner = list(scopes)
            inner.append(set(_parameter_names(source, node.child_by_field_name("parameters"))))
            _walk_scoped(source, body, inner, on_free_ref)
        return
    if kind == "function_declaration":
        name_node = node.child_by_field_name("name")
        prefix = source[node.start_byte : name_node.start_byte].lstrip() if name_node is not None else b""
        if name_node is not None and prefix.startswith(b"local"):
            scopes[-1].add(source[name_node.start_byte : name_node.end_byte].decode("utf-8", "replace"))
        body = node.child_by_field_name("body")
        if body is not None:
            inner = list(scopes)
            inner.append(set(_parameter_names(source, node.child_by_field_name("parameters"))))
            _walk_scoped(source, body, inner, on_free_ref)
        return
    if kind == "variable_declaration":
        expressions = _expression_list(node)
        values = list(expressions.named_children) if expressions is not None else []
        for value in values:
            _walk_scoped(source, value, scopes, on_free_ref)
        variables = _variable_list(node)
        if variables is not None:
            for child in variables.named_children:
                if child.type == "identifier":
                    scopes[-1].add(source[child.start_byte : child.end_byte].decode("utf-8", "replace"))
        return
    if kind == "for_statement":
        clause = node.child_by_field_name("clause")
        body = node.child_by_field_name("body")
        if clause is None or body is None:
            return
        if clause.type == "for_numeric_clause":
            for expression in (
                clause.child_by_field_name("start"),
                clause.child_by_field_name("end"),
                clause.child_by_field_name("step"),
            ):
                if expression is not None:
                    _walk_scoped(source, expression, scopes, on_free_ref)
            name = clause.child_by_field_name("name")
            inner = list(scopes)
            inner.append(
                {source[name.start_byte : name.end_byte].decode("utf-8", "replace")} if name is not None else set()
            )
            _walk_scoped(source, body, inner, on_free_ref)
            return
        if clause.type == "for_generic_clause":
            expressions = next((child for child in clause.named_children if child.type == "expression_list"), None)
            if expressions is not None:
                for expression in expressions.named_children:
                    _walk_scoped(source, expression, scopes, on_free_ref)
            variables = next((child for child in clause.named_children if child.type == "variable_list"), None)
            names: set[str] = set()
            if variables is not None:
                for child in variables.named_children:
                    if child.type == "identifier":
                        names.add(source[child.start_byte : child.end_byte].decode("utf-8", "replace"))
            inner = list(scopes)
            inner.append(names)
            _walk_scoped(source, body, inner, on_free_ref)
            return
        return
    if kind == "block":
        inner = list(scopes)
        inner.append(set())
        for child in node.named_children:
            _walk_scoped(source, child, inner, on_free_ref)
        return
    if kind == "dot_index_expression":
        table = node.child_by_field_name("table")
        if table is not None:
            _walk_scoped(source, table, scopes, on_free_ref)
        return
    if kind == "method_index_expression":
        table = node.child_by_field_name("table")
        if table is not None:
            _walk_scoped(source, table, scopes, on_free_ref)
        return
    if kind == "table_constructor":
        for field in node.named_children:
            if field.type != "field":
                _walk_scoped(source, field, scopes, on_free_ref)
                continue
            name = field.child_by_field_name("name")
            value = field.child_by_field_name("value")
            field_source = source[field.start_byte : field.end_byte].lstrip()
            if name is None or name.type == "identifier" and not field_source.startswith(b"["):
                if value is not None:
                    _walk_scoped(source, value, scopes, on_free_ref)
            else:
                _walk_scoped(source, name, scopes, on_free_ref)
                if value is not None:
                    _walk_scoped(source, value, scopes, on_free_ref)
        return
    for child in node.named_children:
        _walk_scoped(source, child, scopes, on_free_ref)


def _analyze_captures(source: bytes, body: Any, parameters: list[str]) -> tuple[set[str], set[str]]:
    """Find the VM locals/parameters that nested closures capture, split into
    static captures (bindings that live once per activation — boxable) and loop
    captures (loop variables and locals declared inside a loop body — they need a
    fresh cell per iteration, which the compiler boxes per iteration)."""

    captured: set[str] = set()
    loop_captured: set[str] = set()

    def walk(node: Any, scopes: list[set[str]], flags: list[dict[str, bool]], loop_depth: int) -> None:
        kind = node.type
        if kind in {"function_definition", "function_declaration"}:
            name_node = node.child_by_field_name("name") if kind == "function_declaration" else None
            if name_node is not None:
                name = source[name_node.start_byte : name_node.end_byte].decode("utf-8", "replace")
                prefix = source[node.start_byte : name_node.start_byte].lstrip()
                if prefix.startswith(b"local"):
                    scopes[-1].add(name)
                    flags[-1][name] = loop_depth > 0
            params = _parameter_names(source, node.child_by_field_name("parameters"))
            closure_body = node.child_by_field_name("body")
            if closure_body is not None:
                free: list[str] = []
                _walk_scoped(source, closure_body, [set(params)], lambda _node, name: free.append(name))
                for name in set(free):
                    for index in range(len(scopes) - 1, -1, -1):
                        if name in scopes[index]:
                            if flags[index].get(name, False):
                                loop_captured.add(name)
                            else:
                                captured.add(name)
                            break
            return
        if kind == "variable_declaration":
            variables = _variable_list(node)
            if variables is not None:
                for child in variables.named_children:
                    if child.type == "identifier":
                        name = source[child.start_byte : child.end_byte].decode("utf-8", "replace")
                        scopes[-1].add(name)
                        flags[-1][name] = loop_depth > 0
            return
        if kind == "for_statement":
            clause = node.child_by_field_name("clause")
            loop_body = node.child_by_field_name("body")
            if clause is None or loop_body is None:
                return
            inner = list(scopes)
            inner.append(set())
            inner_flags = list(flags)
            inner_flags.append({})
            if clause.type == "for_numeric_clause":
                name_node = clause.child_by_field_name("name")
                if name_node is not None:
                    name = source[name_node.start_byte : name_node.end_byte].decode("utf-8", "replace")
                    inner[-1].add(name)
                    inner_flags[-1][name] = True
            elif clause.type == "for_generic_clause":
                variables = next((child for child in clause.named_children if child.type == "variable_list"), None)
                if variables is not None:
                    for child in variables.named_children:
                        if child.type == "identifier":
                            name = source[child.start_byte : child.end_byte].decode("utf-8", "replace")
                            inner[-1].add(name)
                            inner_flags[-1][name] = True
            walk(loop_body, inner, inner_flags, loop_depth + 1)
            return
        if kind in {"while_statement", "repeat_statement"}:
            loop_body = node.child_by_field_name("body")
            if loop_body is not None:
                walk(loop_body, scopes, flags, loop_depth + 1)
            return
        if kind == "block":
            inner = list(scopes)
            inner.append(set())
            inner_flags = list(flags)
            inner_flags.append({})
            for child in node.named_children:
                walk(child, inner, inner_flags, loop_depth)
            return
        for child in node.named_children:
            walk(child, scopes, flags, loop_depth)

    walk(body, [set(parameters)], [{name: False for name in parameters}], 0)
    return captured, loop_captured


class _FunctionCompiler:
    def __init__(
        self,
        source: bytes,
        parameters: list[str],
        has_vararg: bool = False,
        *,
        aliasing: bool = False,
    ) -> None:
        self.source = source
        self.has_vararg = has_vararg
        self.aliasing = aliasing
        self.builder = IRBuilder()
        self.builder.program.parameter_count = len(parameters)
        self.scopes: list[dict[str, int | _Boxed]] = [{}]
        self.next_slot = 0
        self.next_box = 1
        self.boxes: dict[str, int] = {}
        self.captured: set[str] = set()
        self.loop_captured: set[str] = set()
        self.parameter_names = list(parameters)
        self.break_targets: list[Label] = []
        self.continue_targets: list[Label] = []
        for parameter in parameters:
            self.scopes[0][parameter] = self._allocate_slot()

    def _text(self, node: Any) -> str:
        return self.source[node.start_byte : node.end_byte].decode("utf-8", "replace")

    def _emit_op(self, opcode: str) -> None:
        """Emit a binary instruction, aliasing paired operations when enabled.

        ADD/SUB share one opcode (ALU_DUAL) and EQ/NE share another (CMP_DUAL);
        the semantic operand (0 = ADD/EQ, 1 = SUB/NE) is inverted at assembly
        time per build, so the runtime needs a secondary discriminant to recover
        the operation.
        """
        if self.aliasing and opcode in {"ADD", "SUB"}:
            self.builder.emit("ALU_DUAL", {"ADD": 0, "SUB": 1}[opcode])
        elif self.aliasing and opcode in {"EQ", "NE"}:
            self.builder.emit("CMP_DUAL", {"EQ": 0, "NE": 1}[opcode])
        else:
            self.builder.emit(opcode)

    def _unsupported(self, node: Any, feature: str) -> None:
        raise FunctionVmError(diagnostic_for_node(self.source, node, feature).format())

    def _allocate_slot(self) -> int:
        self.next_slot += 1
        self.builder.program.local_count = max(self.builder.program.local_count, self.next_slot)
        return self.next_slot

    def _new_box(self) -> _Boxed:
        box = _Boxed(self.next_box)
        self.next_box += 1
        return box

    def _declare(self, name: str) -> int | _Boxed:
        if name in self.captured:
            box = self._new_box()
            self.boxes[name] = box.number
            self.scopes[-1][name] = box
            return box
        slot = self._allocate_slot()
        self.scopes[-1][name] = slot
        return slot

    def _lookup(self, name: str) -> int | _Boxed | None:
        for scope in reversed(self.scopes):
            if name in scope:
                return scope[name]
        return None

    def _enter_scope(self) -> None:
        self.scopes.append({})

    def _leave_scope(self) -> None:
        self.scopes.pop()

    def compile_expression(self, node: Any) -> None:
        kind = node.type
        if kind == "identifier":
            name = self._text(node)
            storage = self._lookup(name)
            if isinstance(storage, _Boxed):
                self.builder.emit("GET_BOX", storage.number)
            elif storage is not None:
                self.builder.emit("GET_LOCAL", storage)
            else:
                self.builder.emit("GET_EXT", self.builder.external(name))
            return

        if kind in {"number", "string"}:
            text = self._text(node)
            if kind == "string" and text.startswith("`"):
                # Luau interpolated/backtick strings lower to a constant that
                # would either lose its `{expr}` bindings or crash the numeric
                # canary path. Keep them native (fail-closed) rather than risk
                # a wrong value; the rest of the pipeline preserves them.
                self._unsupported(node, "backtick string literal")
            self.builder.emit("CONST", self.builder.constant(text))
            return
        if kind in {"true", "false", "nil"}:
            self.builder.emit(kind.upper())
            return
        if kind == "vararg_expression":
            if not self.has_vararg:
                self._unsupported(node, "vararg outside a vararg function")
            self.builder.emit("GET_VARARG", 1)
            return

        if kind == "parenthesized_expression":
            children = node.named_children
            if len(children) != 1:
                self._unsupported(node, "parenthesized expression")
            self.compile_expression(children[0])
            return

        if kind == "unary_expression":
            operand = node.child_by_field_name("operand")
            if operand is None:
                self._unsupported(node, "unary expression")
            operator = self.source[node.start_byte : operand.start_byte].decode("ascii", "ignore").strip()
            instruction = _UNARY_OPERATORS.get(operator)
            if instruction is None:
                self._unsupported(node, f"unary operator {operator!r}")
            self.compile_expression(operand)
            self.builder.emit(instruction)
            return

        if kind == "binary_expression":
            left = node.child_by_field_name("left")
            right = node.child_by_field_name("right")
            if left is None or right is None:
                self._unsupported(node, "binary expression")
            operator = self.source[left.end_byte : right.start_byte].decode("ascii", "ignore").strip()
            if operator in {"and", "or"}:
                self.compile_expression(left)
                end = self.builder.new_label()
                self.builder.emit("JFALSE_KEEP" if operator == "and" else "JTRUE_KEEP", end)
                self.builder.emit("POP")
                self.compile_expression(right)
                self.builder.mark(end)
                return
            if operator == "//":
                # Floor division is Luau-only syntax. Lower to math.floor(a / b)
                # so the generated runtime stays valid Lua 5.1 as well.
                self.builder.emit("GET_EXT", self.builder.external("math.floor"))
                self.compile_expression(left)
                self.compile_expression(right)
                self.builder.emit("DIV")
                self.builder.emit("CALL", 1)
                return
            instruction = _BINARY_OPERATORS.get(operator)
            if instruction is None:
                self._unsupported(node, f"operator {operator!r}")
            self.compile_expression(left)
            self.compile_expression(right)
            self._emit_op(instruction)
            return

        if kind in {"bracket_index_expression", "dot_index_expression"}:
            table = node.child_by_field_name("table")
            field = node.child_by_field_name("field")
            if table is None or field is None:
                self._unsupported(node, "table index")
            self.compile_expression(table)
            if kind == "dot_index_expression":
                self.builder.emit("CONST", self.builder.constant(_lua_string(self._text(field))))
            else:
                self.compile_expression(field)
            self.builder.emit("GET_INDEX")
            return

        if kind == "table_constructor":
            self._compile_table_constructor(node)
            return

        if kind == "function_call":
            self._compile_call(node)
            return

        if kind == "function_definition":
            self._compile_function_definition(node)
            return

        if kind == "if_expression":
            self._compile_if_expression(node)
            return

        self._unsupported(node, kind)

    def _compile_if_expression(self, node: Any) -> None:
        """Lower a Luau `if a then b elseif c then d else e` expression.

        Lowers to the same conditional-jump shape as `and`/`or`, leaving one
        value on the stack. An else branch is required (Luau if-expressions are
        values), so a missing else fails closed.
        """
        condition = node.child_by_field_name("condition")
        consequence = node.child_by_field_name("consequence")
        if condition is None or consequence is None:
            self._unsupported(node, "if expression")
        else_clauses: list[Any] = []
        else_value: Any | None = None
        for child in node.named_children:
            if child.type == "elseif_clause":
                else_clauses.append(child)
            elif child.type == "else_clause":
                named = child.named_children
                else_value = named[0] if len(named) == 1 else None
        if else_value is None:
            self._unsupported(node, "if expression without an else branch")
        end = self.builder.new_label()
        following = self.builder.new_label()
        self.compile_expression(condition)
        self.builder.emit("JFALSE_POP", following)
        self.compile_expression(consequence)
        self.builder.emit("JUMP", end)
        self.builder.mark(following)
        for clause in else_clauses:
            clause_condition = clause.child_by_field_name("condition")
            clause_consequence = clause.child_by_field_name("consequence")
            if clause_condition is None or clause_consequence is None:
                self._unsupported(clause, "elseif expression")
            following = self.builder.new_label()
            self.compile_expression(clause_condition)
            self.builder.emit("JFALSE_POP", following)
            self.compile_expression(clause_consequence)
            self.builder.emit("JUMP", end)
            self.builder.mark(following)
        self.compile_expression(else_value)
        self.builder.mark(end)

    def _compile_function_definition(self, node: Any) -> None:
        """Lower an anonymous function expression to a native closure.

        The closure is emitted verbatim as native Lua and stored as an external, so
        it runs untouched. References to VM locals the closure captures are
        rewritten to box accesses (a mutable one-element table shared with the VM),
        so capture-by-reference keeps working; anything else that is neither a
        global nor a captured box rejects the function (fail-closed).
        """
        parameters = node.child_by_field_name("parameters")
        body = node.child_by_field_name("body")
        if body is None:
            self._unsupported(node, "function definition without a body")
        expression, loop_refs = self._rewrite_closure(node, body, parameters)
        if loop_refs:
            # Loop-variable capture: build a fresh cells table per iteration and
            # close the template over it. The cells table carries the captured
            # loop variable values so each closure sees its own iteration's value.
            template_index = self.builder.external("(" + expression + ")")
            self.builder.emit("NEW_TABLE")
            for name, cell_number in sorted(loop_refs.items(), key=lambda pair: pair[1]):
                storage = self._lookup(name)
                if storage is None or isinstance(storage, _Boxed):
                    self._unsupported(node, "loop capture of a value that is not a loop-local slot")
                self.builder.emit("CONST", self.builder.constant(str(cell_number)))
                self.builder.emit("GET_LOCAL", storage)
                self.builder.emit("SET_INDEX_KEEP")
            self.builder.emit("CLOSE_OVER", template_index)
        else:
            self.builder.emit("GET_EXT", self.builder.external("(" + expression + ")"))

    def _rewrite_closure(self, node: Any, body: Any, parameters: Any) -> tuple[str, dict[str, int]]:
        """Return the closure's source slice with captured VM locals rewritten.

        Static captures become box placeholders; loop-variable captures become
        per-iteration cell references inside a template that takes the cells table
        as its first parameter. Returns (expression, loop_refs) where loop_refs
        maps each loop-captured name to its cell number in reference order."""
        start_byte = node.start_byte
        end_byte = node.end_byte
        params = _parameter_names(self.source, parameters)
        visible_names = {name for scope in self.scopes for name in scope}
        replacements: list[tuple[int, int, str]] = []
        loop_refs: dict[str, int] = {}

        def on_free_ref(ref_node: Any, name: str) -> None:
            if name in self.captured and name in self.loop_captured:
                # The same name is captured from both a loop scope and a non-loop
                # scope somewhere in the function; fail closed rather than guess.
                self._unsupported(
                    ref_node, "nested closure captures the same name from loop and non-loop scopes"
                )
            if name in self.captured:
                replacements.append(
                    (ref_node.start_byte, ref_node.end_byte, _box_placeholder(self.boxes[name]))
                )
            elif name in self.loop_captured:
                cell_number = loop_refs.setdefault(name, len(loop_refs) + 1)
                replacements.append(
                    (ref_node.start_byte, ref_node.end_byte, _cell_placeholder(cell_number))
                )
            elif name in visible_names:
                self._unsupported(ref_node, "nested closure capture of a VM local")

        _walk_scoped(self.source, body, [set(params)], on_free_ref)
        if loop_refs:
            # The template receives the cells table as its first parameter.
            if parameters is None:
                self._unsupported(node, "closure without a parameter list")
            if params:
                replacements.append(
                    (parameters.start_byte + 1, parameters.start_byte + 1, _cell_param_placeholder() + ", ")
                )
            else:
                replacements.append(
                    (parameters.start_byte + 1, parameters.start_byte + 1, _cell_param_placeholder())
                )
        if not replacements:
            return self.source[start_byte:end_byte].decode("utf-8", "replace"), loop_refs
        pieces: list[str] = []
        cursor = start_byte
        for ref_start, ref_end, replacement in sorted(replacements):
            pieces.append(self.source[cursor:ref_start].decode("utf-8", "replace"))
            pieces.append(replacement)
            cursor = ref_end
        pieces.append(self.source[cursor:end_byte].decode("utf-8", "replace"))
        return "".join(pieces), loop_refs

    def _compile_table_constructor(self, node: Any) -> None:
        fields = [child for child in node.named_children if child.type == "field"]
        self.builder.emit("NEW_TABLE")
        array_index = 1
        for position, field in enumerate(fields):
            name = field.child_by_field_name("name")
            value = field.child_by_field_name("value")
            if value is None:
                self._unsupported(field, "table field without a value")
            expands_last_list_field = (
                name is None
                and position == len(fields) - 1
                and value.type in {"function_call", "vararg_expression"}
            )
            if expands_last_list_field:
                if value.type == "function_call":
                    self._compile_call(value, pack_results=True)
                else:
                    if not self.has_vararg:
                        self._unsupported(value, "vararg expansion outside a vararg function")
                    self.builder.emit("PACK_VARARG")
                self.builder.emit("TABLE_APPEND_PACK", array_index)
                continue
            if name is None:
                self.builder.emit("CONST", self.builder.constant(str(array_index)))
                array_index += 1
            else:
                field_source = self.source[field.start_byte : field.end_byte].lstrip()
                if field_source.startswith(b"["):
                    self.compile_expression(name)
                else:
                    self.builder.emit("CONST", self.builder.constant(_lua_string(self._text(name))))
            self.compile_expression(value)
            self.builder.emit("SET_INDEX_KEEP")

    def _argument_nodes(self, arguments: Any) -> list[Any]:
        if arguments.type != "arguments":
            return [arguments]
        result: list[Any] = []
        for child in arguments.named_children:
            if child.type == "expression_list":
                result.extend(child.named_children)
            else:
                result.append(child)
        return result

    def _compile_call_frame(self, node: Any) -> tuple[int, str]:
        function = node.child_by_field_name("name")
        arguments = node.child_by_field_name("arguments")
        if function is None or arguments is None:
            self._unsupported(node, "function call")
        argument_nodes = self._argument_nodes(arguments)
        expansion = "none"
        trailing_call: Any | None = None
        if argument_nodes and argument_nodes[-1].type == "function_call":
            expansion = "packed"
            trailing_call = argument_nodes.pop()
        elif argument_nodes and argument_nodes[-1].type == "vararg_expression":
            if not self.has_vararg:
                self._unsupported(argument_nodes[-1], "vararg expansion outside a vararg function")
            expansion = "vararg"
            argument_nodes.pop()

        method = function.type == "method_index_expression"
        if method:
            table = function.child_by_field_name("table")
            method_name = function.child_by_field_name("method")
            if table is None or method_name is None:
                self._unsupported(function, "method call")
            self.compile_expression(table)
            self.builder.emit("GET_METHOD", self.builder.constant(_lua_string(self._text(method_name))))
        else:
            self.compile_expression(function)

        argument_count = len(argument_nodes) + (1 if method else 0)
        if argument_count > _MAX_CALL_ARGUMENTS:
            self._unsupported(node, f"call with more than {_MAX_CALL_ARGUMENTS} fixed arguments")
        for argument in argument_nodes:
            self.compile_expression(argument)
        if trailing_call is not None:
            self._compile_call(trailing_call, pack_results=True)
        return argument_count, expansion

    def _compile_call(self, node: Any, *, pack_results: bool = False, tail: bool = False) -> None:
        argument_count, expansion = self._compile_call_frame(node)
        if tail:
            opcode = {
                "none": "TAIL_CALL",
                "vararg": "TAIL_CALL_VARARG",
                "packed": "TAIL_CALL_EXPANDED",
            }[expansion]
        elif pack_results:
            opcode = {
                "none": "CALL_PACK",
                "vararg": "CALL_VARARG_PACK",
                "packed": "CALL_EXPANDED_PACK",
            }[expansion]
        else:
            opcode = {
                "none": "CALL",
                "vararg": "CALL_VARARG",
                "packed": "CALL_EXPANDED",
            }[expansion]
        self.builder.emit(opcode, argument_count)

    def compile_block(self, block: Any, *, new_scope: bool = True) -> None:
        if new_scope:
            self._enter_scope()
        try:
            for statement in block.named_children:
                if statement.type == "comment":
                    continue
                self.compile_statement(statement)
        finally:
            if new_scope:
                self._leave_scope()

    def compile_statement(self, node: Any) -> None:
        kind = node.type
        if kind in {"empty_statement", "comment"}:
            return
        if kind == "variable_declaration":
            self._compile_local_declaration(node)
            return
        if kind == "assignment_statement":
            self._compile_assignment(node)
            return
        if kind == "update_statement":
            self._compile_update(node)
            return
        if kind == "if_statement":
            self._compile_if(node)
            return
        if kind == "while_statement":
            self._compile_while(node)
            return
        if kind == "repeat_statement":
            self._compile_repeat(node)
            return
        if kind == "for_statement":
            self._compile_for(node)
            return
        if kind == "do_statement":
            body = node.child_by_field_name("body")
            if body is None:
                body = next((child for child in node.named_children if child.type == "block"), None)
            if body is None:
                self._unsupported(node, "do block")
            self.compile_block(body)
            return
        if kind == "function_declaration":
            self._compile_nested_function(node)
            return
        if kind == "function_call":
            self.compile_expression(node)
            self.builder.emit("POP")
            return
        if kind == "return_statement":
            self._compile_return(node)
            return
        if kind == "break_statement":
            if not self.break_targets:
                self._unsupported(node, "break outside a VM-supported loop")
            self.builder.emit("JUMP", self.break_targets[-1])
            return
        if kind == "continue_statement":
            if not self.continue_targets:
                self._unsupported(node, "continue outside a VM-supported loop")
            self.builder.emit("JUMP", self.continue_targets[-1])
            return
        self._unsupported(node, f"statement {kind}")

    def _compile_nested_function(self, node: Any) -> None:
        name = node.child_by_field_name("name")
        parameters = node.child_by_field_name("parameters")
        body = node.child_by_field_name("body")
        if name is None or name.type != "identifier" or parameters is None or body is None:
            self._unsupported(node, "nested method or non-local function declaration")
        prefix = self.source[node.start_byte : name.start_byte].lstrip()
        if not prefix.startswith(b"local"):
            self._unsupported(node, "nested non-local function declaration")
        function_name = self._text(name)
        # Declare the name first so a recursive self-reference is captured through
        # the same box (boxing makes `local function f() ... f() ... end` work).
        storage = self._declare(function_name)
        body_slice, loop_refs = self._rewrite_closure(node, body, parameters)
        # Named functions declared inside a loop that capture the loop variable
        # stay native: per-iteration boxing interacts with the name binding and
        # recursive self-reference in ways that are not yet supported safely.
        if loop_refs:
            self._unsupported(node, "named function inside a loop that captures a loop variable")
        expression = "(function" + body_slice[parameters.start_byte - node.start_byte :] + ")"
        external_index = self.builder.external(expression)
        self.builder.emit("GET_EXT", external_index)
        if isinstance(storage, _Boxed):
            self.builder.emit("SET_BOX", storage.number)
        else:
            self.builder.emit("SET_LOCAL", storage)

    def _compile_values(self, expressions: list[Any], target_count: int) -> None:
        expands_last = (
            bool(expressions)
            and len(expressions) < target_count
            and expressions[-1].type in {"function_call", "vararg_expression"}
        )
        if expands_last:
            for expression in expressions[:-1]:
                self.compile_expression(expression)
            last = expressions[-1]
            if last.type == "function_call":
                self._compile_call(last, pack_results=True)
            else:
                if not self.has_vararg:
                    self._unsupported(last, "vararg expansion outside a vararg function")
                self.builder.emit("PACK_VARARG")
            self.builder.emit("EXPAND_FIXED", target_count - len(expressions) + 1)
            return

        for expression in expressions:
            self.compile_expression(expression)
        if len(expressions) < target_count:
            for _ in range(target_count - len(expressions)):
                self.builder.emit("NIL")
        elif len(expressions) > target_count:
            for _ in range(len(expressions) - target_count):
                self.builder.emit("POP")

    def _compile_local_declaration(self, node: Any) -> None:
        variables = _variable_list(node)
        if variables is None:
            self._unsupported(node, "local declaration")
        names = [child for child in variables.named_children if child.type == "identifier"]
        if not names:
            self._unsupported(node, "destructured local declaration")
        expression_list = _expression_list(node)
        expressions = list(expression_list.named_children) if expression_list is not None else []
        self._compile_values(expressions, len(names))
        storages = [self._declare(self._text(name)) for name in names]
        for storage in reversed(storages):
            if isinstance(storage, _Boxed):
                self.builder.emit("SET_BOX", storage.number)
            else:
                self.builder.emit("SET_LOCAL", storage)

    def _compile_assignment(self, node: Any) -> None:
        variables = _variable_list(node)
        expression_list = _expression_list(node)
        if variables is None or expression_list is None:
            self._unsupported(node, "assignment")
        targets = list(variables.named_children)
        expressions = list(expression_list.named_children)
        if len(targets) == 1 and targets[0].type in {"bracket_index_expression", "dot_index_expression"}:
            target = targets[0]
            table = target.child_by_field_name("table")
            field = target.child_by_field_name("field")
            if table is None or field is None:
                self._unsupported(target, "table assignment target")
            self.compile_expression(table)
            if target.type == "dot_index_expression":
                self.builder.emit("CONST", self.builder.constant(_lua_string(self._text(field))))
            else:
                self.compile_expression(field)
            self._compile_values(expressions, 1)
            self.builder.emit("SET_INDEX")
            return
        if not targets or any(target.type != "identifier" for target in targets):
            self._unsupported(node, "mixed or multiple non-local assignment targets")
        if len(targets) == 1 and self._lookup(self._text(targets[0])) is None:
            self._compile_values(expressions, 1)
            self.builder.emit("SET_EXT", self.builder.external(self._text(targets[0])))
            return
        targets_ref: list[tuple[str, int]] = []
        for target in targets:
            storage = self._lookup(self._text(target))
            if isinstance(storage, _Boxed):
                targets_ref.append(("box", storage.number))
            elif storage is not None:
                targets_ref.append(("local", storage))
            else:
                targets_ref.append(("external", self.builder.external(self._text(target))))
        self._compile_values(expressions, len(targets_ref))
        for kind, reference in reversed(targets_ref):
            if kind == "box":
                self.builder.emit("SET_BOX", reference)
            else:
                self.builder.emit("SET_LOCAL" if kind == "local" else "SET_EXT", reference)

    def _compile_update(self, node: Any) -> None:
        variables = _variable_list(node)
        expression_list = _expression_list(node)
        if variables is None or expression_list is None:
            self._unsupported(node, "compound assignment")
        targets = list(variables.named_children)
        expressions = list(expression_list.named_children)
        if len(targets) != 1 or targets[0].type != "identifier" or len(expressions) != 1:
            self._unsupported(node, "compound assignment shape")
        name = self._text(targets[0])
        storage = self._lookup(name)
        operator_source = self.source[variables.end_byte : expression_list.start_byte].decode("ascii", "ignore").strip()
        if operator_source == "//=":
            # x //= y  =>  x = math.floor(x / y), valid Lua 5.1 and Luau alike.
            if isinstance(storage, _Boxed):
                self.builder.emit("GET_EXT", self.builder.external("math.floor"))
                self.builder.emit("GET_BOX", storage.number)
                self.compile_expression(expressions[0])
                self.builder.emit("DIV")
                self.builder.emit("CALL", 1)
                self.builder.emit("SET_BOX", storage.number)
                return
            if storage is None:
                external = self.builder.external(name)
                self.builder.emit("GET_EXT", self.builder.external("math.floor"))
                self.builder.emit("GET_EXT", external)
                self.compile_expression(expressions[0])
                self.builder.emit("DIV")
                self.builder.emit("CALL", 1)
                self.builder.emit("SET_EXT", external)
                return
            self.builder.emit("GET_EXT", self.builder.external("math.floor"))
            self.builder.emit("GET_LOCAL", storage)
            self.compile_expression(expressions[0])
            self.builder.emit("DIV")
            self.builder.emit("CALL", 1)
            self.builder.emit("SET_LOCAL", storage)
            return
        instruction = _UPDATE_OPERATORS.get(operator_source)
        if instruction is None:
            self._unsupported(node, f"compound operator {operator_source!r}")
        if isinstance(storage, _Boxed):
            self.builder.emit("GET_BOX", storage.number)
            self.compile_expression(expressions[0])
            self._emit_op(instruction)
            self.builder.emit("SET_BOX", storage.number)
            return
        if storage is None:
            external = self.builder.external(name)
            self.builder.emit("GET_EXT", external)
            self.compile_expression(expressions[0])
            self._emit_op(instruction)
            self.builder.emit("SET_EXT", external)
            return
        self.builder.emit("GET_LOCAL", storage)
        self.compile_expression(expressions[0])
        self._emit_op(instruction)
        self.builder.emit("SET_LOCAL", storage)

    def _compile_if(self, node: Any) -> None:
        end = self.builder.new_label()
        condition = node.child_by_field_name("condition")
        consequence = node.child_by_field_name("consequence")
        if condition is None or consequence is None:
            self._unsupported(node, "if statement")
        next_branch = self.builder.new_label()
        self.compile_expression(condition)
        self.builder.emit("JFALSE_POP", next_branch)
        self.compile_block(consequence)
        self.builder.emit("JUMP", end)
        self.builder.mark(next_branch)

        for alternative in _field_children(node, "alternative"):
            if alternative.type == "elseif_statement":
                alternative_condition = alternative.child_by_field_name("condition")
                alternative_body = alternative.child_by_field_name("consequence")
                if alternative_condition is None or alternative_body is None:
                    self._unsupported(alternative, "elseif statement")
                following = self.builder.new_label()
                self.compile_expression(alternative_condition)
                self.builder.emit("JFALSE_POP", following)
                self.compile_block(alternative_body)
                self.builder.emit("JUMP", end)
                self.builder.mark(following)
            elif alternative.type == "else_statement":
                body = alternative.child_by_field_name("body")
                if body is None:
                    body = next((child for child in alternative.named_children if child.type == "block"), None)
                if body is None:
                    self._unsupported(alternative, "else statement")
                self.compile_block(body)
            else:
                self._unsupported(alternative, f"if alternative {alternative.type}")
        self.builder.mark(end)

    def _compile_while(self, node: Any) -> None:
        condition = node.child_by_field_name("condition")
        body = node.child_by_field_name("body")
        if condition is None or body is None:
            self._unsupported(node, "while statement")
        start = self.builder.new_label()
        end = self.builder.new_label()
        self.builder.mark(start)
        self.compile_expression(condition)
        self.builder.emit("JFALSE_POP", end)
        self.break_targets.append(end)
        self.continue_targets.append(start)
        try:
            self.compile_block(body)
        finally:
            self.continue_targets.pop()
            self.break_targets.pop()
        self.builder.emit("JUMP", start)
        self.builder.mark(end)

    def _compile_repeat(self, node: Any) -> None:
        body = node.child_by_field_name("body")
        condition = node.child_by_field_name("condition")
        if body is None or condition is None:
            self._unsupported(node, "repeat statement")
        start = self.builder.new_label()
        condition_label = self.builder.new_label()
        end = self.builder.new_label()
        self.builder.mark(start)
        self._enter_scope()
        self.break_targets.append(end)
        self.continue_targets.append(condition_label)
        try:
            self.compile_block(body, new_scope=False)
            self.builder.mark(condition_label)
            self.compile_expression(condition)
            self.builder.emit("JFALSE_POP", start)
        finally:
            self.continue_targets.pop()
            self.break_targets.pop()
            self._leave_scope()
        self.builder.mark(end)

    def _compile_for(self, node: Any) -> None:
        clause = node.child_by_field_name("clause")
        body = node.child_by_field_name("body")
        if clause is None or body is None:
            self._unsupported(node, "for loop")
        if clause.type == "for_generic_clause":
            self._compile_generic_for(clause, body)
            return
        if clause.type != "for_numeric_clause":
            self._unsupported(node, f"for clause {clause.type}")
        name = clause.child_by_field_name("name")
        start_expression = clause.child_by_field_name("start")
        end_expression = clause.child_by_field_name("end")
        step_expression = clause.child_by_field_name("step")
        if name is None or start_expression is None or end_expression is None:
            self._unsupported(node, "numeric for loop")

        control_slot = self._allocate_slot()
        limit_slot = self._allocate_slot()
        step_slot = self._allocate_slot()
        self.compile_expression(start_expression)
        self.builder.emit("SET_LOCAL", control_slot)
        self.builder.emit("COERCE_NUMBER", control_slot)
        self.compile_expression(end_expression)
        self.builder.emit("SET_LOCAL", limit_slot)
        self.builder.emit("COERCE_NUMBER", limit_slot)
        if step_expression is None:
            self.builder.emit("CONST", self.builder.constant("1"))
        else:
            self.compile_expression(step_expression)
        self.builder.emit("SET_LOCAL", step_slot)
        self.builder.emit("COERCE_NUMBER", step_slot)
        self.builder.emit("CHECK_STEP", step_slot)

        self._enter_scope()
        visible_slot = self._declare(self._text(name))
        check = self.builder.new_label()
        negative = self.builder.new_label()
        body_label = self.builder.new_label()
        increment = self.builder.new_label()
        end = self.builder.new_label()
        self.builder.mark(check)
        self.builder.emit("GET_LOCAL", step_slot)
        self.builder.emit("CONST", self.builder.constant("0"))
        self.builder.emit("GT")
        self.builder.emit("JFALSE_POP", negative)
        self.builder.emit("GET_LOCAL", control_slot)
        self.builder.emit("GET_LOCAL", limit_slot)
        self.builder.emit("LE")
        self.builder.emit("JFALSE_POP", end)
        self.builder.emit("JUMP", body_label)
        self.builder.mark(negative)
        self.builder.emit("GET_LOCAL", control_slot)
        self.builder.emit("GET_LOCAL", limit_slot)
        self.builder.emit("GE")
        self.builder.emit("JFALSE_POP", end)
        self.builder.mark(body_label)
        self.builder.emit("GET_LOCAL", control_slot)
        self.builder.emit("SET_LOCAL", visible_slot)
        self.break_targets.append(end)
        self.continue_targets.append(increment)
        try:
            self.compile_block(body)
        finally:
            self.continue_targets.pop()
            self.break_targets.pop()
        self.builder.mark(increment)
        self.builder.emit("GET_LOCAL", control_slot)
        self.builder.emit("GET_LOCAL", step_slot)
        self._emit_op("ADD")
        self.builder.emit("SET_LOCAL", control_slot)
        self.builder.emit("JUMP", check)
        self.builder.mark(end)
        self._leave_scope()

    def _compile_generic_for(self, clause: Any, body: Any) -> None:
        variables = next((child for child in clause.named_children if child.type == "variable_list"), None)
        expressions = next((child for child in clause.named_children if child.type == "expression_list"), None)
        if variables is None or expressions is None:
            self._unsupported(clause, "generic for shape")
        names = [child for child in variables.named_children if child.type == "identifier"]
        values = list(expressions.named_children)
        if not 1 <= len(names) <= 4:
            self._unsupported(variables, "generic for with more than four variables")

        iterator_slot = self._allocate_slot()
        state_slot = self._allocate_slot()
        control_slot = self._allocate_slot()
        if len(values) == 1 and values[0].type == "function_call":
            argument_count, expansion = self._compile_call_frame(values[0])
            if expansion != "none":
                self._unsupported(values[0], "result-list expansion in a generic for initializer")
            self.builder.emit("CALL_MULTI3", argument_count, iterator_slot, state_slot, control_slot)
        elif len(values) == 3 and all(value.type != "function_call" for value in values):
            for value in values:
                self.compile_expression(value)
            for slot in (control_slot, state_slot, iterator_slot):
                self.builder.emit("SET_LOCAL", slot)
        else:
            self._unsupported(expressions, "generic for iterator expression list")

        self._enter_scope()
        variable_slots = [self._declare(self._text(name)) for name in names]
        start = self.builder.new_label()
        end = self.builder.new_label()
        self.builder.mark(start)
        self.builder.emit(
            "GENERIC_NEXT",
            iterator_slot,
            state_slot,
            control_slot,
            len(variable_slots),
            *variable_slots,
            end,
        )
        self.break_targets.append(end)
        self.continue_targets.append(start)
        try:
            self.compile_block(body)
        finally:
            self.continue_targets.pop()
            self.break_targets.pop()
        self.builder.emit("JUMP", start)
        self.builder.mark(end)
        self._leave_scope()

    def _compile_return(self, node: Any) -> None:
        expression_list = next((child for child in node.named_children if child.type == "expression_list"), None)
        expressions = list(expression_list.named_children) if expression_list is not None else []
        if len(expressions) == 1 and expressions[0].type == "function_call":
            self._compile_call(expressions[0], tail=True)
            self.builder.program.returns_multiple = True
            return
        if len(expressions) == 1 and expressions[0].type == "vararg_expression":
            if not self.has_vararg:
                self._unsupported(expressions[0], "vararg return outside a vararg function")
            self.builder.emit("RETURN_VARARG")
            self.builder.program.returns_multiple = True
            return
        if len(expressions) > 1 and expressions[-1].type == "vararg_expression":
            self._unsupported(node, "mixed fixed and vararg return values")
        if len(expressions) > 8:
            self._unsupported(node, "more than eight fixed expressions in a return list")
        if not expressions:
            # Bare `return`: zero values, not a single nil.
            self.builder.emit("RETURN_NONE")
            self.builder.program.returns_multiple = True
            return
        expands_last = expressions[-1].type in {"function_call", "vararg_expression"}
        if expands_last:
            for expression in expressions[:-1]:
                self.compile_expression(expression)
            last = expressions[-1]
            if last.type == "function_call":
                self._compile_call(last, pack_results=True)
            else:
                if not self.has_vararg:
                    self._unsupported(last, "vararg expansion outside a vararg function")
                self.builder.emit("PACK_VARARG")
            self.builder.emit("RETURN_EXPANDED", len(expressions) - 1)
            self.builder.program.returns_multiple = True
            return
        for expression in expressions:
            self.compile_expression(expression)
        if len(expressions) == 1:
            self.builder.emit("RETURN")
        else:
            self.builder.emit("RETURN_MULTI", len(expressions))
            self.builder.program.returns_multiple = True

    def compile(self, body: Any) -> ProgramIR:
        self.captured, self.loop_captured = _analyze_captures(self.source, body, self.parameter_names)
        # Captured parameters are copied from their register slot (filled by the
        # generic frame init) into their box before any user code runs.
        for name in self.parameter_names:
            if name in self.captured:
                slot = self.scopes[0][name]
                box = self._new_box()
                self.boxes[name] = box.number
                self.scopes[0][name] = box
                self.builder.emit("GET_LOCAL", slot)
                self.builder.emit("SET_BOX", box.number)
        self.compile_block(body, new_scope=False)
        # Falling off the end of a function returns zero values in Lua.
        self.builder.emit("RETURN_NONE")
        self.builder.program.returns_multiple = True
        self.builder.program.box_count = self.next_box - 1
        return self.builder.program
