from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .vm import RandomLike
from .vm_common import _walk
from .vm_profile import NameStyle, random_identifier


@dataclass(frozen=True, slots=True)
class NativeFlowResult:
    source: str
    opaque_predicates: int
    flattened_statements: int

    @property
    def transformed_statements(self) -> int:
        return self.opaque_predicates + self.flattened_statements


_ANCHOR_ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_!."


def _anchor_string(rng: RandomLike, minimum: int = 16, maximum: int = 40) -> str:
    """A random ASCII string used as a runtime anchor.

    These literals are embedded into the generated control-flow guards and are
    later virtualized by the literal VM (string.char(...) constructions), so the
    guard inputs exist only at runtime and cannot be constant-folded statically.
    """
    length = rng.randint(minimum, maximum)
    return "".join(rng.choice(_ANCHOR_ALPHABET) for _ in range(length))


def _statement_candidate(node: Any, protected_prefix_bytes: int) -> bool:
    if node.start_byte < protected_prefix_bytes or node.parent is None:
        return False
    if node.parent.type not in {"block", "chunk"}:
        return False
    return node.type in {"assignment_statement", "update_statement", "function_call"}


def obfuscate_native_control_flow(
    source: str,
    tree: Any,
    rng: RandomLike,
    *,
    protected_prefix_bytes: int = 0,
    opaque_probability: float = 0.0,
    flatten_probability: float = 0.0,
    name_style: NameStyle = "underscore",
) -> NativeFlowResult:
    if opaque_probability <= 0 and flatten_probability <= 0:
        return NativeFlowResult(source, 0, 0)

    encoded = source.encode("utf-8")
    used_names = {
        encoded[node.start_byte : node.end_byte].decode("utf-8", "replace")
        for node in _walk(tree.root_node)
        if node.type == "identifier"
    }
    guard_name = random_identifier(rng, used_names, name_style, 8, 14)
    modulus = rng.choice([65_521, 131_071, 524_287, 1_000_003])
    multiplier = rng.randint(17, min(4093, modulus - 2))
    increment = rng.randint(3, modulus - 2)

    replacements: list[tuple[int, int, bytes]] = []
    opaque_count = 0
    flattened_count = 0
    for node in _walk(tree.root_node):
        if not _statement_candidate(node, protected_prefix_bytes):
            continue
        if any(node.start_byte < end and start < node.end_byte for start, end, _ in replacements):
            continue
        flatten = rng.random() < flatten_probability
        opaque = not flatten and rng.random() < opaque_probability
        if not flatten and not opaque:
            continue
        original = encoded[node.start_byte : node.end_byte].decode("utf-8", "replace")

        # Runtime anchor: a string whose first byte drives the predicate. The
        # literal VM rewrites it to string.char(...), so the value exists only at
        # execution time and `guard(anchor)` cannot be reduced to a constant.
        anchor = _anchor_string(rng)
        first_byte = ord(anchor[0])
        expected = (first_byte * multiplier + increment) % modulus
        wrong = (expected + rng.randint(1, modulus - 1)) % modulus
        predicate_style = rng.randint(0, 2)
        if predicate_style == 0:
            predicate = f'{guard_name}("{anchor}")=={expected}'
        elif predicate_style == 1:
            predicate = f'{guard_name}("{anchor}")~={wrong}'
        else:
            predicate = f'not({guard_name}("{anchor}")=={wrong})'

        if flatten:
            anchor_name = random_identifier(rng, used_names, name_style, 6, 11)
            state_name = random_identifier(rng, used_names, name_style, 6, 11)
            step = rng.randint(2, 1000)
            distance = rng.randint(3, 997)
            replacement = (
                f' do local {anchor_name}="{anchor}";local {state_name}=(#{anchor_name})*{step};repeat '
                f"if {state_name}==(#{anchor_name})*{step} then "
                f"if {guard_name}({anchor_name})=={expected} then {original} end;"
                f"{state_name}=(#{anchor_name})*{step}+{distance} end "
                f"until {state_name}==(#{anchor_name})*{step}+{distance} end "
            )
            flattened_count += 1
        else:
            decoy_anchor = _anchor_string(rng)
            replacement = f' if {predicate} then {original} else {guard_name}("{decoy_anchor}") end '
            opaque_count += 1
        replacements.append((node.start_byte, node.end_byte, replacement.encode("utf-8")))

    if not replacements:
        return NativeFlowResult(source, 0, 0)
    for start, end, replacement in sorted(replacements, reverse=True):
        encoded = encoded[:start] + replacement + encoded[end:]

    # The guard hashes the first byte of its runtime string argument.
    if rng.random() < 0.5:
        prelude = f"local {guard_name}=function(value)return(value:byte(1)*{multiplier}+{increment})%{modulus} end\n"
    else:
        prelude = (
            f"local {guard_name};do {guard_name}=function(value)"
            f"return(value:byte(1)*{multiplier}+{increment})%{modulus} end end\n"
        )
    return NativeFlowResult(prelude + encoded.decode("utf-8"), opaque_count, flattened_count)
