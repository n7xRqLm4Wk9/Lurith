from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


class RandomLike(Protocol):
    def randint(self, a: int, b: int) -> int: ...
    def random(self) -> float: ...
    def choice(self, seq): ...
    def sample(self, population, k: int): ...


@dataclass(frozen=True, slots=True)
class VmEntry:
    handle: int
    code: list[int]


@dataclass(frozen=True, slots=True)
class VmLayout:
    push: int
    delta: int
    run: int
    junk: int
    stop: int


def key_parameters(seed: int) -> tuple[int, int]:
    """Derive the rolling key parameters from the entry seed.

    The generated Lua reconstructs these from `code[1]` at runtime instead of
    storing the multiplier/increment as literals, so the key schedule is never
    written directly into the obfuscated source.
    """
    multiplier = 5 + ((seed + 7) % 233)
    increment = 11 + ((seed * 13 + 29) % 244)
    return multiplier, increment


class LiteralVM:
    """Compiles literal bytes for a small randomized stackless VM.

    This VM protects constants only; it deliberately does not execute uploaded source or
    depend on loadstring, which keeps generated output compatible with Roblox Luau.
    """

    def __init__(self, rng: RandomLike, junk_probability: float) -> None:
        self.rng = rng
        self.junk_probability = junk_probability
        opcodes = rng.sample(list(range(17, 240)), 5)
        self.layout = VmLayout(
            push=opcodes[0],
            delta=opcodes[1],
            run=opcodes[2],
            junk=opcodes[3],
            stop=opcodes[4],
        )
        self.pool: list[VmEntry] = []
        self._handles_by_literal: dict[bytes, int] = {}
        self._used_handles: set[int] = set()
        self._handle_minimum, self._handle_maximum = rng.choice(
            [
                (4_097, 16_777_215),
                (-16_777_215, -4_097),
                (33_554_431, 536_870_911),
            ]
        )

    def _next_key(self, seed: int, key: int) -> int:
        multiplier, increment = key_parameters(seed)
        return (key * multiplier + increment) % 256

    def _maybe_junk(self, code: list[int]) -> None:
        if self.rng.random() < self.junk_probability:
            code.extend((self.layout.junk, self.rng.randint(0, 255)))

    def _new_handle(self) -> int:
        while True:
            handle = self.rng.randint(self._handle_minimum, self._handle_maximum)
            if handle not in self._used_handles:
                self._used_handles.add(handle)
                return handle

    def _encode(self, data: bytes) -> tuple[int, list[int]]:
        seed = self.rng.randint(0, 255)
        key = seed
        last = 0
        code = [seed]
        i = 0
        while i < len(data):
            self._maybe_junk(code)
            if i > 0 and data[i] == last:
                run_length = 0
                while i + run_length < len(data) and data[i + run_length] == last and run_length < 250:
                    run_length += 1
                code.extend((self.layout.run, (run_length + key) % 256))
                for _ in range(run_length):
                    key = self._next_key(seed, key)
                i += run_length
                continue

            byte = data[i]
            if self.rng.random() < 0.5:
                code.extend((self.layout.push, (byte + key) % 256))
            else:
                delta = (byte - last) % 256
                code.extend((self.layout.delta, (delta + key) % 256))
            last = byte
            key = self._next_key(seed, key)
            i += 1

        self._maybe_junk(code)
        code.append(self.layout.stop)
        return seed, code

    def add(self, data: bytes) -> int:
        existing = self._handles_by_literal.get(data)
        if existing is not None:
            return existing
        _seed, code = self._encode(data)
        handle = self._new_handle()
        self.pool.append(VmEntry(handle, code))
        self._handles_by_literal[data] = handle
        return handle

    def add_decoy(self, data: bytes) -> None:
        """Add a valid program for garbage bytes that no source reference ever resolves.

        Decoy entries sit in the shared pool so a dump of every handle yields noise
        mixed with real strings, while lazy caching means they cost nothing at runtime.
        """
        _seed, code = self._encode(data)
        handle = self._new_handle()
        self.pool.append(VmEntry(handle, code))

    def program_for(self, handle: int) -> list[int]:
        return next(entry.code for entry in self.pool if entry.handle == handle)

    def shuffled_entries(self) -> list[VmEntry]:
        return self.rng.sample(self.pool, len(self.pool))

    def decode(self, code: list[int]) -> bytes:
        """Reference decoder used by tests; generated Lua implements the same machine."""
        seed = code[0]
        key = seed
        last = 0
        ip = 1
        output = bytearray()
        while ip < len(code):
            opcode = code[ip]
            ip += 1
            if opcode == self.layout.stop:
                break
            if opcode == self.layout.junk:
                ip += 1
                continue
            if ip >= len(code):
                raise ValueError("Truncated VM bytecode")
            operand = code[ip]
            ip += 1
            if opcode == self.layout.push:
                last = (operand - key) % 256
                output.append(last)
                key = self._next_key(seed, key)
            elif opcode == self.layout.delta:
                last = (last + ((operand - key) % 256)) % 256
                output.append(last)
                key = self._next_key(seed, key)
            elif opcode == self.layout.run:
                count = (operand - key) % 256
                output.extend((last,) * count)
                for _ in range(count):
                    key = self._next_key(seed, key)
            else:
                raise ValueError(f"Unknown VM opcode {opcode}")
        return bytes(output)


def lua_table(values: list[int]) -> str:
    return "{" + ",".join(str(value) for value in values) + "}"
