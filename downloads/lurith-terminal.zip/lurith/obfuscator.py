from __future__ import annotations

import random
import re
import secrets
from dataclasses import dataclass
from typing import Literal

from .config import ObfuscationConfig, get_config
from .function_vm import virtualize_annotated_functions
from .lexer import Token, decode_lua_string, lex
from .limits import (
    DEFAULT_LIMITS,
    EngineLimits,
    check_generated_size,
    check_source_size,
    check_syntax_depth,
    check_tokens,
)
from .macros import expand_luraph_macros, extract_minify_directive, extract_vm_family_directive
from .native_flow import obfuscate_native_control_flow
from .pipeline import PipelinePlan, build_pipeline
from .scope import rename_locals
from .syntax import SyntaxValidationError, analyze_syntax
from .version import VERSION
from .vm import LiteralVM, RandomLike, lua_table
from .vm_family import get_vm_family
from .vm_profile import NameStyle, random_identifier

Dialect = Literal["lua51", "luau"]
# `auto` resolves to `roblox` for the Luau dialect (Roblox capability checks)
# and to `off` for plain Lua 5.1, which has no Roblox globals to assert on.
EnvironmentAssertions = Literal["off", "roblox", "auto"]
WATERMARK = f"-- [obfuscated by Lurith v{VERSION} | https://discord.gg/XSYDVYbqNz ]"
_WATERMARK_RE = re.compile(
    r"^-- \[(?:Obfuscated using (?:Lurith|Luaminator)|obfuscated by Lurith) [^\r\n]+\][ \t]*(?:\r?\n)?"
)


@dataclass(frozen=True, slots=True)
class ObfuscationResult:
    source: str
    config: str
    dialect: Dialect
    input_bytes: int
    output_bytes: int
    virtualized_literals: int
    unique_literals: int
    masked_integers: int
    renamed_locals: int
    virtualized_functions: int
    automatically_virtualized_functions: int
    vm_profile: str | None
    vm_family: str
    expanded_macros: int
    macro_names: tuple[str, ...]
    anti_tamper_mode: str
    syntax_validated: bool
    pipeline: tuple[str, ...]
    ir_instruction_count: int
    bytecode_word_count: int
    packed_bytecode_bytes: int
    fused_instruction_count: int
    opaque_predicates: int
    flattened_native_statements: int
    environment_assertions: str


class Obfuscator:
    def __init__(
        self,
        config: str | ObfuscationConfig = "normal",
        dialect: Dialect = "lua51",
        *,
        seed: int | None = None,
        limits: EngineLimits = DEFAULT_LIMITS,
        environment_assertions: EnvironmentAssertions = "auto",
        vm_family: str = "auto",
        minify: bool | None = None,
        strip_comments: bool | None = None,
    ) -> None:
        self.config = get_config(config) if isinstance(config, str) else config
        family_spec = get_vm_family(vm_family)
        if family_spec.name != "auto":
            family_spec.validate_level(self.config.vm_polymorphism_level, self.config.name)
        self.requested_vm_family = family_spec.name
        self.minify_override = minify
        self.strip_comments_override = strip_comments
        if environment_assertions not in {"off", "roblox", "auto"}:
            raise ValueError("environment_assertions must be 'off', 'roblox', or 'auto'")
        if dialect not in {"lua51", "luau"}:
            raise ValueError("dialect must be 'lua51' or 'luau'")
        self.dialect = dialect
        if environment_assertions == "auto":
            environment_assertions = "roblox" if dialect == "luau" else "off"
        self.environment_assertions = environment_assertions
        self.pipeline: PipelinePlan = build_pipeline(self.config)
        self.limits = limits
        self.rng: RandomLike = random.Random(seed) if seed is not None else secrets.SystemRandom()
        self.identifier_style: NameStyle = self.rng.choice(["underscore", "confusable", "alpha"])

    def obfuscate(self, source: str) -> ObfuscationResult:
        check_source_size(source, self.limits)
        prefix, body = self._extract_prefix(source)
        body = _WATERMARK_RE.sub("", body, count=1)
        tokens = lex(body)
        check_tokens(tokens, self.limits)
        directive = extract_vm_family_directive(body, tokens)
        body = directive.source
        if (
            directive.family is not None
            and self.requested_vm_family != "auto"
            and directive.family != self.requested_vm_family
        ):
            raise ValueError(
                f"Source requests VM family {directive.family!r}, but the caller selected "
                f"{self.requested_vm_family!r}. Remove one setting instead of relying on precedence."
            )
        effective_vm_family = directive.family or self.requested_vm_family
        family_spec = get_vm_family(effective_vm_family)
        family_spec.validate_level(self.config.vm_polymorphism_level, self.config.name)

        tokens = lex(body)
        check_tokens(tokens, self.limits)
        minify_directive = extract_minify_directive(body, tokens)
        if minify_directive.source != body:
            body = minify_directive.source
            tokens = lex(body)
            check_tokens(tokens, self.limits)
        effective_minify = (
            self.minify_override
            if self.minify_override is not None
            else minify_directive.minify
            if minify_directive.minify is not None
            else self.config.minify
        )
        effective_strip_comments = (
            self.strip_comments_override
            if self.strip_comments_override is not None
            else minify_directive.strip_comments
            if minify_directive.strip_comments is not None
            else self.config.strip_comments
        )
        analysis = analyze_syntax(body, self.dialect)
        check_syntax_depth(analysis.tree.root_node, self.limits)
        if analysis.has_errors:
            raise SyntaxValidationError(
                analysis.error_message or f"{self.dialect} source contains a syntax error. Obfuscation was blocked."
            )
        syntax_validated = True

        macro_result = expand_luraph_macros(body, analysis.tree, self.dialect)
        expanded_macros = macro_result.expanded
        macro_names = macro_result.names
        if macro_result.source != body:
            body = macro_result.source
            check_generated_size(body, self.limits)
            tokens = lex(body)
            check_tokens(tokens, self.limits)
            analysis = analyze_syntax(body, self.dialect)
            check_syntax_depth(analysis.tree.root_node, self.limits)
            if analysis.has_errors:
                detail = analysis.error_message or "unknown macro expansion syntax error"
                raise SyntaxValidationError(f"Macro expansion generated invalid source: {detail}")

        if self.environment_assertions == "roblox":
            token = "".join(
                self.rng.choice("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
                for _ in range(self.rng.randint(10, 18))
            )
            body = f'if game==nil or workspace==nil or task==nil then error("{token}",0) end\n' + body
            tokens = lex(body)
            check_tokens(tokens, self.limits)
            analysis = analyze_syntax(body, self.dialect)
            check_syntax_depth(analysis.tree.root_node, self.limits)
            if analysis.has_errors:
                detail = analysis.error_message or "unknown capability assertion syntax error"
                raise SyntaxValidationError(f"Capability assertion generated invalid source: {detail}")

        virtualized_functions = 0
        automatically_virtualized_functions = 0
        ir_instruction_count = 0
        bytecode_word_count = 0
        packed_bytecode_bytes = 0
        fused_instruction_count = 0
        runtime_prefix_bytes = 0
        opaque_predicates = 0
        flattened_native_statements = 0
        vm_profile: str | None = None
        if syntax_validated and self.pipeline.enabled("lower-function-vm"):
            function_result = virtualize_annotated_functions(
                body,
                analysis.tree,
                self.rng,
                max_instructions=self.limits.max_function_vm_instructions,
                anti_tamper_mode=self.config.anti_tamper_mode,
                polymorphism_level=self.config.vm_polymorphism_level,
                auto_virtualize_min_nodes=self.config.auto_virtualize_min_nodes,
                auto_virtualize_max_overhead=self.config.auto_virtualize_max_overhead,
                superinstruction_level=self.config.superinstruction_level,
                vm_family=effective_vm_family,
                dialect=self.dialect,
            )
            if function_result.virtualized_functions:
                body = function_result.source
                check_generated_size(body, self.limits)
                virtualized_functions = function_result.virtualized_functions
                automatically_virtualized_functions = function_result.automatically_virtualized
                vm_profile = function_result.profile
                ir_instruction_count = function_result.ir_instruction_count
                bytecode_word_count = function_result.bytecode_word_count
                packed_bytecode_bytes = function_result.packed_bytecode_bytes
                fused_instruction_count = function_result.fused_instruction_count
                runtime_prefix_bytes = function_result.runtime_prefix_bytes
                tokens = lex(body)
                check_tokens(tokens, self.limits)
                analysis = analyze_syntax(body, self.dialect)
                check_syntax_depth(analysis.tree.root_node, self.limits)
                if analysis.has_errors:
                    detail = analysis.error_message or "unknown function VM syntax error"
                    raise SyntaxValidationError(f"Function VM generated invalid source: {detail}")

        if self.pipeline.enabled("obfuscate-native-flow"):
            native_result = obfuscate_native_control_flow(
                body,
                analysis.tree,
                self.rng,
                protected_prefix_bytes=runtime_prefix_bytes,
                opaque_probability=self.config.native_opaque_probability,
                flatten_probability=self.config.native_flatten_probability,
                name_style=self.identifier_style,
            )
            if native_result.transformed_statements:
                body = native_result.source
                opaque_predicates = native_result.opaque_predicates
                flattened_native_statements = native_result.flattened_statements
                check_generated_size(body, self.limits)
                tokens = lex(body)
                check_tokens(tokens, self.limits)
                analysis = analyze_syntax(body, self.dialect)
                check_syntax_depth(analysis.tree.root_node, self.limits)
                if analysis.has_errors:
                    detail = analysis.error_message or "unknown native control-flow syntax error"
                    raise SyntaxValidationError(f"Native control-flow pass generated invalid source: {detail}")

        used_names = {token.value for token in tokens if token.kind == "identifier"}
        renamed_locals = 0
        if self.pipeline.enabled("rename-locals") and syntax_validated:
            renamed = rename_locals(
                body,
                tokens,
                analysis.tree,
                self.rng,
                used_names,
                self.identifier_style,
            )
            tokens = renamed.tokens
            renamed_locals = renamed.renamed_bindings

        math_shadowed = self._is_math_shadowed(tokens)
        tokens = self._rewrite_negative_zero_literals(tokens, math_shadowed)

        resolver_name = self._random_identifier(used_names)
        vm = LiteralVM(self.rng, self.config.junk_probability)
        literal_fragments: dict[bytes, list[int]] = {}

        transformed: list[Token] = []
        virtualized = 0
        masked_integers = 0
        for index, token in enumerate(tokens):
            if token.kind == "number" and self.pipeline.enabled("mask-integers"):
                masked = self._mask_integer(token)
                if masked is not None:
                    transformed.append(masked)
                    masked_integers += 1
                else:
                    transformed.append(token)
                continue

            if token.kind != "string" or not self.pipeline.enabled("protect-literals"):
                transformed.append(token)
                continue
            decoded = decode_lua_string(token.value, self.dialect)
            if (
                decoded is None
                or len(decoded) < self.config.minimum_string_bytes
                or self._is_luau_type_literal(tokens, index)
            ):
                transformed.append(token)
                continue
            handles = literal_fragments.get(decoded)
            if handles is None:
                handles = self._fragment_literal(vm, decoded)
                literal_fragments[decoded] = handles
            calls = [f"{resolver_name}({self._number(handle)})" for handle in handles]
            expression = "(" + "..".join(calls) + ")"
            transformed.append(
                Token(
                    "atom",
                    expression,
                    token.line,
                    token.column,
                    token.start_byte,
                    token.end_byte,
                )
            )
            virtualized += 1

        if vm.pool and self.config.junk_probability > 0:
            decoy_budget = self.rng.randint(1, min(6, 1 + len(vm.pool) * 2))
            for _ in range(decoy_budget):
                length = self.rng.randint(8, 64)
                vm.add_decoy(bytes(self.rng.randrange(256) for _ in range(length)))

        rendered = self._render(transformed, effective_minify, effective_strip_comments)
        if vm.pool:
            prelude = self._render_vm(vm, resolver_name, used_names)
            protected_body = prelude + rendered
        else:
            protected_body = rendered

        if syntax_validated and self.pipeline.enabled("validate-output"):
            output_analysis = analyze_syntax(protected_body, self.dialect)
            if output_analysis.has_errors:
                detail = output_analysis.error_message or "unknown generated syntax error"
                raise SyntaxValidationError(f"Internal validation rejected generated output: {detail}")
        output = prefix + WATERMARK + "\n" + protected_body
        check_generated_size(output, self.limits)

        return ObfuscationResult(
            source=output,
            config=self.config.name,
            dialect=self.dialect,
            input_bytes=len(source.encode("utf-8")),
            output_bytes=len(output.encode("utf-8")),
            virtualized_literals=virtualized,
            unique_literals=len(vm.pool),
            masked_integers=masked_integers,
            renamed_locals=renamed_locals,
            virtualized_functions=virtualized_functions,
            automatically_virtualized_functions=automatically_virtualized_functions,
            vm_profile=vm_profile,
            vm_family=effective_vm_family,
            expanded_macros=expanded_macros,
            macro_names=macro_names,
            anti_tamper_mode=self.config.anti_tamper_mode if virtualized_functions else "off",
            syntax_validated=syntax_validated,
            pipeline=self.pipeline.active_names,
            ir_instruction_count=ir_instruction_count,
            bytecode_word_count=bytecode_word_count,
            packed_bytecode_bytes=packed_bytecode_bytes,
            fused_instruction_count=fused_instruction_count,
            opaque_predicates=opaque_predicates,
            flattened_native_statements=flattened_native_statements,
            environment_assertions=self.environment_assertions,
        )

    @staticmethod
    def _extract_prefix(source: str) -> tuple[str, str]:
        """Keep shebangs and Luau mode directives at the very beginning of the file."""
        prefix: list[str] = []
        body = source
        if body.startswith("#!"):
            line, separator, remainder = body.partition("\n")
            prefix.append(line + separator)
            body = remainder
        while body.startswith("--!"):
            line, separator, remainder = body.partition("\n")
            if line.strip() not in {"--!strict", "--!nonstrict", "--!nocheck", "--!native", "--!optimize 2"}:
                break
            prefix.append(line + separator)
            body = remainder
            if not separator:
                break
        return "".join(prefix), body

    def _is_luau_type_literal(self, tokens: list[Token], index: int) -> bool:
        if self.dialect != "luau":
            return False
        token = tokens[index]
        significant = [candidate for candidate in tokens if candidate.kind not in {"whitespace", "comment"}]
        by_line: dict[int, list[Token]] = {}
        for candidate in significant:
            by_line.setdefault(candidate.line, []).append(candidate)

        line_tokens = by_line.get(token.line, [])
        values = [candidate.value for candidate in line_tokens]
        if values[:1] == ["type"] or values[:2] == ["export", "type"]:
            return True

        # Conservatively preserve singleton strings in annotations/casts. A method-call colon
        # is followed by an identifier and then `(`, so it is not mistaken for an annotation.
        before = [candidate for candidate in line_tokens if candidate.column < token.column]
        for position, candidate in enumerate(before):
            if candidate.value == "::":
                return True
            if candidate.value == ":":
                after_colon = before[position + 1 :]
                if not after_colon or "(" not in [item.value for item in after_colon[:2]]:
                    return True

        # Handle multiline aliases/annotations, such as:
        #   type Mode =
        #       "fast"
        #       | "slow"
        current_first = values[0] if values else ""
        continuation = current_first in {"|", "&", ")", "}", "]"}
        for line_number in range(token.line - 1, max(0, token.line - 80), -1):
            previous_line = by_line.get(line_number)
            if not previous_line:
                continue
            previous_values = [candidate.value for candidate in previous_line]
            starts_alias = previous_values[:1] == ["type"] or previous_values[:2] == ["export", "type"]
            if starts_alias:
                return continuation or previous_values[-1] in {"=", "|", "&", "(", "{", "[", ",", "->"}
            if previous_values[-1] in {":", "::"}:
                return True
            if not continuation and previous_values[-1] not in {"=", "|", "&", "(", "{", "[", ",", "->"}:
                break
            continuation = True
        return False

    def _fragment_literal(self, vm: LiteralVM, data: bytes) -> list[int]:
        maximum = min(self.config.max_string_fragments, max(1, len(data) // 4))
        if maximum <= 1:
            return [vm.add(data)]
        fragment_count = self.rng.randint(2, maximum)
        cut_points = sorted(self.rng.sample(range(1, len(data)), fragment_count - 1))
        boundaries = [0, *cut_points, len(data)]
        return [vm.add(data[start:end]) for start, end in zip(boundaries, boundaries[1:], strict=False)]

    def _random_identifier(self, used: set[str]) -> str:
        return random_identifier(self.rng, used, self.identifier_style, 8, 14)

    def _mask_integer(self, token: Token) -> Token | None:
        raw = token.value.replace("_", "")
        if not raw.isascii() or not raw.isdigit() or len(raw) > 10:
            return None
        value = int(raw, 10)
        if value > 1_000_000 or self.rng.random() >= self.config.integer_mask_probability:
            return None
        offset = self.rng.randint(257, 1_000_000)
        expression = f"(({value + offset})-{offset})"
        return Token(
            "atom",
            expression,
            token.line,
            token.column,
            token.start_byte,
            token.end_byte,
        )

    _FLOAT_ZERO_RE = re.compile(r"0(\.\d*)?([eE][+-]?\d+)?")

    @staticmethod
    def _is_float_zero_literal(value: str) -> bool:
        """True for zero-valued float literals: `0.0`, `0.`, `0e0`, `0E-10`, …"""
        stripped = value.replace("_", "")
        if "." not in stripped and "e" not in stripped.lower():
            return False
        return Obfuscator._FLOAT_ZERO_RE.fullmatch(stripped) is not None

    @staticmethod
    def _is_math_shadowed(tokens: list[Token]) -> bool:
        """True if `math` is bound in a way that shadows the standard library.

        Runs on post-rename tokens: renamed locals are gone, so only surviving
        declarations (`local math` at rename-off configs) and global assignments
        (`math = …`) still shadow the library. Covers `local math`,
        `local a, math`, `function math(…)`, `local function math(…)`,
        `for math …`, `math` as a parameter, and `math = …`.
        """
        significant = [token for token in tokens if token.kind not in {"whitespace", "comment"}]
        for index, token in enumerate(significant):
            if token.kind != "identifier" or token.value != "math":
                continue
            previous = significant[index - 1] if index > 0 else None
            following = significant[index + 1] if index + 1 < len(significant) else None
            # Global assignment target: `math = …` (but not `x.math = …`).
            if (
                following is not None
                and following.value == "="
                and (previous is None or previous.value not in {".", ":"})
            ):
                return True
            if previous is None:
                continue
            if previous.kind == "keyword" and previous.value in {"local", "for", "function"}:
                return True
            if previous.value == ",":
                for back in range(index - 2, -1, -1):
                    candidate = significant[back]
                    if candidate.value == ",":
                        continue
                    if candidate.kind == "keyword" and candidate.value in {"local", "for"}:
                        return True
                    break
            if previous.value == "(" and following is not None and following.value in {",", ")"}:
                return True
        return False

    @staticmethod
    def _rewrite_negative_zero_literals(tokens: list[Token], math_shadowed: bool) -> list[Token]:
        """Rewrite unary negative-zero float literals to a runtime form.

        PUC Lua 5.1 constant-folds `-0.0` into an earlier `0` constant (since
        `0 == -0.0`), so any `0` literal earlier in the chunk — including the
        ones Lurith's prelude emits — collapses the user's `-0.0` to `+0.0`.
        `(-1)/math.huge` computes negative zero at runtime and cannot be folded.
        When `math` is shadowed the literal is left untouched (Luau and Lua 5.2+
        are unaffected either way).
        """
        if math_shadowed:
            return list(tokens)
        value_enders = {"identifier", "number", "string", "atom", ")" , "]", "}", "..."}
        significant = [token for token in tokens if token.kind not in {"whitespace", "comment"}]
        rewritten: list[Token] = []
        index = 0
        while index < len(tokens):
            token = tokens[index]
            if token.kind == "number" and Obfuscator._is_float_zero_literal(token.value):
                # Is this a unary negation? The previous significant token must
                # be `-` and the token before that must not end a value.
                position = significant.index(token) if token in significant else -1
                if position > 0 and significant[position - 1].value == "-":
                    before_minus = significant[position - 2] if position >= 2 else None
                    is_unary = before_minus is None or (
                        before_minus.kind not in value_enders
                        and not (before_minus.kind == "keyword" and before_minus.value in {"true", "false", "nil"})
                    )
                    if is_unary:
                        # Remove the preceding '-' token from the output.
                        rewritten.pop()
                        rewritten.append(
                            Token(
                                "atom",
                                "((-1)/math.huge)",
                                token.line,
                                token.column,
                                token.start_byte,
                                token.end_byte,
                            )
                        )
                        index += 1
                        continue
            rewritten.append(token)
            index += 1
        return rewritten

    def _number(self, value: int) -> str:
        if not self.config.mask_vm_constants:
            return str(value)
        # Occasionally emit the value as a hex literal so the numeric runs in the
        # literal-VM pools are not all one `(left±right)` shape.
        if self.rng.random() < 0.25:
            return f"-0x{abs(value):X}" if value < 0 else f"0x{value:X}"
        left = self.rng.randint(257, 4096)
        right = value - left
        sign = "+" if right >= 0 else "-"
        return f"({left}{sign}{abs(right)})"

    def _render_vm(self, vm: LiteralVM, resolver: str, used_names: set[str]) -> str:
        char_name = self._random_identifier(used_names)
        concat_name = self._random_identifier(used_names)
        pool_name = self._random_identifier(used_names)
        shards_name = self._random_identifier(used_names)
        shard_index_name = self._random_identifier(used_names)
        cache_name = self._random_identifier(used_names)
        decode_name = self._random_identifier(used_names)
        code_name = self._random_identifier(used_names)
        ip_name = self._random_identifier(used_names)
        seed_name = self._random_identifier(used_names)
        mult_name = self._random_identifier(used_names)
        inc_name = self._random_identifier(used_names)
        key_name = self._random_identifier(used_names)
        last_name = self._random_identifier(used_names)
        out_name = self._random_identifier(used_names)
        op_name = self._random_identifier(used_names)
        value_name = self._random_identifier(used_names)
        count_name = self._random_identifier(used_names)
        index_name = self._random_identifier(used_names)
        dead_name = self._random_identifier(used_names)

        layout = vm.layout
        n = self._number

        # Shard the constant pool so there is no single contiguous dump site.
        # The resolver picks a shard from the handle itself (handle % shards).
        entries = vm.shuffled_entries()
        shard_count = self.rng.choice((2, 3)) if len(entries) >= 2 else 1
        if shard_count > 1:
            buckets: list[list[object]] = [[] for _ in range(shard_count)]
            for entry in entries:
                buckets[entry.handle % shard_count].append(entry)
            if any(not bucket for bucket in buckets):
                shard_count = 1

        def render_code(code: list[int]) -> str:
            if not self.config.mask_vm_constants:
                return lua_table(code)
            return "{" + ",".join(self._number(value) for value in code) + "}"

        pool_bodies: list[str] = []
        if shard_count == 1:
            body = ",".join(f"[{n(entry.handle)}]={render_code(entry.code)}" for entry in entries)
            pool_bodies.append("{" + body + "}")
        else:
            for bucket in buckets:
                body = ",".join(f"[{n(entry.handle)}]={render_code(entry.code)}" for entry in bucket)
                pool_bodies.append("{" + body + "}")

        handlers = [
            (
                layout.push,
                f"{last_name}=({value_name}-{key_name})%256;"
                f"{out_name}[#{out_name}+1]={char_name}({last_name});"
                f"{key_name}=({key_name}*{mult_name}+{inc_name})%256",
            ),
            (
                layout.delta,
                f"{last_name}=({last_name}+({value_name}-{key_name})%256)%256;"
                f"{out_name}[#{out_name}+1]={char_name}({last_name});"
                f"{key_name}=({key_name}*{mult_name}+{inc_name})%256",
            ),
            (
                layout.run,
                f"local {count_name}=({value_name}-{key_name})%256;"
                f"for {index_name}=1,{count_name} do "
                f"{out_name}[#{out_name}+1]={char_name}({last_name});"
                f"{key_name}=({key_name}*{mult_name}+{inc_name})%256 end",
            ),
        ]
        literal_error = "".join(
            self.rng.choice("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
            for _ in range(self.rng.randint(9, 18))
        )
        handler_lines: list[str] = []
        for position, (opcode, implementation) in enumerate(self.rng.sample(handlers, len(handlers))):
            keyword = "if" if position == 0 else "elseif"
            handler_lines.extend((f"{keyword} {op_name}=={n(opcode)} then", implementation))
        handler_lines.append(f'else error("{literal_error}",0) end')

        split_char_concat = self.rng.random() < 0.5
        repeat_loop = self.rng.random() < 0.5
        split_frame = self.rng.random() < 0.5
        loop_open = "repeat" if repeat_loop else "while true do"
        loop_close = "until false" if repeat_loop else "end"

        lines = [
            "local " + resolver,
            "do",
        ]
        if split_char_concat:
            lines.append(f"local {char_name}=string.char")
            lines.append(f"local {concat_name}=table.concat")
        else:
            lines.append(f"local {char_name},{concat_name}=string.char,table.concat")
        if shard_count == 1:
            lines.append(f"local {pool_name}={pool_bodies[0]}")
        else:
            lines.append(f"local {shards_name}={{{','.join(pool_bodies)}}}")
        lines.append(f"local {cache_name}={{}}")
        lines.append(f"local function {decode_name}({code_name})")
        lines.append(f"local {seed_name}={code_name}[1]")
        lines.append(f"local {mult_name}={n(5)}+(({seed_name}+{n(7)})%{n(233)})")
        lines.append(f"local {inc_name}={n(11)}+(({seed_name}*{n(13)}+{n(29)})%{n(244)})")
        if split_frame:
            lines.append(f"local {ip_name},{key_name}=2,{seed_name}")
            lines.append(f"local {last_name},{out_name},{dead_name}=0,{{}},0")
        else:
            lines.append(
                f"local {ip_name},{key_name},{last_name},{out_name},{dead_name}=2,{seed_name},0,{{}},0"
            )
        lines.append(loop_open)
        lines.append(f"local {op_name}={code_name}[{ip_name}];{ip_name}={ip_name}+1")
        lines.append(f"if {op_name}=={n(layout.stop)} then break")
        lines.append(
            f"elseif {op_name}=={n(layout.junk)} then "
            f"{dead_name}=({dead_name}+{code_name}[{ip_name}])%256;{ip_name}={ip_name}+1"
        )
        lines.append("else")
        lines.append(f"local {value_name}={code_name}[{ip_name}];{ip_name}={ip_name}+1")
        lines.extend(handler_lines)
        lines.append("end")
        lines.append(loop_close)
        lines.append(f"return {concat_name}({out_name})")
        lines.append("end")
        lines.append(f"{resolver}=function({index_name})")
        lines.append(f"local {value_name}={cache_name}[{index_name}]")
        if shard_count == 1:
            lines.append(
                f"if {value_name}==nil then "
                f"{value_name}={decode_name}({pool_name}[{index_name}]);"
                f"{cache_name}[{index_name}]={value_name} end"
            )
        else:
            lines.append(
                f"if {value_name}==nil then "
                f"local {shard_index_name}={index_name}%{shard_count}+1;"
                f"{value_name}={decode_name}({shards_name}[{shard_index_name}][{index_name}]);"
                f"{cache_name}[{index_name}]={value_name} end"
            )
        lines.extend(
            [
                f"return {value_name}",
                "end",
                "end",
                "",
            ]
        )
        return "\n".join(lines)

    def _render(self, tokens: list[Token], minify: bool, strip_comments: bool) -> str:
        if not minify and not strip_comments:
            return "".join(token.value for token in tokens)

        if not minify:
            parts: list[str] = []
            for token in tokens:
                if token.kind == "comment" and strip_comments:
                    parts.append("\n" if "\n" in token.value else " ")
                else:
                    parts.append(token.value)
            return "".join(parts)

        output: list[str] = []
        previous: Token | None = None
        pending_newline = False
        had_gap = False

        for token in tokens:
            if token.kind in {"whitespace", "comment"}:
                had_gap = True
                if "\n" in token.value:
                    pending_newline = True
                if token.kind == "comment" and not strip_comments:
                    # Keep the comment on its own line while minifying the rest.
                    if output and not output[-1].endswith("\n"):
                        output.append("\n")
                    output.append(token.value)
                    if not token.value.endswith("\n"):
                        output.append("\n")
                    pending_newline = False
                continue

            if previous is not None:
                if pending_newline:
                    output.append("\n")
                elif self._needs_space(previous, token) or (
                    had_gap and previous.kind == "keyword" and token.kind == "symbol" and token.value == "-"
                ):
                    output.append(" ")
            output.append(token.value)
            previous = token
            pending_newline = False
            had_gap = False

        return "".join(output)

    @staticmethod
    def _needs_space(previous: Token, current: Token) -> bool:
        wordish = {"identifier", "keyword", "number"}
        if previous.kind in wordish and current.kind in wordish:
            return True
        if previous.kind == "number" and current.value.startswith("."):
            return True
        if previous.value.endswith(".") and current.kind == "number":
            return True
        combined = previous.value + current.value
        dangerous = {
            "--",
            "..",
            "...",
            "==",
            "~=",
            "<=",
            ">=",
            "::",
            "//",
            "<<",
            ">>",
            "+=",
            "-=",
            "*=",
            "/=",
            "%=",
            "^=",
            "&=",
            "|=",
            "->",
        }
        return combined in dangerous
