from __future__ import annotations


class BytecodePackingError(ValueError):
    pass


def pack_words(words: list[int]) -> bytes:
    output = bytearray()
    for word in words:
        if not isinstance(word, int) or word < 0:
            raise BytecodePackingError(f"bytecode words must be non-negative integers, got {word!r}")
        value = word
        while value >= 0x80:
            output.append((value & 0x7F) | 0x80)
            value >>= 7
        output.append(value)
    return bytes(output)


def unpack_words(data: bytes) -> list[int]:
    output: list[int] = []
    value = 0
    multiplier = 1
    bytes_in_word = 0
    for byte in data:
        value += (byte & 0x7F) * multiplier
        bytes_in_word += 1
        if bytes_in_word > 8:
            raise BytecodePackingError("varint exceeds eight bytes")
        if byte < 0x80:
            output.append(value)
            value = 0
            multiplier = 1
            bytes_in_word = 0
        else:
            multiplier *= 0x80
    if bytes_in_word:
        raise BytecodePackingError("truncated varint at end of packed bytecode")
    return output


def lua_binary_literal(data: bytes) -> str:
    return '"' + "".join(f"\\{byte:03d}" for byte in data) + '"'


def validate_packed_round_trip(words: list[int]) -> bytes:
    packed = pack_words(words)
    decoded = unpack_words(packed)
    if decoded != words:
        raise BytecodePackingError("packed bytecode failed round-trip validation")
    return packed
