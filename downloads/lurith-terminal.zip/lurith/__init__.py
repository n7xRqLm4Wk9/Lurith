"""Lurith: a semantics-conscious Lua/Luau source obfuscator."""

from .config import CONFIGS, ObfuscationConfig, get_config
from .function_vm import FunctionVmError
from .limits import EngineLimits, ResourceLimitError
from .macros import MacroError
from .obfuscator import ObfuscationResult, Obfuscator
from .syntax import SyntaxValidationError
from .version import VERSION as __version__
from .vm_family import VM_FAMILIES, VmFamilyError, get_vm_family

__all__ = [
    "CONFIGS",
    "VM_FAMILIES",
    "__version__",
    "EngineLimits",
    "MacroError",
    "FunctionVmError",
    "ObfuscationConfig",
    "ObfuscationResult",
    "Obfuscator",
    "ResourceLimitError",
    "SyntaxValidationError",
    "VmFamilyError",
    "get_config",
    "get_vm_family",
]
