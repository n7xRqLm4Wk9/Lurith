from __future__ import annotations

import math

from .lexer import decode_lua_string
from .vm_profile import VmProfile
from .vm_types import CompiledFunction


def _parse_numeric_literal(literal: str) -> float:
    value = literal.replace("_", "")
    lowered = value.lower()
    if lowered.startswith("0b"):
        return float(int(lowered[2:], 2))
    if lowered.startswith("0x"):
        return float.fromhex(value) if "p" in lowered or "." in lowered else float(int(lowered, 16))
    return float(value)


def _number_integrity_values(literal: str, marker: int) -> list[int]:
    value = _parse_numeric_literal(literal)
    if math.isnan(value):
        return [marker, 1, 0, 0]
    if math.isinf(value):
        return [marker, 2, 0, 1 if value < 0 else 0]
    mantissa, exponent = math.frexp(value)
    quantized_mantissa = int(math.floor(abs(mantissa) * (2**30) + 0.5))
    return [marker, exponent + 4096, quantized_mantissa, 1 if mantissa < 0 else 0]


def _number_values_or_raise(literal: str, marker: int) -> list[int]:
    """Integrity values for a numeric constant, or a clear internal error when
    the literal is neither a string nor a number (the lowering must never emit
    such a constant; a future shape should fail loudly, not silently produce
    wrong integrity material)."""
    try:
        return _number_integrity_values(literal, marker)
    except ValueError:
        raise ValueError(
            f"VM program constant is neither a string nor a number literal: {literal!r}"
        ) from None


def _constant_canary(literal: str, dialect: str = "luau") -> tuple[int, int]:
    modulus = 1_000_003
    decoded = decode_lua_string(literal, dialect)
    if decoded is not None:
        result = 17
        for index, byte in enumerate(decoded, 1):
            result = (result * 257 + byte + index) % modulus
        return 1, result
    result = 29
    for index, value in enumerate(_number_values_or_raise(literal, 97), 1):
        result = (result * 263 + value + index) % modulus
    return 2, result


def _integrity_values(function: CompiledFunction, profile: VmProfile, dialect: str = "luau") -> list[int]:
    program = function.program
    first, second, third, fourth = profile.integrity_weights
    values = [
        function.handle,
        function.guard_token,
        program.local_count * first,
        program.parameter_count * second,
        len(function.code) * third,
        len(program.constants) * fourth,
        *function.code,
    ]
    for position, word in function.sentinel_words:
        values.extend((position + second, word + fourth))
    for index, type_code, expected in function.constant_canaries:
        values.extend((index + first, type_code + second, expected + third))
    for index, constant in enumerate(program.constants, 1):
        decoded = decode_lua_string(constant, dialect)
        values.append(index + profile.integrity_increment)
        if decoded is not None:
            values.append(len(decoded) + third)
            values.extend(byte + byte_index for byte_index, byte in enumerate(decoded, 1))
        else:
            values.extend(_number_values_or_raise(constant, fourth + index))
    return values


def _integrity_checksum(function: CompiledFunction, profile: VmProfile, dialect: str = "luau") -> int:
    modulus = profile.integrity_modulus
    values = _integrity_values(function, profile, dialect)
    if profile.integrity_family == "fletcher":
        first = profile.integrity_increment % modulus
        second = (profile.integrity_multiplier + function.handle) % modulus
        for value in values:
            first = (first + value) % modulus
            second = (second + first) % modulus
        return (first + second * profile.integrity_weights[0]) % modulus

    result = profile.integrity_increment % modulus
    for index, value in enumerate(values, 1):
        result = (result * profile.integrity_multiplier + value + index) % modulus
    return result
