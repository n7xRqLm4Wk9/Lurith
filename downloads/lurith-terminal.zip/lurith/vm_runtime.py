from __future__ import annotations

import math

from .vm import RandomLike
from .vm_bootstrap import render_bootstrap
from .vm_common import _lua_string, _random_name
from .vm_integrity import _integrity_checksum, _parse_numeric_literal
from .vm_packing import lua_binary_literal, pack_words
from .vm_profile import VmProfile
from .vm_schema import ALL_INSTRUCTIONS, DYNAMIC_RESULT_INSTRUCTIONS
from .vm_types import CompiledFunction

_MAX_CALL_ARGUMENTS = 8


def _runtime_constant_source(literal: str, profile: VmProfile) -> str:
    if not profile.numeric_constant_strings:
        return literal
    try:
        value = _parse_numeric_literal(literal)
    except (OverflowError, ValueError):
        return literal
    if not math.isfinite(value):
        return literal
    canonical = "-0" if value == 0 and math.copysign(1.0, value) < 0 else format(value, ".17g")
    return f"tonumber({_lua_string(canonical)})"


def _render_shared_runtime(
    rng: RandomLike,
    used: set[str],
    functions: list[CompiledFunction],
    opcodes: dict[str, int],
    profile: VmProfile,
    anti_tamper_mode: str,
    dialect: str = "luau",
) -> tuple[str, str]:
    used_instructions = {
        item.opcode
        for function in functions
        for item in function.program.instructions
        if hasattr(item, "opcode")
    }
    uses_dynamic_results = not DYNAMIC_RESULT_INSTRUCTIONS.isdisjoint(used_instructions)
    run_name = _random_name(rng, used, profile, 10, 15)
    programs_name = _random_name(rng, used, profile)
    program_name = _random_name(rng, used, profile)
    code_name = _random_name(rng, used, profile)
    constants_name = _random_name(rng, used, profile)
    args_name = _random_name(rng, used, profile)
    guard_argument_name = _random_name(rng, used, profile)
    sentinels_name = _random_name(rng, used, profile)
    constant_canaries_name = _random_name(rng, used, profile)
    canary_hash_name = _random_name(rng, used, profile)
    canary_type_name = _random_name(rng, used, profile)
    canary_expected_name = _random_name(rng, used, profile)
    externals_name = _random_name(rng, used, profile)
    boxes_name = _random_name(rng, used, profile)
    setters_name = _random_name(rng, used, profile)
    varargs_name = _random_name(rng, used, profile)
    vararg_count_name = _random_name(rng, used, profile)
    unpack_name = _random_name(rng, used, profile)
    unpack_index_name = _random_name(rng, used, profile)
    unpack_limit_name = _random_name(rng, used, profile)
    call_args_name = _random_name(rng, used, profile)
    if uses_dynamic_results:
        pack_name = _random_name(rng, used, profile)
        packed_name = _random_name(rng, used, profile)
        packed_count_name = _random_name(rng, used, profile)
    else:
        pack_name = unpack_name
        packed_name = program_name
        packed_count_name = ""
    # Outer program getter: an indirection layer between the bootstrap table and
    # the dispatch loop. Deterministically keyed on the bootstrap seed (no RNG
    # draw) so profile streams stay identical; breaks the flat
    # `local program=programs[index]` shape a structural dumper keys on.
    getter_name = ""
    if profile.bootstrap_seed % 2 == 0:
        getter_name = _random_name(rng, used, profile)
    locals_name = _random_name(rng, used, profile)
    stack_name = _random_name(rng, used, profile)
    ip_name = _random_name(rng, used, profile)
    sp_name = _random_name(rng, used, profile)
    op_name = _random_name(rng, used, profile)
    index_name = _random_name(rng, used, profile)
    left_name = _random_name(rng, used, profile)
    right_name = _random_name(rng, used, profile)
    count_name = _random_name(rng, used, profile)
    base_name = _random_name(rng, used, profile)
    function_name = _random_name(rng, used, profile)
    object_name = _random_name(rng, used, profile)
    loop_name = _random_name(rng, used, profile)
    verified_name = _random_name(rng, used, profile)
    call_counts_name = _random_name(rng, used, profile)
    call_count_name = _random_name(rng, used, profile)
    checksum_name = _random_name(rng, used, profile)
    checksum_second_name = _random_name(rng, used, profile)
    position_name = _random_name(rng, used, profile)
    mix_name = _random_name(rng, used, profile)
    constant_name = _random_name(rng, used, profile)
    mantissa_name = _random_name(rng, used, profile)
    exponent_name = _random_name(rng, used, profile)
    byte_name = _random_name(rng, used, profile)
    byte_function_name = _random_name(rng, used, profile) if profile.packed_bytecode else ""
    byte_accessor = byte_function_name or "string.byte"
    slots_name = _random_name(rng, used, profile)
    first_value_name = _random_name(rng, used, profile)
    second_value_name = _random_name(rng, used, profile)
    third_value_name = _random_name(rng, used, profile)
    fourth_value_name = _random_name(rng, used, profile)
    decoder_name = _random_name(rng, used, profile)
    blob_name = _random_name(rng, used, profile)
    word_name = _random_name(rng, used, profile)
    factor_name = _random_name(rng, used, profile)
    if profile.execution_style == "staged" and profile.opcode_aliasing:
        disc_name = _random_name(rng, used, profile)
    else:
        disc_name = ""
    decoded_name = _random_name(rng, used, profile)
    code_field = profile.record_index("code")
    constants_field = profile.record_index("constants")
    locals_field = profile.record_index("locals")
    parameters_field = profile.record_index("parameters")
    guard_field = profile.record_index("guard")
    sentinels_field = profile.record_index("sentinels")
    constant_canaries_field = profile.record_index("constant_canaries")
    checksum_field = profile.record_index("checksum")
    semantic_error = _lua_string(profile.error_tokens[3])

    records: list[tuple[CompiledFunction, str]] = []
    for function in rng.sample(functions, len(functions)):
        code_source = (
            lua_binary_literal(pack_words(function.code))
            if profile.packed_bytecode
            else "{" + ",".join(profile.lua_integer(value, rng) for value in function.code) + "}"
        )
        sentinel_source = (
            "{" + ",".join(profile.lua_integer(value, rng) for pair in function.sentinel_words for value in pair) + "}"
        )
        canary_source = (
            "{"
            + ",".join(profile.lua_integer(value, rng) for canary in function.constant_canaries for value in canary)
            + "}"
        )
        fields = {
            "code": code_source,
            "constants": "{"
            + ",".join(_runtime_constant_source(value, profile) for value in function.program.constants)
            + "}",
            "locals": profile.lua_integer(function.program.local_count, rng),
            "parameters": profile.lua_integer(function.program.parameter_count, rng),
            "guard": profile.lua_integer(function.guard_token, rng),
            "sentinels": sentinel_source,
            "constant_canaries": canary_source,
            "checksum": profile.lua_integer(_integrity_checksum(function, profile, dialect), rng),
        }
        record = "{" + ",".join(fields[field] for field in profile.record_order) + "}"
        records.append((function, record))
    opcode_limit = profile.opcode_encoding.modulus if profile.opcode_encoding is not None else 997
    active_opcodes = {
        instruction: value
        for instruction, value in opcodes.items()
        if instruction not in DYNAMIC_RESULT_INSTRUCTIONS or instruction in used_instructions
    }
    active_opcode_values = set(active_opcodes.values())
    available_decoys = [value for value in range(3, opcode_limit) if value not in active_opcode_values]
    decoy_values = rng.sample(available_decoys, min(profile.decoy_opcode_count, len(available_decoys)))
    manifest_opcodes = {**active_opcodes, **{f"decoy-{index}": value for index, value in enumerate(decoy_values)}}
    bootstrap = render_bootstrap(
        rng,
        used,
        profile,
        records,
        manifest_opcodes,
        programs_name,
        _lua_string(profile.error_tokens[3]),
    )

    reader_name = _random_name(rng, used, profile)
    group_name = _random_name(rng, used, profile)
    stack_step = "+1" if profile.stack_direction == 1 else "-1"
    stack_unstep = "-1" if profile.stack_direction == 1 else "+1"
    below_top = f"{sp_name}-1" if profile.stack_direction == 1 else f"{sp_name}+1"
    two_below_top = f"{sp_name}-2" if profile.stack_direction == 1 else f"{sp_name}+2"

    def read_into(target: str) -> str:
        if profile.operand_encoding is None:
            return f"local {target}={code_name}[{ip_name}];{ip_name}={ip_name}+1"
        return f"local {target}={reader_name}()"

    push_prefix = f"{sp_name}={sp_name}{stack_step};"
    pop_suffix = f"{stack_name}[{sp_name}]=nil;{sp_name}={sp_name}{stack_unstep}"
    local_key = profile.register_lua(index_name)
    left_local_key = profile.register_lua(left_name)
    right_local_key = profile.register_lua(right_name)
    loop_local_key = profile.register_lua(loop_name)

    binary_symbols = {
        "ADD": "+",
        "SUB": "-",
        "MUL": "*",
        "DIV": "/",
        "MOD": "%",
        "POW": "^",
        "CONCAT": "..",
        "EQ": "==",
        "NE": "~=",
        "LT": "<",
        "LE": "<=",
        "GT": ">",
        "GE": ">=",
    }
    step_error, call_error, opcode_error, integrity_error = (_lua_string(token) for token in profile.error_tokens)
    const_handler = read_into(index_name) + ";"
    if anti_tamper_mode != "off":
        const_handler += f"local {position_name}={sp_name};"
    const_handler += push_prefix + f"{stack_name}[{sp_name}]={constants_name}[{index_name}]"
    if anti_tamper_mode != "off":
        const_handler += f";if {sp_name}~={position_name}{stack_step} then error({semantic_error},0) end"
    add_disc = 1 if profile.alu_inverted else 0
    eq_disc = 1 if profile.cmp_inverted else 0
    alu_setup: list[str] = []
    if profile.execution_style == "staged":
        alu_signature = (
            f"local function {factor_name}({count_name},{left_name},{right_name},{disc_name})"
            if profile.opcode_aliasing
            else f"local function {factor_name}({count_name},{left_name},{right_name})"
        )
        alu_cases = [
            f"{'if' if position == 0 else 'elseif'} {count_name}=={opcodes[instruction]} "
            f"then return {left_name}{symbol}{right_name}"
            for position, (instruction, symbol) in enumerate(binary_symbols.items())
        ]
        if profile.opcode_aliasing:
            alu_cases.append(
                f"elseif {count_name}=={opcodes['ALU_DUAL']} then "
                f"if {disc_name}=={add_disc} then return {left_name}+{right_name} "
                f"else return {left_name}-{right_name} end"
            )
            alu_cases.append(
                f"elseif {count_name}=={opcodes['CMP_DUAL']} then "
                f"if {disc_name}=={eq_disc} then return {left_name}=={right_name} "
                f"else return {left_name}~={right_name} end"
            )
        alu_setup = [alu_signature, *alu_cases, f"else error({opcode_error},0) end", "end"]
    handlers: dict[str, str] = {
        "CONST": const_handler,
        "TRUE": push_prefix + f"{stack_name}[{sp_name}]=true",
        "FALSE": push_prefix + f"{stack_name}[{sp_name}]=false",
        "NIL": push_prefix + f"{stack_name}[{sp_name}]=nil",
        "GET_VARARG": (
            read_into(index_name) + ";" + push_prefix + f"{stack_name}[{sp_name}]={varargs_name}[{index_name}]"
        ),
        "PACK_VARARG": (
            push_prefix
            + f"{stack_name}[{sp_name}]={pack_name}({unpack_name}({varargs_name},1,{vararg_count_name}))"
        ),
        "RETURN_VARARG": f"return {unpack_name}({varargs_name},1,{vararg_count_name})",
        "GET_LOCAL": read_into(index_name) + ";" + push_prefix + f"{stack_name}[{sp_name}]={locals_name}[{local_key}]",
        "SET_LOCAL": (read_into(index_name) + f";{locals_name}[{local_key}]={stack_name}[{sp_name}];" + pop_suffix),
        "GET_EXT": (
            read_into(index_name) + ";" + push_prefix + f"{stack_name}[{sp_name}]={externals_name}[{index_name}]"
        ),
        "SET_EXT": (
            read_into(index_name)
            + f";local {left_name}={stack_name}[{sp_name}];{externals_name}[{index_name}]={left_name};"
            + f"{setters_name}[{index_name}]({left_name});{pop_suffix}"
        ),
        "GET_BOX": (
            read_into(index_name) + ";" + push_prefix + f"{stack_name}[{sp_name}]={boxes_name}[{index_name}][1]"
        ),
        "SET_BOX": (
            read_into(index_name)
            + f";local {left_name}={stack_name}[{sp_name}];{boxes_name}[{index_name}][1]={left_name};"
            + pop_suffix
        ),
        "CLOSE_OVER": (
            read_into(index_name)
            + f";local {left_name}={stack_name}[{sp_name}];"
            + f"local {right_name}={externals_name}[{index_name}];"
            + f"{stack_name}[{sp_name}]=function(...)return {right_name}({left_name},...) end"
        ),
        "POP": pop_suffix,
        "DUP": f"local {left_name}={stack_name}[{sp_name}];{push_prefix}{stack_name}[{sp_name}]={left_name}",
        "NEG": f"{stack_name}[{sp_name}]=-{stack_name}[{sp_name}]",
        "NOT": f"{stack_name}[{sp_name}]=not {stack_name}[{sp_name}]",
        "LEN": f"{stack_name}[{sp_name}]=#{stack_name}[{sp_name}]",
        "JUMP": read_into(index_name) + f";{ip_name}={index_name}",
        "JFALSE_POP": (
            read_into(index_name)
            + f";local {left_name}={stack_name}[{sp_name}];{pop_suffix};"
            + f"if not {left_name} then {ip_name}={index_name} end"
        ),
        "JFALSE_KEEP": read_into(index_name) + f";if not {stack_name}[{sp_name}] then {ip_name}={index_name} end",
        "JTRUE_KEEP": read_into(index_name) + f";if {stack_name}[{sp_name}] then {ip_name}={index_name} end",
        "NEW_TABLE": push_prefix + f"{stack_name}[{sp_name}]={{}}",
        "GET_INDEX": (
            f"local {right_name}={stack_name}[{sp_name}];local {left_name}={stack_name}[{below_top}];"
            f"{pop_suffix};{stack_name}[{sp_name}]={left_name}[{right_name}]"
        ),
        "SET_INDEX": (
            f"local {right_name}={stack_name}[{sp_name}];local {index_name}={stack_name}[{below_top}];"
            f"local {left_name}={stack_name}[{two_below_top}];{left_name}[{index_name}]={right_name};"
            f"{stack_name}[{sp_name}]=nil;{stack_name}[{below_top}]=nil;{stack_name}[{two_below_top}]=nil;"
            f"{sp_name}={sp_name}{'-3' if profile.stack_direction == 1 else '+3'}"
        ),
        "SET_INDEX_KEEP": (
            f"local {right_name}={stack_name}[{sp_name}];local {index_name}={stack_name}[{below_top}];"
            f"local {left_name}={stack_name}[{two_below_top}];{left_name}[{index_name}]={right_name};"
            f"{stack_name}[{sp_name}]=nil;{stack_name}[{below_top}]=nil;"
            f"{sp_name}={sp_name}{'-2' if profile.stack_direction == 1 else '+2'}"
        ),
        "TABLE_APPEND_PACK": (
            read_into(index_name)
            + f";local {packed_name}={stack_name}[{sp_name}];local {left_name}={stack_name}[{below_top}];"
            + f"for {loop_name}=1,{packed_name}[0] do "
            + f"{left_name}[{index_name}+{loop_name}-1]={packed_name}[{loop_name}] end;"
            + pop_suffix
        ),
        "GET_METHOD": (
            read_into(index_name)
            + f";local {object_name}={stack_name}[{sp_name}];"
            + f"{stack_name}[{sp_name}]={object_name}[{constants_name}[{index_name}]];"
            + push_prefix
            + f"{stack_name}[{sp_name}]={object_name}"
        ),
        "COERCE_NUMBER": read_into(index_name) + f";{locals_name}[{local_key}]={locals_name}[{local_key}]+0",
        "CHECK_STEP": (read_into(index_name) + f";if {locals_name}[{local_key}]==0 then error({step_error},0) end"),
        "ADD_LOCAL_CONST_SET": (
            read_into(index_name)
            + ";"
            + read_into(left_name)
            + ";"
            + read_into(right_name)
            + f";{locals_name}[{right_local_key}]={locals_name}[{local_key}]+{constants_name}[{left_name}]"
        ),
        "ADD_LOCALS_SET": (
            read_into(index_name)
            + ";"
            + read_into(left_name)
            + ";"
            + read_into(right_name)
            + f";{locals_name}[{right_local_key}]={locals_name}[{local_key}]+{locals_name}[{left_local_key}]"
        ),
        "JNE_LOCAL_CONST": (
            read_into(index_name)
            + ";"
            + read_into(left_name)
            + ";"
            + read_into(right_name)
            + f";if {locals_name}[{local_key}]~={constants_name}[{left_name}] then {ip_name}={right_name} end"
        ),
        "RETURN": f"return {stack_name}[{sp_name}]",
        "RETURN_NONE": "return",
    }
    for instruction, symbol in binary_symbols.items():
        operation = (
            f"{factor_name}({opcodes[instruction]},{left_name},{right_name})"
            if profile.execution_style == "staged"
            else f"{left_name}{symbol}{right_name}"
        )
        handlers[instruction] = (
            f"local {right_name}={stack_name}[{sp_name}];local {left_name}={stack_name}[{below_top}];"
            f"{pop_suffix};{stack_name}[{sp_name}]={operation}"
        )

    if profile.opcode_aliasing:
        dual_read = read_into(index_name)
        dual_read_body = (
            f";local {right_name}={stack_name}[{sp_name}];"
            f"local {left_name}={stack_name}[{below_top}];{pop_suffix};"
        )
        if profile.execution_style == "staged":
            handlers["ALU_DUAL"] = (
                dual_read
                + dual_read_body
                + f"{stack_name}[{sp_name}]={factor_name}("
                f"{opcodes['ALU_DUAL']},{left_name},{right_name},{index_name})"
            )
            handlers["CMP_DUAL"] = (
                dual_read
                + dual_read_body
                + f"{stack_name}[{sp_name}]={factor_name}("
                f"{opcodes['CMP_DUAL']},{left_name},{right_name},{index_name})"
            )
        else:
            handlers["ALU_DUAL"] = (
                dual_read
                + dual_read_body
                + f"if {index_name}=={add_disc} then "
                f"{stack_name}[{sp_name}]={left_name}+{right_name} "
                f"else {stack_name}[{sp_name}]={left_name}-{right_name} end"
            )
            handlers["CMP_DUAL"] = (
                dual_read
                + dual_read_body
                + f"if {index_name}=={eq_disc} then "
                f"{stack_name}[{sp_name}]={left_name}=={right_name} "
                f"else {stack_name}[{sp_name}]={left_name}~={right_name} end"
            )
    else:
        # Dead dispatcher branches: these opcodes exist in the manifest but are
        # never emitted when aliasing is disabled.
        handlers["ALU_DUAL"] = f"error({opcode_error},0)"
        handlers["CMP_DUAL"] = f"error({opcode_error},0)"

    base_expression = f"{sp_name}-{count_name}" if profile.stack_direction == 1 else f"{sp_name}+{count_name}"
    expanded_base_expression = (
        f"{sp_name}-{count_name}-1" if profile.stack_direction == 1 else f"{sp_name}+{count_name}+1"
    )
    call_cases = [f"if {count_name}==0 then {stack_name}[{base_name}]={function_name}()"]
    pack_cases = [f"if {count_name}==0 then {stack_name}[{base_name}]={pack_name}({function_name}())"]
    tail_cases = [f"if {count_name}==0 then return {function_name}()"]
    multi_cases = [
        f"if {count_name}==0 then {first_value_name},{second_value_name},{third_value_name}={function_name}()"
    ]
    for argument_count in range(1, _MAX_CALL_ARGUMENTS + 1):
        arguments = ",".join(
            f"{stack_name}[{base_name}{'+' if profile.stack_direction == 1 else '-'}{offset}]"
            for offset in range(1, argument_count + 1)
        )
        call_cases.append(
            f"elseif {count_name}=={argument_count} then {stack_name}[{base_name}]={function_name}({arguments})"
        )
        pack_cases.append(
            f"elseif {count_name}=={argument_count} then "
            f"{stack_name}[{base_name}]={pack_name}({function_name}({arguments}))"
        )
        tail_cases.append(f"elseif {count_name}=={argument_count} then return {function_name}({arguments})")
        multi_cases.append(
            f"elseif {count_name}=={argument_count} then "
            f"{first_value_name},{second_value_name},{third_value_name}={function_name}({arguments})"
        )
    call_cases.append(f"else error({call_error},0) end")
    pack_cases.append(f"else error({call_error},0) end")
    tail_cases.append(f"else error({call_error},0) end")
    multi_cases.append(f"else error({call_error},0) end")
    cleanup_loop = (
        f"for {loop_name}={base_name}+1,{sp_name} do {stack_name}[{loop_name}]=nil end"
        if profile.stack_direction == 1
        else f"for {loop_name}={base_name}-1,{sp_name},-1 do {stack_name}[{loop_name}]=nil end"
    )
    handlers["CALL"] = (
        read_into(count_name)
        + f";local {base_name}={base_expression};local {function_name}={stack_name}[{base_name}];"
        + ";".join(call_cases)
        + f";{cleanup_loop};{sp_name}={base_name}"
    )
    handlers["CALL_PACK"] = (
        read_into(count_name)
        + f";local {base_name}={base_expression};local {function_name}={stack_name}[{base_name}];"
        + ";".join(pack_cases)
        + f";{cleanup_loop};{sp_name}={base_name}"
    )
    handlers["TAIL_CALL"] = (
        read_into(count_name)
        + f";local {base_name}={base_expression};local {function_name}={stack_name}[{base_name}];"
        + ";".join(tail_cases)
    )
    fixed_argument_index = f"{base_name}+{loop_name}" if profile.stack_direction == 1 else f"{base_name}-{loop_name}"
    dynamic_call_setup = (
        f";local {call_args_name}={{}};for {loop_name}=1,{count_name} do "
        f"{call_args_name}[{loop_name}]={stack_name}[{fixed_argument_index}] end;"
        f"for {loop_name}=1,{vararg_count_name} do "
        f"{call_args_name}[{count_name}+{loop_name}]={varargs_name}[{loop_name}] end;"
        f"local {index_name}={count_name}+{vararg_count_name}"
    )
    handlers["CALL_VARARG"] = (
        read_into(count_name)
        + f";local {base_name}={base_expression};local {function_name}={stack_name}[{base_name}]"
        + dynamic_call_setup
        + f";{stack_name}[{base_name}]={function_name}({unpack_name}({call_args_name},1,{index_name}));"
        + f"{cleanup_loop};{sp_name}={base_name}"
    )
    handlers["CALL_VARARG_PACK"] = (
        read_into(count_name)
        + f";local {base_name}={base_expression};local {function_name}={stack_name}[{base_name}]"
        + dynamic_call_setup
        + f";{stack_name}[{base_name}]={pack_name}({function_name}("
        + f"{unpack_name}({call_args_name},1,{index_name})));{cleanup_loop};{sp_name}={base_name}"
    )
    handlers["TAIL_CALL_VARARG"] = (
        read_into(count_name)
        + f";local {base_name}={base_expression};local {function_name}={stack_name}[{base_name}]"
        + dynamic_call_setup
        + f";return {function_name}({unpack_name}({call_args_name},1,{index_name}))"
    )
    expanded_call_setup = (
        f";local {packed_name}={stack_name}[{sp_name}];local {packed_count_name}={packed_name}[0];"
        f"local {call_args_name}={{}};for {loop_name}=1,{count_name} do "
        f"{call_args_name}[{loop_name}]={stack_name}[{fixed_argument_index}] end;"
        f"for {loop_name}=1,{packed_count_name} do "
        f"{call_args_name}[{count_name}+{loop_name}]={packed_name}[{loop_name}] end;"
        f"local {index_name}={count_name}+{packed_count_name}"
    )
    handlers["CALL_EXPANDED"] = (
        read_into(count_name)
        + f";local {base_name}={expanded_base_expression};local {function_name}={stack_name}[{base_name}]"
        + expanded_call_setup
        + f";{stack_name}[{base_name}]={function_name}({unpack_name}({call_args_name},1,{index_name}));"
        + f"{cleanup_loop};{sp_name}={base_name}"
    )
    handlers["CALL_EXPANDED_PACK"] = (
        read_into(count_name)
        + f";local {base_name}={expanded_base_expression};local {function_name}={stack_name}[{base_name}]"
        + expanded_call_setup
        + f";{stack_name}[{base_name}]={pack_name}({function_name}("
        + f"{unpack_name}({call_args_name},1,{index_name})));{cleanup_loop};{sp_name}={base_name}"
    )
    handlers["TAIL_CALL_EXPANDED"] = (
        read_into(count_name)
        + f";local {base_name}={expanded_base_expression};local {function_name}={stack_name}[{base_name}]"
        + expanded_call_setup
        + f";return {function_name}({unpack_name}({call_args_name},1,{index_name}))"
    )
    handlers["EXPAND_FIXED"] = (
        read_into(count_name)
        + f";local {packed_name}={stack_name}[{sp_name}];{stack_name}[{sp_name}]=nil;"
        + f"{sp_name}={sp_name}{stack_unstep};for {loop_name}=1,{count_name} do "
        + f"{sp_name}={sp_name}{stack_step};{stack_name}[{sp_name}]={packed_name}[{loop_name}] end"
    )
    return_value_index = (
        f"{base_name}+{loop_name}-1" if profile.stack_direction == 1 else f"{base_name}-{loop_name}+1"
    )
    handlers["RETURN_EXPANDED"] = (
        read_into(count_name)
        + f";local {packed_name}={stack_name}[{sp_name}];local {base_name}={base_expression};"
        + f"local {call_args_name}={{}};for {loop_name}=1,{count_name} do "
        + f"{call_args_name}[{loop_name}]={stack_name}[{return_value_index}] end;"
        + f"local {packed_count_name}={packed_name}[0];for {loop_name}=1,{packed_count_name} do "
        + f"{call_args_name}[{count_name}+{loop_name}]={packed_name}[{loop_name}] end;"
        + f"return {unpack_name}({call_args_name},1,{count_name}+{packed_count_name})"
    )
    iterator_key = profile.register_lua(index_name)
    state_key = profile.register_lua(left_name)
    control_key = profile.register_lua(right_name)
    handlers["CALL_MULTI3"] = (
        read_into(count_name)
        + ";"
        + read_into(index_name)
        + ";"
        + read_into(left_name)
        + ";"
        + read_into(right_name)
        + f";local {base_name}={base_expression};local {function_name}={stack_name}[{base_name}];"
        + f"local {first_value_name},{second_value_name},{third_value_name};"
        + ";".join(multi_cases)
        + f";{locals_name}[{iterator_key}]={first_value_name};"
        + f"{locals_name}[{state_key}]={second_value_name};{locals_name}[{control_key}]={third_value_name};"
        + f"{cleanup_loop};{stack_name}[{base_name}]=nil;{sp_name}={base_name}{stack_unstep}"
    )
    return_cases = [f"if {count_name}==0 then return"]
    for return_count in range(1, 9):
        values = []
        for offset in range(return_count):
            distance = return_count - 1 - offset
            if distance == 0:
                values.append(f"{stack_name}[{sp_name}]")
            else:
                sign = "-" if profile.stack_direction == 1 else "+"
                values.append(f"{stack_name}[{sp_name}{sign}{distance}]")
        return_cases.append(f"elseif {count_name}=={return_count} then return {','.join(values)}")
    return_cases.append(f"else error({call_error},0) end")
    handlers["RETURN_MULTI"] = read_into(count_name) + ";" + ";".join(return_cases)
    generic_slot_key = profile.register_lua(f"{slots_name}[{loop_name}]")
    handlers["GENERIC_NEXT"] = (
        read_into(index_name)
        + ";"
        + read_into(left_name)
        + ";"
        + read_into(right_name)
        + ";"
        + read_into(count_name)
        + f";local {slots_name}={{}};for {loop_name}=1,{count_name} do {slots_name}[{loop_name}]={reader_name}() end;"
        + read_into(base_name)
        + f";local {first_value_name},{second_value_name},{third_value_name},{fourth_value_name}="
        + f"{locals_name}[{iterator_key}]({locals_name}[{state_key}],{locals_name}[{control_key}]);"
        + f"if {first_value_name}==nil then {ip_name}={base_name} else "
        + f"{locals_name}[{control_key}]={first_value_name};"
        + f"if {count_name}>=1 then {loop_name}=1;{locals_name}[{generic_slot_key}]={first_value_name} end;"
        + f"if {count_name}>=2 then {loop_name}=2;{locals_name}[{generic_slot_key}]={second_value_name} end;"
        + f"if {count_name}>=3 then {loop_name}=3;{locals_name}[{generic_slot_key}]={third_value_name} end;"
        + f"if {count_name}>=4 then {loop_name}=4;{locals_name}[{generic_slot_key}]={fourth_value_name} end end"
    )

    dispatch_items = [
        (opcodes[instruction], handlers[instruction])
        for instruction in ALL_INSTRUCTIONS
        if instruction not in DYNAMIC_RESULT_INSTRUCTIONS or instruction in used_instructions
    ]
    for index, decoy_opcode in enumerate(decoy_values):
        if index % 3 == 0:
            # Inert arithmetic on a scratch local: executes real work but maps to
            # no recoverable semantic, and is never emitted by real control flow.
            decoy_handler = f"{left_name}={left_name}*1"
        elif index % 3 == 1:
            decoy_handler = f"local {left_name}={op_name};{left_name}={left_name}-{op_name}"
        else:
            decoy_handler = f"local {left_name}={stack_name}[{sp_name}];error({opcode_error},0)"
        dispatch_items.append((decoy_opcode, decoy_handler))
    dispatch_items = rng.sample(dispatch_items, len(dispatch_items))

    def chain_lines(items: list[tuple[int, str]]) -> list[str]:
        lines = [
            f"{'if' if position == 0 else 'elseif'} {op_name}=={opcode} then {handler}"
            for position, (opcode, handler) in enumerate(items)
        ]
        lines.append(f"else error({opcode_error},0) end")
        return lines

    def linear_dispatch(items: list[tuple[int, str]]) -> str:
        return "\n".join(chain_lines(items))

    def fragmented_dispatch(items: list[tuple[int, str]]) -> str:
        """Two/three value-ranged groups instead of one contiguous opcode chain.

        Groups are contiguous by opcode value, each rendered as an indented
        linear chain with an unreachable decoy range guard before its final
        fallthrough. The indentation alone defeats line-anchored chain parsers,
        and the value-ranged split means no single flat `if op==N` ladder.
        """
        ordered = sorted(items)
        if len(ordered) < 8:
            return linear_dispatch(ordered)
        group_count = 3 if len(ordered) >= 16 else 2
        groups: list[list[tuple[int, str]]] = [[] for _ in range(group_count)]
        for index, item in enumerate(ordered):
            group_index = min(group_count - 1, (index * group_count) // len(ordered))
            groups[group_index].append(item)
        boundaries = [groups[g][0][0] for g in range(1, group_count)]
        out: list[str] = []
        for group_index, group in enumerate(groups):
            lines = chain_lines(group)
            last_opcode = group[-1][0]
            upper = boundaries[group_index] if group_index < group_count - 1 else None
            if upper is not None and last_opcode + 1 < upper:
                # Middle elseif branch: no `end` here — the chain's final
                # `else error(...) end` closes the single if-statement.
                lines.insert(
                    -1,
                    f"elseif {op_name}>={last_opcode + 1} and {op_name}<{upper} "
                    f"then error({opcode_error},0)",
                )
            if group_index == 0:
                out.append(f"if {op_name}<{boundaries[0]} then")
            elif group_index == group_count - 1:
                out.append("else")
            else:
                out.append(f"elseif {op_name}<{boundaries[group_index]} then")
            out.extend(" " + line for line in lines)
        out.append("end")
        return "\n".join(out)

    def binary_dispatch(items: list[tuple[int, str]]) -> str:
        ordered = sorted(items)
        if len(ordered) <= 2:
            return linear_dispatch(ordered)
        middle = len(ordered) // 2
        opcode, handler = ordered[middle]
        return (
            f"if {op_name}<{opcode} then\n{binary_dispatch(ordered[:middle])}\n"
            f"elseif {op_name}=={opcode} then {handler}\n"
            f"else\n{binary_dispatch(ordered[middle + 1 :])}\nend"
        )

    dispatch_setup: list[str] = [f"local {byte_function_name}=string.byte"] if byte_function_name else []
    dispatch_setup.extend(alu_setup)
    if profile.dispatcher == "binary":
        dispatcher_source = binary_dispatch(dispatch_items)
    elif profile.dispatcher == "bucket":
        buckets = [dispatch_items[index::3] for index in range(3)]
        group_entries = [f"[{opcode}]={group + 1}" for group, bucket in enumerate(buckets) for opcode, _ in bucket]
        dispatch_setup.append(f"local {group_name}={{{','.join(group_entries)}}}")
        group_value = _random_name(rng, used, profile)
        dispatcher_source = "\n".join(
            [
                f"local {group_value}={group_name}[{op_name}]",
                *[
                    f"{'if' if index == 0 else 'elseif'} {group_value}=={index + 1} then\n{linear_dispatch(bucket)}"
                    for index, bucket in enumerate(buckets)
                ],
                f"else error({opcode_error},0) end",
            ]
        )
    else:
        dispatcher_source = fragmented_dispatch(dispatch_items)
    if profile.packed_bytecode:
        dispatch_setup.extend(
            [
                f"local function {decoder_name}({blob_name})",
                f"local {decoded_name}, {word_name}, {factor_name}={{}},0,1",
                f"for {loop_name}=1,#{blob_name} do",
                f"local {byte_name}={byte_function_name}({blob_name},{loop_name})",
                f"{word_name}={word_name}+({byte_name}%128)*{factor_name}",
                (
                    f"if {byte_name}<128 then {decoded_name}[#{decoded_name}+1]={word_name};"
                    f"{word_name}=0;{factor_name}=1 else {factor_name}={factor_name}*128 end"
                ),
                "end",
                f"return {decoded_name}",
                "end",
            ]
        )
    if profile.integrity_sample_slot % 2 == 0:
        dispatch_setup.extend(
            [
                f"local function {unpack_name}({call_args_name},{unpack_index_name},{unpack_limit_name})",
                f"if {unpack_index_name}>{unpack_limit_name} then return end",
                (
                    f"return {call_args_name}[{unpack_index_name}],"
                    f"{unpack_name}({call_args_name},{unpack_index_name}+1,{unpack_limit_name})"
                ),
                "end",
            ]
        )
    else:
        dispatch_setup.extend(
            [
                f"local {unpack_name};{unpack_name}=function({call_args_name},{unpack_index_name},{unpack_limit_name})",
                f"if {unpack_index_name}>{unpack_limit_name} then return end",
                (
                    f"return {call_args_name}[{unpack_index_name}],"
                    f"{unpack_name}({call_args_name},{unpack_index_name}+1,{unpack_limit_name})"
                ),
                "end",
            ]
        )
    if uses_dynamic_results:
        dispatch_setup.append(f"local function {pack_name}(...) return {{[0]=select(\"#\",...),...}} end")
    if getter_name:
        dispatch_setup.append(
            f"local function {getter_name}({unpack_index_name})return {programs_name}[{unpack_index_name}] end"
        )
    noise_name = _random_name(rng, used, profile)
    for noise_index in range(profile.integrity_sample_period):
        if noise_index % 3 == 0:
            dispatch_setup.append(f"do local {noise_name}={noise_index} end")
        elif noise_index % 3 == 1:
            dispatch_setup.append(f"local {noise_name};{noise_name}={noise_index};{noise_name}=nil")
        else:
            dispatch_setup.append(
                f"local {noise_name}={noise_index};{noise_name}={noise_name}+{noise_index}-{noise_index}"
            )

    tamper_lines: list[str] = []
    integrity_lines: list[str] = []
    if anti_tamper_mode != "off":
        tamper_lines = [
            f"if {guard_argument_name}~={program_name}[{guard_field}] then error({integrity_error},0) end",
            f"local {sentinels_name}={program_name}[{sentinels_field}]",
            f"for {loop_name}=1,#{sentinels_name},2 do",
            (
                f"if {code_name}[{sentinels_name}[{loop_name}]]~={sentinels_name}[{loop_name}+1] "
                f"then error({integrity_error},0) end"
            ),
            "end",
            f"local {constant_canaries_name}={program_name}[{constant_canaries_field}]",
            f"for {loop_name}=1,#{constant_canaries_name},3 do",
            f"local {index_name}={constant_canaries_name}[{loop_name}]",
            f"local {canary_type_name}={constant_canaries_name}[{loop_name}+1]",
            f"local {canary_expected_name}={constant_canaries_name}[{loop_name}+2]",
            f"local {constant_name}={constants_name}[{index_name}]",
            f"local {canary_hash_name}",
            f"if {canary_type_name}==1 then",
            f"{canary_hash_name}=17;for {byte_name}=1,#{constant_name} do",
            (
                f"{canary_hash_name}=({canary_hash_name}*257+{byte_accessor}({constant_name},{byte_name})+"
                f"{byte_name})%1000003 end"
            ),
            "else",
            f"local {mantissa_name},{exponent_name}=math.frexp({constant_name})",
            f"local {slots_name}={{97,{exponent_name}+4096,"
            f"math.floor(math.abs({mantissa_name})*1073741824+0.5),{mantissa_name}<0 and 1 or 0}}",
            f"{canary_hash_name}=29;for {byte_name}=1,4 do",
            f"{canary_hash_name}=({canary_hash_name}*263+{slots_name}[{byte_name}]+{byte_name})%1000003 end",
            "end",
            f"if {canary_hash_name}~={canary_expected_name} then error({integrity_error},0) end",
            "end",
        ]
        if anti_tamper_mode == "always":
            condition = "true"
        elif anti_tamper_mode == "sampled":
            tamper_lines.extend(
                [
                    f"local {call_count_name}=({call_counts_name}[{index_name}] or 0)+1",
                    f"{call_counts_name}[{index_name}]={call_count_name}",
                ]
            )
            condition = (
                f"not {verified_name}[{index_name}] or "
                f"{call_count_name}%{profile.lua_integer(profile.integrity_sample_period, rng)}"
                f"=={profile.lua_integer(profile.integrity_sample_slot, rng)}"
            )
        else:
            condition = f"not {verified_name}[{index_name}]"
        modulus = profile.integrity_modulus
        multiplier = profile.integrity_multiplier
        increment = profile.integrity_increment
        first_weight, second_weight, third_weight, fourth_weight = profile.integrity_weights
        if profile.integrity_family == "fletcher":
            integrity_lines = [
                f"if {condition} then",
                (
                    f"local {checksum_name},{checksum_second_name}={increment}%{modulus},"
                    f"({multiplier}+{index_name})%{modulus}"
                ),
                (
                    f"local function {mix_name}({left_name}) {checksum_name}=({checksum_name}+{left_name})%{modulus};"
                    f"{checksum_second_name}=({checksum_second_name}+{checksum_name})%{modulus} end"
                ),
            ]
        else:
            integrity_lines = [
                f"if {condition} then",
                f"local {checksum_name},{position_name}={increment}%{modulus},0",
                (
                    f"local function {mix_name}({left_name}) {position_name}={position_name}+1;"
                    f"{checksum_name}=({checksum_name}*{multiplier}+{left_name}+{position_name})%{modulus} end"
                ),
            ]
        integrity_lines.extend(
            [
                f"{mix_name}({index_name})",
                f"{mix_name}({program_name}[{guard_field}])",
                f"{mix_name}({program_name}[{locals_field}]*{first_weight})",
                f"{mix_name}({program_name}[{parameters_field}]*{second_weight})",
                f"{mix_name}(#{code_name}*{third_weight})",
                f"{mix_name}(#{constants_name}*{fourth_weight})",
                f"for {loop_name}=1,#{code_name} do {mix_name}({code_name}[{loop_name}]) end",
                f"for {loop_name}=1,#{sentinels_name},2 do",
                f"{mix_name}({sentinels_name}[{loop_name}]+{second_weight})",
                f"{mix_name}({sentinels_name}[{loop_name}+1]+{fourth_weight})",
                "end",
                f"for {loop_name}=1,#{constant_canaries_name},3 do",
                f"{mix_name}({constant_canaries_name}[{loop_name}]+{first_weight})",
                f"{mix_name}({constant_canaries_name}[{loop_name}+1]+{second_weight})",
                f"{mix_name}({constant_canaries_name}[{loop_name}+2]+{third_weight})",
                "end",
                f"for {loop_name}=1,#{constants_name} do",
                f"{mix_name}({loop_name}+{increment})",
                f"local {constant_name}={constants_name}[{loop_name}]",
                f'if type({constant_name})=="string" then',
                f"{mix_name}(#{constant_name}+{third_weight})",
                f"for {byte_name}=1,#{constant_name} do",
                f"{mix_name}({byte_accessor}({constant_name},{byte_name})+{byte_name})",
                "end",
                f'elseif type({constant_name})=="number" then',
                f"local {mantissa_name},{exponent_name}=math.frexp({constant_name})",
                f"{mix_name}({fourth_weight}+{loop_name})",
                f"{mix_name}({exponent_name}+4096)",
                f"{mix_name}(math.floor(math.abs({mantissa_name})*1073741824+0.5))",
                f"{mix_name}({mantissa_name}<0 and 1 or 0)",
                "else",
                f"{mix_name}({fourth_weight}+{loop_name})",
                "end",
                "end",
            ]
        )
        if profile.integrity_family == "fletcher":
            integrity_lines.append(f"{checksum_name}=({checksum_name}+{checksum_second_name}*{first_weight})%{modulus}")
        integrity_lines.append(
            f"if {checksum_name}~={program_name}[{checksum_field}] then error({integrity_error},0) end"
        )
        if anti_tamper_mode in {"once", "sampled"}:
            integrity_lines.append(f"{verified_name}[{index_name}]=true")
        integrity_lines.append("end")

    decoded_operand = profile.decode_operand_lua(index_name)
    if profile.bootstrap_seed % 2 == 0:
        reader_lines = [
            f"local function {reader_name}()",
            f"local {index_name}={code_name}[{ip_name}]",
            f"{ip_name}={ip_name}+1",
            f"return {decoded_operand}",
            "end",
        ]
    else:
        reader_lines = [
            f"local {reader_name};do {reader_name}=function()",
            f"local {index_name}={code_name}[{ip_name}]",
            f"{ip_name}={ip_name}+1",
            f"return {decoded_operand}",
            "end end",
        ]

    opcode_fetch = [f"local {op_name}={code_name}[{ip_name}]", f"{ip_name}={ip_name}+1"]
    if profile.opcode_encoding is not None:
        opcode_fetch.append(f"{op_name}={profile.decode_opcode_lua(op_name)}")
    if profile.execution_style == "staged":
        fetch_state, execute_state = profile.bootstrap_canaries[:2]
        loop_start = "while true do" if profile.loop_style == "while" else "repeat"
        loop_end = "end" if profile.loop_style == "while" else "until false"
        staged_opcode_fetch = [f"{op_name}={code_name}[{ip_name}]", f"{ip_name}={ip_name}+1"]
        if profile.opcode_encoding is not None:
            staged_opcode_fetch.append(f"{op_name}={profile.decode_opcode_lua(op_name)}")
        execution_loop = [
            f"local {object_name},{op_name}={fetch_state}",
            loop_start,
            f"if {object_name}=={fetch_state} then",
            *staged_opcode_fetch,
            f"{object_name}={execute_state}",
            "end",
            f"if {object_name}=={execute_state} then",
            f"{object_name}={fetch_state}",
            dispatcher_source,
            "end",
            loop_end,
        ]
    else:
        execution_loop = (
            ["while true do", *opcode_fetch, dispatcher_source, "end"]
            if profile.loop_style == "while"
            else ["repeat", *opcode_fetch, dispatcher_source, "until false"]
        )

    code_load_lines = [
        f"local {constants_name}={program_name}[{constants_field}]",
        f"local {code_name}={program_name}[{code_field}]",
    ]
    if profile.packed_bytecode:
        code_load_lines.extend(
            [
                f'if type({code_name})=="string" then',
                f"{code_name}={decoder_name}({code_name});{program_name}[{code_field}]={code_name}",
                "end",
            ]
        )
    identity_lines = [f"if {program_name}==nil then error({semantic_error},0) end"] if anti_tamper_mode != "off" else []
    entry_state_lines = [f"if {ip_name}~=1 then error({semantic_error},0) end"] if anti_tamper_mode != "off" else []
    parameter_consistency_lines = (
        [
            f"for {loop_name}=1,{program_name}[{parameters_field}] do",
            (f"local {left_name}={locals_name}[{loop_local_key}];local {right_name}={args_name}[{loop_name}]"),
            (
                f'if {left_name}~={right_name} and not(type({left_name})=="number" and '
                f'type({right_name})=="number" and {left_name}~={left_name} and '
                f"{right_name}~={right_name}) then error({semantic_error},0) end"
            ),
            "end",
        ]
        if anti_tamper_mode != "off"
        else []
    )
    runtime_body = [
        (
            f"local {program_name}={getter_name}({index_name})"
            if getter_name
            else f"local {program_name}={programs_name}[{index_name}]"
        ),
        *identity_lines,
        *code_load_lines,
        *tamper_lines,
        *integrity_lines,
        f"local {locals_name}={{}}",
        f"local {stack_name}={{}}",
        (
            f"for {loop_name}=1,{program_name}[{parameters_field}] do "
            f"{locals_name}[{loop_local_key}]={args_name}[{loop_name}] end"
        ),
        *parameter_consistency_lines,
        f"local {ip_name}=1",
        f"local {sp_name}={profile.stack_origin}",
        *entry_state_lines,
        *reader_lines,
        *execution_loop,
    ]

    runtime_parameters = (
        f"{index_name},{guard_argument_name},{args_name},{externals_name},"
        f"{boxes_name},{setters_name},{varargs_name},{vararg_count_name}"
    )
    if profile.prelude == "iife":
        prelude_lines = [
            f"local {run_name}=(function()",
            *bootstrap.lines,
            f"local {verified_name},{call_counts_name}={{}},{{}}",
            *dispatch_setup,
            f"return function({runtime_parameters})",
            *runtime_body,
            "end",
            "end)()",
            "",
        ]
    else:
        prelude_lines = [
            f"local {run_name}",
            "do",
            *bootstrap.lines,
            f"local {verified_name},{call_counts_name}={{}},{{}}",
            *dispatch_setup,
            f"{run_name}=function({runtime_parameters})",
            *runtime_body,
            "end",
            "end",
            "",
        ]
    return run_name, "\n".join(prelude_lines)
