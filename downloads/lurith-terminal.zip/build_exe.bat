@echo off
setlocal
cd /d "%~dp0"

set "PYCMD="
where python >nul 2>nul && set "PYCMD=python"
if not defined PYCMD where py >nul 2>nul && set "PYCMD=py -3"
if not defined PYCMD goto nopython

echo Building with: %PYCMD%
call :pyrun --version
if errorlevel 1 goto nopython

echo.
echo [1/3] Installing PyInstaller (once)...
call :pyrun -m pip install --upgrade pyinstaller
if errorlevel 1 goto fail

echo.
echo [2/3] Building Lurith.exe and lurith-cli.exe (a few minutes)...
call :pyrun -m PyInstaller --noconfirm --clean lurith.spec
if errorlevel 1 goto fail

echo.
echo [3/3] Done! Your files are in the dist folder:
echo.
dir /b dist
echo.
echo   Lurith.exe       - double-click this to open the app
echo   lurith-cli.exe   - the terminal command
echo.
pause
goto done

:pyrun
if "%PYCMD%"=="py -3" (
    %PYCMD% %*
) else (
    "%PYCMD%" %*
)
exit /b %errorlevel%

:nopython
echo.
echo Python 3.11+ was not found.
echo.
echo Quickest fix: open PowerShell IN THIS FOLDER and paste:
echo     python -m pip install pyinstaller
echo     python -m PyInstaller --noconfirm --clean lurith.spec
echo.
echo Or install Python from https://www.python.org and tick
echo "Add Python to PATH", then run this again.
echo.
pause
goto done

:fail
echo.
echo The build did not finish.
echo If Windows Defender blocked it, add an exception for this folder
echo and run build_exe.bat again. Otherwise copy the red text above.
echo.
pause

:done
endlocal
