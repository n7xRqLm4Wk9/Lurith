@echo off
setlocal
cd /d "%~dp0"

python -c "import tree_sitter, tree_sitter_language_pack" >nul 2>nul
if errorlevel 1 goto install

:run
if "%~1"=="" goto gui
python -m lurith.cli %*
goto done

:gui
python -m lurith.gui
goto done

:install
echo.
echo First run: installing the Lurith engine - this happens once.
python -m pip install -r requirements-terminal.txt
if errorlevel 1 goto fail
goto run

:fail
echo.
echo Could not install the Lurith engine.
echo Install Python 3.11+ from python.org and tick "Add Python to PATH",
echo then run this again.
pause

:done
endlocal
